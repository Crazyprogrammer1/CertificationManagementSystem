import {
  Message
} from 'primeng/components/common/api';
import {
  TopicComponent
} from './../topic/topic.component';
import {
  Component,
  OnInit,
  Input,
  OnChanges,
  forwardRef,
  Inject,
  ChangeDetectorRef
} from '@angular/core';
import {
  InputTextareaModule
} from 'primeng/inputtextarea';
import {
  AfterViewInit,
  ViewChild,
  ElementRef,
  Renderer2
} from '@angular/core';
import {
  MessageService
} from 'primeng/api';
import {
  FormBuilder,
  FormGroup,
  FormArray,
  FormControl,
  FormControlName
} from '@angular/forms';
import {
  InformationService
} from '../service/information/information.service';
import {
  ComponentRef,
  ComponentFactoryResolver,
  ViewContainerRef
} from "@angular/core";
import {
  NgxSmartModalService,
  NgxSmartModalComponent
} from 'ngx-smart-modal';
import {
  ModalInstance
} from 'ngx-smart-modal/src/services/modal-instance';

interface SelectionRectangle {
  left: number;
  top: number;
  width: number;
  height: number;
}

@Component({
  selector: 'topic-textarea',
  templateUrl: './textarea.component.html',
  styleUrls: ['./textarea.component.css']
})
export class TextareaComponent {
  nsm;
  dialog;
  animation;
  rtl;


  @Input('topic_id') topic_id;
  @Input('form') form: FormGroup;

  @Input('textarea_no_counter') textarea_no_counter: number;

  displayDocSoa: boolean = false;

  @Input('title_of_information') title_of_information: string;
  @Input('separators') sep_values: any[];
  @Input('separator_dot') separator_dot: string;
  @Input('separator_colon') separator_colon: string;
  @Input('separator_semicolon') separator_semicolon: string;
  @Input('separator_dash') separator_dash: string;
  @Input('separator_rc') separator_rc: string;

  areas: FormArray;
  _ref: any;
  is_Popup_Editable: boolean[] = [];


  @Input('popup_text_area_value') popup_text_area_value: string[] = [];


  @Input('enable_information_screen') enable_information_screen: boolean;

  @Input('first_text_area_value') first_text_area_value: string;
  @Input('second_text_area_value') second_text_area_value: string;
  @Input('third_text_area_value') third_text_area_value: string;
  @Input('fourth_text_area_value') fourth_text_area_value: string;
  @Input('fifth_text_area_value') fifth_text_area_value: string;

  @Input('sixth_text_area_value') sixth_text_area_value: string;
  @Input('sevent_text_area_value') sevent_text_area_value: string;
  @Input('eighth_text_area_value') eighth_text_area_value: string;
  @Input('ninth_text_area_value') ninth_text_area_value: string;
  @Input('tenth_text_area_value') tenth_text_area_value: string;

  @Input('eleventh_text_area_value') eleventh_text_area_value: string;
  @Input('tweleve_text_area_value') tweleve_text_area_value: string;
  @Input('thirteen_text_area_value') thirteen_text_area_value: string;
  @Input('fourteen_text_area_value') fourteen_text_area_value: string;
  @Input('fifteen_text_area_value') fifteen_text_area_value: string;

  @Input('sixteen_text_area_value') sixteen_text_area_value: string;
  @Input('seventeen_text_area_value') seventeen_text_area_value: string;
  @Input('eighteen_text_area_value') eighteen_text_area_value: string;
  @Input('nineteen_text_area_value') nineteen_text_area_value: string;
  @Input('twenty_text_area_value') twenty_text_area_value: string;

  @Input('twentyone_text_area_value') twentyone_text_area_value: string;
  @Input('twentytwo_text_area_value') twentytwo_text_area_value: string;
  @Input('twentythree_text_area_value') twentythree_text_area_value: string;
  @Input('twentyfour_text_area_value') twentyfour_text_area_value: string;
  @Input('twentyfive_text_area_value') twentyfive_text_area_value: string;



  @Input('text_index') text_index;


  elementRef: ElementRef;

  private selectedText: string;

  constructor(
    public ngxSmartModalService: NgxSmartModalService,
    private CFR: ComponentFactoryResolver,
    @Inject(ElementRef) elementRef: ElementRef,
    private formBuilder: FormBuilder,
    private messageService: MessageService,
    private renderer2: Renderer2,
    private changeRef: ChangeDetectorRef,
    private infoSvc: InformationService) {
    this.elementRef = elementRef;
    this.selectedText = "";
  }

  ngOnInit() {


    if (this.popup_text_area_value[this.text_index - 1] == undefined) {

      this.popup_text_area_value[this.text_index - 1] = '';

    }


    for (var i = 0; i < 25; i++) {
      this.is_Popup_Editable.push(true);
      this.is_Popup_Disabled.push(false);
    }
  }

  get popupAreaDisabled() {
    return this.is_Popup_Disabled[this.text_index - 1];
  }

  getTextAreDisabled() {

    switch (this.text_index) {

      case 1:
        return this.text_area_1_disabled;

      case 2:
        return this.text_area_2_disabled;

      case 3:
        return this.text_area_3_disabled;

      case 4:
        return this.text_area_4_disabled;

      case 5:
        return this.text_area_5_disabled;

      case 6:
        return this.text_area_6_disabled;

      case 7:
        return this.text_area_7_disabled;

      case 8:
        return this.text_area_8_disabled;

      case 9:
        return this.text_area_9_disabled;

      case 10:
        return this.text_area_10_disabled;

      case 11:
        return this.text_area_11_disabled;

      case 12:
        return this.text_area_12_disabled;

      case 13:
        return this.text_area_13_disabled;

      case 14:
        return this.text_area_14_disabled;

      case 15:
        return this.text_area_15_disabled;

      case 16:
        return this.text_area_16_disabled;

      case 17:
        return this.text_area_17_disabled;

      case 18:
        return this.text_area_18_disabled;

      case 19:
        return this.text_area_19_disabled;

      case 20:
        return this.text_area_20_disabled;

      case 21:
        return this.text_area_21_disabled;

      case 22:
        return this.text_area_22_disabled;

      case 23:
        return this.text_area_23_disabled;

      case 24:
        return this.text_area_24_disabled;

      case 25:
        return this.text_area_25_disabled;
    }

  }
  detectInput(event) {
    switch (this.text_index) {

      case 1:
        this.first_text_area_value = event.target.value;
        this.popup_text_area_value[0] = this.first_text_area_value;
        break;

      case 2:
        this.second_text_area_value = event.target.value;
        this.popup_text_area_value[1] = this.second_text_area_value;
        break;

      case 3:
        this.third_text_area_value = event.target.value;
        this.popup_text_area_value[2] = this.third_text_area_value;
        break;

      case 4:
        this.fourth_text_area_value = event.target.value;
        this.popup_text_area_value[3] = this.fourth_text_area_value;
        break;

      case 5:
        this.fifth_text_area_value = event.target.value;
        this.popup_text_area_value[4] = this.fifth_text_area_value;
        break;

      case 6:
        this.sixth_text_area_value = event.target.value;
        this.popup_text_area_value[5] = this.sixth_text_area_value;
        break;

      case 7:
        this.sevent_text_area_value = event.target.value;
        this.popup_text_area_value[6] = this.sevent_text_area_value;
        break;

      case 8:
        this.eighth_text_area_value = event.target.value;
        this.popup_text_area_value[7] = this.eighth_text_area_value;
        break;

      case 9:
        this.ninth_text_area_value = event.target.value;
        this.popup_text_area_value[8] = this.ninth_text_area_value;
        break;

      case 10:
        this.tenth_text_area_value = event.target.value;
        this.popup_text_area_value[9] = this.tenth_text_area_value;
        break;

      case 11:
        this.eleventh_text_area_value = event.target.value;
        this.popup_text_area_value[10] = this.eleventh_text_area_value;
        break;

      case 12:
        this.tweleve_text_area_value = event.target.value;
        this.popup_text_area_value[11] = this.tweleve_text_area_value;
        break;

      case 13:
        this.thirteen_text_area_value = event.target.value;
        this.popup_text_area_value[12] = this.thirteen_text_area_value;
        break;

      case 14:
        this.fourteen_text_area_value = event.target.value;
        this.popup_text_area_value[13] = this.fourteen_text_area_value;
        break;

      case 15:
        this.fifteen_text_area_value = event.target.value;
        this.popup_text_area_value[14] = this.fifteen_text_area_value;
        break;

      case 16:
        this.sixteen_text_area_value = event.target.value;
        this.popup_text_area_value[15] = this.sixteen_text_area_value;
        break;

      case 17:
        this.seventeen_text_area_value = event.target.value;
        this.popup_text_area_value[16] = this.seventeen_text_area_value;
        break;

      case 18:
        this.eighteen_text_area_value = event.target.value;
        this.popup_text_area_value[17] = this.eighteen_text_area_value;
        break;

      case 19:
        this.nineteen_text_area_value = event.target.value;
        this.popup_text_area_value[18] = this.nineteen_text_area_value;
        break;

      case 20:
        this.twenty_text_area_value = event.target.value;
        this.popup_text_area_value[19] = this.twenty_text_area_value;
        break;

      case 21:
        this.twentyone_text_area_value = event.target.value;
        this.popup_text_area_value[20] = this.twentyone_text_area_value;
        break;

      case 22:
        this.twentytwo_text_area_value = event.target.value;
        this.popup_text_area_value[21] = this.twentytwo_text_area_value;
        break;

      case 23:
        this.twentythree_text_area_value = event.target.value;
        this.popup_text_area_value[22] = this.twentythree_text_area_value;
        break;

      case 24:
        this.twentyfour_text_area_value = event.target.value;
        this.popup_text_area_value[23] = this.twentyfour_text_area_value;
        break;

      case 25:
        this.twentyfive_text_area_value = event.target.value;
        this.popup_text_area_value[24] = this.twentyfive_text_area_value;
        break;


    }

  }

  validatePopup(ref) {

    switch (ref) {
      case 'text_area_1':
        this.first_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_2':
        this.second_text_area_value = this.popup_text_area_value[this.text_index - 1];


        break;
      case 'text_area_3':
        this.third_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_4':
        this.fourth_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_5':
        this.fifth_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_6':
        this.sixth_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;

      case 'text_area_7':
        this.sevent_text_area_value = this.popup_text_area_value[this.text_index - 1];


        break;
      case 'text_area_8':
        this.eighth_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_9':
        this.ninth_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_10':
        this.tenth_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_11':
        this.eleventh_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_12':
        this.tweleve_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;

      case 'text_area_13':
        this.thirteen_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_14':
        this.fourteen_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_15':
        this.fifteen_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_16':
        this.sixteen_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_17':
        this.seventeen_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_18':
        this.eighteen_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_19':
        this.nineteen_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_20':
        this.twenty_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_21':
        this.twentyone_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_22':
        this.twentytwo_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_23':
        this.twentythree_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_24':
        this.twentyfour_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
      case 'text_area_25':
        this.twentyfive_text_area_value = this.popup_text_area_value[this.text_index - 1];

        break;
    }

  }


  detectPopupInput(event) {
    this.popup_text_area_value[this.text_index - 1] = event.target.value;
  }
  clearPopupValue(ref) {
    switch (ref) {
      case 'text_area_1':
        this.elementRef.nativeElement.querySelector('#maximized_first_text_area').value = this.first_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.first_text_area_value;
        break;
      case 'text_area_2':
        this.elementRef.nativeElement.querySelector('#maximized_second_text_area').value = this.second_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.second_text_area_value;

        break;
      case 'text_area_3':
        this.elementRef.nativeElement.querySelector('#maximized_third_text_area').value = this.third_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.third_text_area_value;

        break;
      case 'text_area_4':
        this.elementRef.nativeElement.querySelector('#maximized_fourth_text_area').value = this.fourth_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.fourth_text_area_value;

        break;
      case 'text_area_5':
        this.elementRef.nativeElement.querySelector('#maximized_fifth_text_area').value = this.fifth_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.fifth_text_area_value;

        break;
      case 'text_area_6':
        this.elementRef.nativeElement.querySelector('#maximized_sixth_text_area').value = this.sixth_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.sixth_text_area_value;

        break;

      case 'text_area_7':
        this.elementRef.nativeElement.querySelector('#maximized_seventh_text_area').value = this.sevent_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.sevent_text_area_value;


        break;
      case 'text_area_8':
        this.elementRef.nativeElement.querySelector('#maximized_eighth_text_area').value = this.eighth_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.eighth_text_area_value;

        break;
      case 'text_area_9':
        this.elementRef.nativeElement.querySelector('#maximized_ninth_text_area').value = this.ninth_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.ninth_text_area_value;

        break;
      case 'text_area_10':
        this.elementRef.nativeElement.querySelector('#maximized_tenth_text_area').value = this.tenth_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.tenth_text_area_value;

        break;
      case 'text_area_11':
        this.elementRef.nativeElement.querySelector('#maximized_eleventh_text_area').value = this.eleventh_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.eleventh_text_area_value;

        break;
      case 'text_area_12':
        this.elementRef.nativeElement.querySelector('#maximized_tweleve_text_area').value = this.tweleve_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.tweleve_text_area_value;

        break;

      case 'text_area_13':
        this.elementRef.nativeElement.querySelector('#maximized_thirteen_text_area').value = this.thirteen_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.thirteen_text_area_value;

        break;
      case 'text_area_14':
        this.elementRef.nativeElement.querySelector('#maximized_fourteen_text_area').value = this.fourteen_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.fourteen_text_area_value;

        break;
      case 'text_area_15':
        this.elementRef.nativeElement.querySelector('#maximized_fifteen_text_area').value = this.fifteen_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.fifteen_text_area_value;

        break;
      case 'text_area_16':
        this.elementRef.nativeElement.querySelector('#maximized_sixteen_text_area').value = this.sixteen_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.sixteen_text_area_value;

        break;
      case 'text_area_17':
        this.elementRef.nativeElement.querySelector('#maximized_seventeen_text_area').value = this.seventeen_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.seventeen_text_area_value;

        break;
      case 'text_area_18':
        this.elementRef.nativeElement.querySelector('#maximized_eighteen_text_area').value = this.eighteen_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.eighteen_text_area_value;

        break;
      case 'text_area_19':
        this.elementRef.nativeElement.querySelector('#maximized_nineteen_text_area').value = this.nineteen_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.nineteen_text_area_value;


        break;
      case 'text_area_20':
        this.elementRef.nativeElement.querySelector('#maximized_twenty_text_area').value = this.twenty_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.twenty_text_area_value;

        break;
      case 'text_area_21':
        this.elementRef.nativeElement.querySelector('#maximized_twentyone_text_area').value = this.twentyone_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.twentyone_text_area_value;

        break;
      case 'text_area_22':
        this.elementRef.nativeElement.querySelector('#maximized_twentytwo_text_area').value = this.twentytwo_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.twentytwo_text_area_value;

        break;
      case 'text_area_23':
        this.elementRef.nativeElement.querySelector('#maximized_twentythree_text_area').value = this.twentythree_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.twentythree_text_area_value;

        break;
      case 'text_area_24':
        this.elementRef.nativeElement.querySelector('#maximized_twentyfour_text_area').value = this.twentyfour_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.twentyfour_text_area_value;

        break;
      case 'text_area_25':
        this.elementRef.nativeElement.querySelector('#maximized_twentyfive_text_area').value = this.twentyfive_text_area_value;
        this.popup_text_area_value[this.text_index - 1] = this.twentyfive_text_area_value;

        break;

    }

  }

  get popupValue() {
    return this.popup_text_area_value[this.text_index - 1];
  }

  get textareaValue() {

    switch (this.text_index) {

      case 1:
        return this.first_text_area_value;

      case 2:
        return this.second_text_area_value;

      case 3:
        return this.third_text_area_value;

      case 4:
        return this.fourth_text_area_value;

      case 5:
        return this.fifth_text_area_value;

      case 6:
        return this.sixth_text_area_value;

      case 7:
        return this.sevent_text_area_value;

      case 8:
        return this.eighth_text_area_value;

      case 9:
        return this.ninth_text_area_value;

      case 10:
        return this.tenth_text_area_value;

      case 11:
        return this.eleventh_text_area_value;

      case 12:
        return this.tweleve_text_area_value;

      case 13:
        return this.thirteen_text_area_value;

      case 14:
        return this.fourteen_text_area_value;

      case 15:
        return this.fifteen_text_area_value;

      case 16:
        return this.sixteen_text_area_value;

      case 17:
        return this.seventeen_text_area_value;

      case 18:
        return this.eighteen_text_area_value;

      case 19:
        return this.nineteen_text_area_value;

      case 20:
        return this.twenty_text_area_value;


      case 21:
        return this.twentyone_text_area_value;

      case 22:
        return this.twentytwo_text_area_value;

      case 23:
        return this.twentythree_text_area_value;

      case 24:
        return this.twentyfour_text_area_value;

      case 25:
        return this.twentyfive_text_area_value;
    }
  }


  get maximizedTextAreaReference() {
    switch (this.text_index) {

      case 1:
        return 'maximized_first_text_area';

      case 2:
        return 'maximized_second_text_area';

      case 3:
        return 'maximized_third_text_area';

      case 4:
        return 'maximized_fourth_text_area';

      case 5:
        return 'maximized_fifth_text_area';

      case 6:
        return 'maximized_sixth_text_area';

      case 7:
        return 'maximized_seventh_text_area';

      case 8:
        return 'maximized_eighth_text_area';

      case 9:
        return 'maximized_ninth_text_area';

      case 10:
        return 'maximized_tenth_text_area';

      case 11:
        return 'maximized_eleventh_text_area';

      case 12:
        return 'maximized_tweleve_text_area';

      case 13:
        return 'maximized_thirteen_text_area';

      case 14:
        return 'maximized_fourteen_text_area';

      case 15:
        return 'maximized_fifteen_text_area';

      case 16:
        return 'maximized_sixteen_text_area';

      case 17:
        return 'maximized_seventeen_text_area';

      case 18:
        return 'maximized_eighteen_text_area';

      case 19:
        return 'maximized_nineteen_text_area';

      case 20:
        return 'maximized_twenty_text_area';

      case 21:
        return 'maximized_twentyone_text_area';

      case 22:
        return 'maximized_twentytwo_text_area';

      case 23:
        return 'maximized_twentythree_text_area';

      case 24:
        return 'maximized_twentyfour_text_area';

      case 25:
        return 'maximized_twentyfive_text_area';
    }
  }


  get textareaReference() {
    switch (this.text_index) {

      case 1:
        return 'first_text_area';

      case 2:
        return 'second_text_area';

      case 3:
        return 'third_text_area';

      case 4:
        return 'fourth_text_area';

      case 5:
        return 'fifth_text_area';

      case 6:
        return 'sixth_text_area';

      case 7:
        return 'seventh_text_area';

      case 8:
        return 'eighth_text_area';

      case 9:
        return 'ninth_text_area';

      case 10:
        return 'tenth_text_area';

      case 11:
        return 'eleventh_text_area';

      case 12:
        return 'tweleve_text_area';

      case 13:
        return 'thirteen_text_area';

      case 14:
        return 'fourteen_text_area';

      case 15:
        return 'fifteen_text_area';

      case 16:
        return 'sixteen_text_area';

      case 17:
        return 'seventeen_text_area';

      case 18:
        return 'eighteen_text_area';

      case 19:
        return 'nineteen_text_area';

      case 20:
        return 'twenty_text_area';

      case 21:
        return 'twentyone_text_area';

      case 22:
        return 'twentytwo_text_area';

      case 23:
        return 'twentythree_text_area';

      case 24:
        return 'twentyfour_text_area';

      case 25:
        return 'twentyfive_text_area';
    }
  }

  get isPopupEditable() {
    return this.is_Popup_Editable[this.text_index - 1];
  }

  get isTextEditable() {
    switch (this.text_index) {

      case 1:
        return this.is_text_editable1;

      case 2:
        return this.is_text_editable2;

      case 3:
        return this.is_text_editable3;

      case 4:
        return this.is_text_editable4;

      case 5:
        return this.is_text_editable5;

      case 6:
        return this.is_text_editable6;

      case 7:
        return this.is_text_editable7;

      case 8:
        return this.is_text_editable8;

      case 9:
        return this.is_text_editable9;

      case 10:
        return this.is_text_editable10;

      case 11:
        return this.is_text_editable11;

      case 12:
        return this.is_text_editable12;

      case 13:
        return this.is_text_editable13;

      case 14:
        return this.is_text_editable14;

      case 15:
        return this.is_text_editable15;

      case 16:
        return this.is_text_editable16;

      case 17:
        return this.is_text_editable17;

      case 18:
        return this.is_text_editable18;

      case 19:
        return this.is_text_editable19;

      case 20:
        return this.is_text_editable20;

      case 21:
        return this.is_text_editable21;

      case 22:
        return this.is_text_editable22;

      case 23:
        return this.is_text_editable23;

      case 24:
        return this.is_text_editable24;

      case 25:
        return this.is_text_editable25;
    }
  }



  part_index: number = 0;



  counter: number = 0;

  max_text_cloning_reached: boolean;
  firstClickofText: boolean = true;

  first_text_area_start_position: number;
  first_text_area_end_position: number;

  second_text_area_start_position: number;
  second_text_area_end_position: number;

  third_text_area_start_position: number;
  third_text_area_end_position: number;

  fourth_text_area_start_position: number;
  fourth_text_area_end_position: number;

  fifth_text_area_start_position: number;
  fifth_text_area_end_position: number;

  sixth_text_area_start_position: number;
  sixth_text_area_end_position: number;

  seventh_text_area_start_position: number;
  seventh_text_area_end_position: number;

  eighth_text_area_start_position: number;
  eighth_text_area_end_position: number;

  ninth_text_area_start_position: number;
  ninth_text_area_end_position: number;

  tenth_text_area_start_position: number;
  tenth_text_area_end_position: number;

  eleventh_text_area_start_position: number;
  eleventh_text_area_end_position: number;


  tweleve_text_area_start_position: number;
  tweleve_text_area_end_position: number;

  thirteen_text_area_start_position: number;
  thirteen_text_area_end_position: number;

  fourteen_text_area_start_position: number;
  fourteen_text_area_end_position: number;

  fifteen_text_area_start_position: number;
  fifteen_text_area_end_position: number;


  sixteen_text_area_start_position: number;
  sixteen_text_area_end_position: number;

  seventeen_text_area_start_position: number;
  seventeen_text_area_end_position: number;

  eighteen_text_area_start_position: number;
  eighteen_text_area_end_position: number;

  nineteen_text_area_start_position: number;
  nineteen_text_area_end_position: number;

  twenty_text_area_start_position: number;
  twenty_text_area_end_position: number;

  twentyone_text_area_start_position: number;
  twentyone_text_area_end_position: number;

  twentytwo_text_area_start_position: number;
  twentytwo_text_area_end_position: number;

  twentythree_text_area_start_position: number;
  twentythree_text_area_end_position: number;

  twentyfour_text_area_start_position: number;
  twentyfour_text_area_end_position: number;

  twentyfive_text_area_start_position: number;
  twentyfive_text_area_end_position: number;


  isClicked: boolean;
  text_area_position_counter: number = 1;

  is_Popup_Disabled: boolean[] = [];

  @Input('text_area_1_disabled') text_area_1_disabled: boolean;
  @Input('text_area_2_disabled') text_area_2_disabled: boolean;
  @Input('text_area_3_disabled') text_area_3_disabled: boolean;
  @Input('text_area_4_disabled') text_area_4_disabled: boolean;
  @Input('text_area_5_disabled') text_area_5_disabled: boolean;
  @Input('text_area_6_disabled') text_area_6_disabled: boolean;

  @Input('text_area_7_disabled') text_area_7_disabled: boolean;
  @Input('text_area_8_disabled') text_area_8_disabled: boolean;
  @Input('text_area_9_disabled') text_area_9_disabled: boolean;
  @Input('text_area_10_disabled') text_area_10_disabled: boolean;
  @Input('text_area_11_disabled') text_area_11_disabled: boolean;
  @Input('text_area_12_disabled') text_area_12_disabled: boolean;

  @Input('text_area_13_disabled') text_area_13_disabled: boolean;
  @Input('text_area_14_disabled') text_area_14_disabled: boolean;
  @Input('text_area_15_disabled') text_area_15_disabled: boolean;
  @Input('text_area_16_disabled') text_area_16_disabled: boolean;
  @Input('text_area_17_disabled') text_area_17_disabled: boolean;
  @Input('text_area_18_disabled') text_area_18_disabled: boolean;

  @Input('text_area_19_disabled') text_area_19_disabled: boolean;
  @Input('text_area_20_disabled') text_area_20_disabled: boolean;
  @Input('text_area_21_disabled') text_area_21_disabled: boolean;
  @Input('text_area_22_disabled') text_area_22_disabled: boolean;
  @Input('text_area_23_disabled') text_area_23_disabled: boolean;
  @Input('text_area_24_disabled') text_area_24_disabled: boolean;
  @Input('text_area_25_disabled') text_area_25_disabled: boolean;

  @Input('is_text_editable1') is_text_editable1: boolean;
  @Input('is_text_editable2') is_text_editable2: boolean;
  @Input('is_text_editable3') is_text_editable3: boolean;
  @Input('is_text_editable4') is_text_editable4: boolean;
  @Input('is_text_editable5') is_text_editable5: boolean;
  @Input('is_text_editable6') is_text_editable6: boolean;

  @Input('is_text_editable7') is_text_editable7: boolean;
  @Input('is_text_editable8') is_text_editable8: boolean;
  @Input('is_text_editable9') is_text_editable9: boolean;
  @Input('is_text_editable10') is_text_editable10: boolean;
  @Input('is_text_editable11') is_text_editable11: boolean;
  @Input('is_text_editable12') is_text_editable12: boolean;

  @Input('is_text_editable13') is_text_editable13: boolean;
  @Input('is_text_editable14') is_text_editable14: boolean;
  @Input('is_text_editable15') is_text_editable15: boolean;
  @Input('is_text_editable16') is_text_editable16: boolean;
  @Input('is_text_editable17') is_text_editable17: boolean;
  @Input('is_text_editable18') is_text_editable18: boolean;

  @Input('is_text_editable19') is_text_editable19: boolean;
  @Input('is_text_editable20') is_text_editable20: boolean;
  @Input('is_text_editable21') is_text_editable21: boolean;
  @Input('is_text_editable22') is_text_editable22: boolean;
  @Input('is_text_editable23') is_text_editable23: boolean;
  @Input('is_text_editable24') is_text_editable24: boolean;
  @Input('is_text_editable25') is_text_editable25: boolean;

  public compInteraction;



  breakOuter: boolean;

  public parts: FormArray;
  applicabilty: FormGroup;
  separators: string[] = ['.', ':', '\n', ';', '-'];
  parts_string: string;
  tempArr: any[] = [];
  finalArr: any[] = [];


  createAreas(): FormGroup {
    return new FormGroup({
      areaId: new FormControl(''),
      type: new FormControl(''),
      position: new FormControl(''),
      parts: new FormArray([])
    })
  }


  createParts(value, index, type): FormGroup {
    return new FormGroup({
      partId: new FormControl(''),
      type: new FormControl(type),
      position: new FormControl(index++),
      phraseId: new FormControl(''),
      value: new FormControl(value)
    })
  }

  createApplicabiltyParts(): FormGroup {
    return new FormGroup({
      label: new FormControl(''),
      value: new FormControl(''),
      selected: new FormControl('')
    })
  }


  get textAreaName() {
    return 'text_area_' + this.text_index;
  }


  closeTextArea(textarea) {

    let informations = ( < FormArray > this.form.controls['informations']);
    let areas = informations.at(0).get('areas') as FormArray;

    for (let i = 0; i < areas.length; i++) {
      if (areas.at(i).get('textarea_no').value == this.text_index) {
        areas.removeAt(i);
      }
    }
    this.compInteraction.removeComponent(this.text_index);

  }


  seperatorArr: string[] = [];

  processTextForSeparator(text_area_value) {
    let str = text_area_value;
    let i;
    let substringResult = "";
    let type;
    let positionCounter = 1;
    let value = "";
    let position;
    let text = str.split(/(?=@)/g);
    let newParts = new FormArray([]);

    for (i = 0; i < text.length; i++) {

      if (text[i].indexOf('@S#') > -1 && (text[i].indexOf('#') !== text[i].lastIndexOf('#'))) {

        let textBetweenValue = text[i].split('@S#').pop().split('#')[0];
        substringResult = substringResult + '$~' + textBetweenValue;
        let textAfterValue = text[i].split('@S#').pop().split('#')[1];
        substringResult = substringResult + '$' + textAfterValue;

      } else if (text[i].indexOf('@D#') > -1 && (text[i].indexOf('#') !== text[i].lastIndexOf('#'))
        && text[i].indexOf('||') > -1
      ) {

        let textBetweenValue = text[i].split('@D#').pop().split('#')[0];
        substringResult = substringResult + '$&^&^&' + textBetweenValue;
        let textAfterValue = text[i].split('@D#').pop().split('#')[1];
        substringResult = substringResult + '$' + textAfterValue;

      }
      else {
        substringResult = substringResult + '' + text[i];
      }
    }

    let finalResult = substringResult.split('$');
    finalResult = finalResult.filter(function(e){return e}); 

    for (i = 0; i < finalResult.length; i++) {

      if (finalResult[i].indexOf('~') > -1) {
        value = '@S#' + finalResult[i].substring(1, (finalResult[i].length)) + '#';
        position = i + 1;
        if (this.separator_colon == value || this.separator_dash == value || this.separator_dot == value || this.separator_rc == value || this.separator_semicolon == value) {
          type = 'separator';
        } else {
          type = 'userseparator';
        }
      } else if(finalResult[i].indexOf('&^&^&') > -1) {
        value = '@D#' + finalResult[i].substring(5, (finalResult[i].length)) + '#';
        position = i + 1;
        type = "docref"
      }else {
        type = 'text';
        value = finalResult[i];
        position = i + 1;
      }

      if (!this.isInValid(value)) {
     
        if (this.parts.length > 0) {

          for (let k = 0; k < this.parts.length; k++) {

            let partValue = this.parts.at(k).value.value ? this.parts.at(k).value.value.toString().trim() : '';
            let enteredValue = value.toString().trim();

               if (partValue === enteredValue) {
                this.parts.at(k).get('position').setValue(positionCounter);
                this.parts.at(k).get('type').setValue(type);
                this.parts.at(k).get('value').setValue(value.toString());
                newParts.push(this.parts.at(k));
                this.parts.removeAt(k);
                positionCounter++;
                break;

              } else if (partValue !== enteredValue && k == Number(this.parts.length - 1)) {

                newParts.push(this.createParts(value, positionCounter, type));
                positionCounter++;
                break;
              }
            

          }

        } 
        else {
          newParts.push(this.createParts(value, position, type));
        }

      }

      value = "";
    }

    while (this.parts.length) {
      this.parts.removeAt(0);
    }
    for (let part = 0; part < newParts.length; part++) {
      this.parts.push(newParts.at(part))
    }
   
  }



  addnewPart(target) {

    this.finalArr = [];
    this.tempArr = [];

    let informations = ( < FormArray > this.form.controls['informations']);
    let areas = informations.at(0).get('areas') as FormArray;

    for (let i = 0; i < areas.length; i++) {
      if (areas.at(i).get('textarea_no').value == this.text_index) {
        this.parts = areas.at(i).get('parts') as FormArray;
      }
    }

    switch (target) {

      case 'text_area_1':

        this.tempArr = this.first_text_area_value.split(' ');

        this.processTextForSeparator(this.first_text_area_value);
        
        this.elementRef.nativeElement.querySelector('#first_text_area').scrollTop = 0;

        break;

      case 'text_area_2':

        this.tempArr = this.second_text_area_value.split(' ');

        this.processTextForSeparator(this.second_text_area_value);
        this.elementRef.nativeElement.querySelector('#second_text_area').scrollTop = 0;

        break;
      case 'text_area_3':

        this.tempArr = this.third_text_area_value.split(' ');

        this.processTextForSeparator(this.third_text_area_value);
        this.elementRef.nativeElement.querySelector('#third_text_area').scrollTop = 0;

        break;
      case 'text_area_4':

        this.tempArr = this.fourth_text_area_value.split(' ');

        this.processTextForSeparator(this.fourth_text_area_value);
        this.elementRef.nativeElement.querySelector('#fourth_text_area').scrollTop = 0;

        break;
      case 'text_area_5':

        this.tempArr = this.fifth_text_area_value.split(' ');

        this.processTextForSeparator(this.fifth_text_area_value);
        this.elementRef.nativeElement.querySelector('#fifth_text_area').scrollTop = 0;

        break;
      case 'text_area_6':

        this.tempArr = this.sixth_text_area_value.split(' ');

        this.processTextForSeparator(this.sixth_text_area_value);
        this.elementRef.nativeElement.querySelector('#sixth_text_area').scrollTop = 0;

        break;

      case 'text_area_7':

        this.tempArr = this.sevent_text_area_value.split(' ');

        this.processTextForSeparator(this.sevent_text_area_value);
        this.elementRef.nativeElement.querySelector('#seventh_text_area').scrollTop = 0;

        break;

      case 'text_area_8':


        this.tempArr = this.eighth_text_area_value.split(' ');

        this.processTextForSeparator(this.eighth_text_area_value);
        this.elementRef.nativeElement.querySelector('#eighth_text_area').scrollTop = 0;

        break;

      case 'text_area_9':


        this.tempArr = this.ninth_text_area_value.split(' ');

        this.processTextForSeparator(this.ninth_text_area_value);
        this.elementRef.nativeElement.querySelector('#ninth_text_area').scrollTop = 0;

        break;

      case 'text_area_10':


        this.tempArr = this.tenth_text_area_value.split(' ');

        this.processTextForSeparator(this.tenth_text_area_value);
        this.elementRef.nativeElement.querySelector('#tenth_text_area').scrollTop = 0;

        break;

      case 'text_area_11':

        this.tempArr = this.eleventh_text_area_value.split(' ');

        this.processTextForSeparator(this.eleventh_text_area_value);
        this.elementRef.nativeElement.querySelector('#eleventh_text_area').scrollTop = 0;

        break;

      case 'text_area_12':


        this.tempArr = this.tweleve_text_area_value.split(' ');

        this.processTextForSeparator(this.tweleve_text_area_value);
        this.elementRef.nativeElement.querySelector('#tweleve_text_area').scrollTop = 0;

        break;

      case 'text_area_13':


        this.tempArr = this.thirteen_text_area_value.split(' ');

        this.processTextForSeparator(this.thirteen_text_area_value);
        this.elementRef.nativeElement.querySelector('#thirteen_text_area').scrollTop = 0;

        break;

      case 'text_area_14':

        this.tempArr = this.fourteen_text_area_value.split(' ');

        this.processTextForSeparator(this.fourteen_text_area_value);
        this.elementRef.nativeElement.querySelector('#fourteen_text_area').scrollTop = 0;

        break;

      case 'text_area_15':


        this.tempArr = this.fifteen_text_area_value.split(' ');

        this.processTextForSeparator(this.fifteen_text_area_value);
        this.elementRef.nativeElement.querySelector('#fifteen_text_area').scrollTop = 0;

        break;

      case 'text_area_16':


        this.tempArr = this.sixteen_text_area_value.split(' ');

        this.processTextForSeparator(this.sixteen_text_area_value);
        this.elementRef.nativeElement.querySelector('#sixteen_text_area').scrollTop = 0;

        break;

      case 'text_area_17':


        this.tempArr = this.seventeen_text_area_value.split(' ');

        this.processTextForSeparator(this.seventeen_text_area_value);
        this.elementRef.nativeElement.querySelector('#seventeen_text_area').scrollTop = 0;

        break;

      case 'text_area_18':


        this.tempArr = this.eighteen_text_area_value.split(' ');

        this.processTextForSeparator(this.eighteen_text_area_value);
        this.elementRef.nativeElement.querySelector('#eighteen_text_area').scrollTop = 0;

        break;

      case 'text_area_19':


        this.tempArr = this.nineteen_text_area_value.split(' ');

        this.processTextForSeparator(this.nineteen_text_area_value);
        this.elementRef.nativeElement.querySelector('#nineteen_text_area').scrollTop = 0;

        break;

      case 'text_area_20':

        this.tempArr = this.twenty_text_area_value.split(' ');

        this.processTextForSeparator(this.twenty_text_area_value);
        this.elementRef.nativeElement.querySelector('#twenty_text_area').scrollTop = 0;

        break;

      case 'text_area_21':


        this.tempArr = this.twentyone_text_area_value.split(' ');

        this.processTextForSeparator(this.twentyone_text_area_value);
        this.elementRef.nativeElement.querySelector('#twentyone_text_area').scrollTop = 0;

        break;

      case 'text_area_22':


        this.tempArr = this.twentytwo_text_area_value.split(' ');

        this.processTextForSeparator(this.twentytwo_text_area_value);
        this.elementRef.nativeElement.querySelector('#twentytwo_text_area').scrollTop = 0;

        break;

      case 'text_area_23':


        this.tempArr = this.twentythree_text_area_value.split(' ');

        this.processTextForSeparator(this.twentythree_text_area_value);
        this.elementRef.nativeElement.querySelector('#twentythree_text_area').scrollTop = 0;

        break;

      case 'text_area_24':

        this.tempArr = this.twentyfour_text_area_value.split(' ');

        this.processTextForSeparator(this.twentyfour_text_area_value);
        this.elementRef.nativeElement.querySelector('#twentyfour_text_area').scrollTop = 0;

        break;

      case 'text_area_25':


        this.tempArr = this.twentyfive_text_area_value.split(' ');

        this.processTextForSeparator(this.twentyfive_text_area_value);
        this.elementRef.nativeElement.querySelector('#twentyfive_text_area').scrollTop = 0;
        break;
    }
    console.log(JSON.stringify(this.parts.value))
  }


  enterText(separator, text_area, popup ? : boolean) {


    switch (text_area) {

      case 'text_area_1':
        if (this.first_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_first_text_area' : '#first_text_area');
          this.first_text_area_start_position = ref.selectionStart;
          this.first_text_area_end_position = ref.selectionEnd;


          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.first_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.first_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.first_text_area_value = this.first_text_area_value.substring(0, this.first_text_area_start_position) + separator + this.first_text_area_value.substring(this.first_text_area_end_position, this.first_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.first_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.first_text_area_value;
          ref.focus();
          ref.selectionEnd = this.first_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_2':
        if (this.second_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_second_text_area' : '#second_text_area');
          this.second_text_area_start_position = ref.selectionStart;
          this.second_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.second_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.second_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.second_text_area_value = this.second_text_area_value.substring(0, this.second_text_area_start_position) + separator + this.second_text_area_value.substring(this.second_text_area_end_position, this.second_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.second_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.second_text_area_value;
          ref.focus();
          ref.selectionEnd = this.second_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;

        }
        break;

      case 'text_area_3':
        if (this.third_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_third_text_area' : '#third_text_area');
          this.third_text_area_start_position = ref.selectionStart;
          this.third_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.third_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.third_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.third_text_area_value = this.third_text_area_value.substring(0, this.third_text_area_start_position) + separator + this.third_text_area_value.substring(this.third_text_area_end_position, this.third_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.third_text_area_value;

          }

          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.third_text_area_value;
          ref.focus();
          ref.selectionEnd = this.third_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_4':
        if (this.fourth_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fourth_text_area' : '#fourth_text_area');
          this.fourth_text_area_start_position = ref.selectionStart;
          this.fourth_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.fourth_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.fourth_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.fourth_text_area_value = this.fourth_text_area_value.substring(0, this.fourth_text_area_start_position) + separator + this.fourth_text_area_value.substring(this.fourth_text_area_end_position, this.fourth_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.fourth_text_area_value;

          }

          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.fourth_text_area_value;
          ref.focus();
          ref.selectionEnd = this.fourth_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_5':
        if (this.fifth_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fifth_text_area' : '#fifth_text_area');
          this.fifth_text_area_start_position = ref.selectionStart;
          this.fifth_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.fifth_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.fifth_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.fifth_text_area_value = this.fifth_text_area_value.substring(0, this.fifth_text_area_start_position) + separator + this.fifth_text_area_value.substring(this.fifth_text_area_end_position, this.fifth_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.fifth_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.fifth_text_area_value;
          ref.focus();
          ref.selectionEnd = this.fifth_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_6':
        if (this.sixth_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_sixth_text_area' : '#sixth_text_area');
          this.sixth_text_area_start_position = ref.selectionStart;
          this.sixth_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.sixth_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.sixth_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.sixth_text_area_value = this.sixth_text_area_value.substring(0, this.sixth_text_area_start_position) + separator + this.sixth_text_area_value.substring(this.sixth_text_area_end_position, this.sixth_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.sixth_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.sixth_text_area_value;
          ref.focus();
          ref.selectionEnd = this.sixth_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_7':
        if (this.sevent_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_seventh_text_area' : '#seventh_text_area');
          this.seventh_text_area_start_position = ref.selectionStart;
          this.seventh_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.seventh_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.seventh_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.sevent_text_area_value = this.sevent_text_area_value.substring(0, this.seventh_text_area_start_position) + separator + this.sevent_text_area_value.substring(this.seventh_text_area_end_position, this.sevent_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.sevent_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.sevent_text_area_value;
          ref.focus();
          ref.selectionEnd = this.seventh_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_8':
        if (this.eighth_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_eighth_text_area' : '#eighth_text_area');
          this.eighth_text_area_start_position = ref.selectionStart;
          this.eighth_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.eighth_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.eighth_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.eighth_text_area_value = this.eighth_text_area_value.substring(0, this.eighth_text_area_start_position) + separator + this.eighth_text_area_value.substring(this.eighth_text_area_end_position, this.eighth_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.eighth_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.eighth_text_area_value;
          ref.focus();
          ref.selectionEnd = this.eighth_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;

        }
        break;

      case 'text_area_9':
        if (this.ninth_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_ninth_text_area' : '#ninth_text_area');
          this.ninth_text_area_start_position = ref.selectionStart;
          this.ninth_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.ninth_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.ninth_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.ninth_text_area_value = this.ninth_text_area_value.substring(0, this.ninth_text_area_start_position) + separator + this.ninth_text_area_value.substring(this.ninth_text_area_end_position, this.ninth_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.ninth_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.ninth_text_area_value;
          ref.focus();
          ref.selectionEnd = this.ninth_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_10':
        if (this.tenth_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_tenth_text_area' : '#tenth_text_area');
          this.tenth_text_area_start_position = ref.selectionStart;
          this.tenth_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.tenth_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.tenth_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.tenth_text_area_value = this.tenth_text_area_value.substring(0, this.tenth_text_area_start_position) + separator + this.tenth_text_area_value.substring(this.tenth_text_area_end_position, this.tenth_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.tenth_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.tenth_text_area_value;
          ref.focus();
          ref.selectionEnd = this.tenth_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_11':
        if (this.eleventh_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_eleventh_text_area' : '#eleventh_text_area');
          this.eleventh_text_area_start_position = ref.selectionStart;
          this.eleventh_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.eleventh_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.eleventh_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.eleventh_text_area_value = this.eleventh_text_area_value.substring(0, this.eleventh_text_area_start_position) + separator + this.eleventh_text_area_value.substring(this.eleventh_text_area_end_position, this.eleventh_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.eleventh_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.eleventh_text_area_value;
          ref.focus();
          ref.selectionEnd = this.eleventh_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_12':
        if (this.tweleve_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_tweleve_text_area' : '#tweleve_text_area');
          this.tweleve_text_area_start_position = ref.selectionStart;
          this.tweleve_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.tweleve_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.tweleve_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.tweleve_text_area_value = this.tweleve_text_area_value.substring(0, this.tweleve_text_area_start_position) + separator + this.tweleve_text_area_value.substring(this.tweleve_text_area_end_position, this.tweleve_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.tweleve_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.tweleve_text_area_value;
          ref.focus();
          ref.selectionEnd = this.tweleve_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_13':
        if (this.thirteen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_thirteen_text_area' : '#thirteen_text_area');
          this.thirteen_text_area_start_position = ref.selectionStart;
          this.thirteen_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.thirteen_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.thirteen_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.thirteen_text_area_value = this.thirteen_text_area_value.substring(0, this.thirteen_text_area_start_position) + separator + this.thirteen_text_area_value.substring(this.thirteen_text_area_end_position, this.thirteen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.thirteen_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.thirteen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.thirteen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_14':
        if (this.fourteen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fourteen_text_area' : '#fourteen_text_area');
          this.fourteen_text_area_start_position = ref.selectionStart;
          this.fourteen_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.fourteen_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.fourteen_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.fourteen_text_area_value = this.fourteen_text_area_value.substring(0, this.fourteen_text_area_start_position) + separator + this.fourteen_text_area_value.substring(this.fourteen_text_area_end_position, this.fourteen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.fourteen_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.fourteen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.fourteen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_15':
        if (this.fifteen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fifteen_text_area' : '#fifteen_text_area');
          this.fifteen_text_area_start_position = ref.selectionStart;
          this.fifteen_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.fifteen_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.fifteen_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.fifteen_text_area_value = this.fifteen_text_area_value.substring(0, this.fifteen_text_area_start_position) + separator + this.fifteen_text_area_value.substring(this.fifteen_text_area_end_position, this.fifteen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.fifteen_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.fifteen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.fifteen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_16':
        if (this.sixteen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_sixteen_text_area' : '#sixteen_text_area');
          this.sixteen_text_area_start_position = ref.selectionStart;
          this.sixteen_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.sixteen_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.sixteen_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.sixteen_text_area_value = this.sixteen_text_area_value.substring(0, this.sixteen_text_area_start_position) + separator + this.sixteen_text_area_value.substring(this.sixteen_text_area_end_position, this.sixteen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.sixteen_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.sixteen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.sixteen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_17':
        if (this.seventeen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_seventeen_text_area' : '#seventeen_text_area');
          this.seventeen_text_area_start_position = ref.selectionStart;
          this.seventeen_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.seventeen_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.seventeen_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.seventeen_text_area_value = this.seventeen_text_area_value.substring(0, this.seventeen_text_area_start_position) + separator + this.seventeen_text_area_value.substring(this.seventeen_text_area_end_position, this.seventeen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.seventeen_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.seventeen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.seventeen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_18':
        if (this.eighteen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_eighteen_text_area' : '#eighteen_text_area');
          this.eighteen_text_area_start_position = ref.selectionStart;
          this.eighteen_text_area_end_position = ref.selectionEnd;
          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.eighteen_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.eighteen_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.eighteen_text_area_value = this.eighteen_text_area_value.substring(0, this.eighteen_text_area_start_position) + separator + this.eighteen_text_area_value.substring(this.eighteen_text_area_end_position, this.eighteen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.eighteen_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.eighteen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.eighteen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_19':
        if (this.nineteen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_nineteen_text_area' : '#nineteen_text_area');
          this.nineteen_text_area_start_position = ref.selectionStart;
          this.nineteen_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.nineteen_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.ninth_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.nineteen_text_area_value = this.nineteen_text_area_value.substring(0, this.nineteen_text_area_start_position) + separator + this.nineteen_text_area_value.substring(this.ninth_text_area_end_position, this.nineteen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.nineteen_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.nineteen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.nineteen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_20':
        if (this.twenty_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twenty_text_area' : '#twenty_text_area');
          this.twenty_text_area_start_position = ref.selectionStart;
          this.twenty_text_area_end_position = ref.selectionEnd;
          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.twenty_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.twenty_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.twenty_text_area_value = this.twenty_text_area_value.substring(0, this.twenty_text_area_start_position) + separator + this.twenty_text_area_value.substring(this.twenty_text_area_end_position, this.twenty_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.twenty_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.twenty_text_area_value;
          ref.focus();
          ref.selectionEnd = this.twenty_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_21':
        if (this.twentyone_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentyone_text_area' : '#twentyone_text_area');
          this.twentyone_text_area_start_position = ref.selectionStart;
          this.twentyone_text_area_end_position = ref.selectionEnd;
          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.twentyfive_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.twentyone_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.twentyone_text_area_value = this.twentyone_text_area_value.substring(0, this.twentyfive_text_area_start_position) + separator + this.twentyone_text_area_value.substring(this.twentyone_text_area_end_position, this.twentyone_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.twentyone_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.twentyone_text_area_value;
          ref.focus();
          ref.selectionEnd = this.twentyone_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_22':
        if (this.twentytwo_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentytwo_text_area' : '#twentytwo_text_area');
          this.twentytwo_text_area_start_position = ref.selectionStart;
          this.twentytwo_text_area_end_position = ref.selectionEnd;
          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.twentytwo_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.twentytwo_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.twentytwo_text_area_value = this.twentytwo_text_area_value.substring(0, this.twentytwo_text_area_start_position) + separator + this.twentytwo_text_area_value.substring(this.twentytwo_text_area_end_position, this.twentytwo_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.twentytwo_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.twentytwo_text_area_value;
          ref.focus();
          ref.selectionEnd = this.twentytwo_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_23':
        if (this.twentythree_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentythree_text_area' : '#twentythree_text_area');
          this.twentythree_text_area_start_position = ref.selectionStart;
          this.twentythree_text_area_end_position = ref.selectionEnd;
          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.twentythree_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.twentythree_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.twentythree_text_area_value = this.twentythree_text_area_value.substring(0, this.twentythree_text_area_start_position) + separator + this.twentythree_text_area_value.substring(this.twentythree_text_area_end_position, this.twentythree_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.twentythree_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.twentythree_text_area_value;
          ref.focus();
          ref.selectionEnd = this.twentythree_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_24':
        if (this.twentyfour_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentyfour_text_area' : '#twentyfour_text_area');
          this.twentyfour_text_area_start_position = ref.selectionStart;
          this.twentyfour_text_area_end_position = ref.selectionEnd;
          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.twentyfour_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.twentyfour_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.twentyfour_text_area_value = this.twentyfour_text_area_value.substring(0, this.twentyfour_text_area_start_position) + separator + this.twentyfour_text_area_value.substring(this.twentyfour_text_area_end_position, this.twentyfour_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.twentyfour_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.twentyfour_text_area_value;
          ref.focus();
          ref.selectionEnd = this.twentyfour_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

      case 'text_area_25':
        if (this.twentyfive_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentyfive_text_area' : '#twentyfive_text_area');
          this.twentyfive_text_area_start_position = ref.selectionStart;
          this.twentyfive_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] = this.popup_text_area_value[this.text_index - 1].substring(0, this.twentyfive_text_area_start_position) + separator + this.popup_text_area_value[this.text_index - 1].substring(this.twentyfive_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.twentyfive_text_area_value = this.twentyfive_text_area_value.substring(0, this.twentyfive_text_area_start_position) + separator + this.twentyfive_text_area_value.substring(this.twentyfive_text_area_end_position, this.twentyfive_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.twentyfive_text_area_value;

          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.twentyfive_text_area_value;
          ref.focus();
          ref.selectionEnd = this.twentyfive_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
        }
        break;

    }
  }

  editPopuArea() {
    this.selectedText = '';
    this.is_Popup_Editable[this.text_index - 1] = true;
    this.is_Popup_Disabled[this.text_index - 1] = false;
  }

  editTextArea(target) {

    switch (target) {
      case 'text_area_1':
        this.text_area_1_disabled = false;
        this.is_text_editable1 = true;
        break;
      case 'text_area_2':
        this.text_area_2_disabled = false;
        this.is_text_editable2 = true;
        break;
      case 'text_area_3':
        this.text_area_3_disabled = false;
        this.is_text_editable3 = true;
        break;
      case 'text_area_4':
        this.text_area_4_disabled = false;
        this.is_text_editable4 = true;
        break;
      case 'text_area_5':
        this.text_area_5_disabled = false;
        this.is_text_editable5 = true;
        break;
      case 'text_area_6':
        this.text_area_6_disabled = false;
        this.is_text_editable6 = true;
        break;

      case 'text_area_7':
        this.text_area_7_disabled = false;
        this.is_text_editable7 = true;
        break;
      case 'text_area_8':
        this.text_area_8_disabled = false;
        this.is_text_editable8 = true;
        break;
      case 'text_area_9':
        this.text_area_9_disabled = false;
        this.is_text_editable9 = true;
        break;
      case 'text_area_10':
        this.text_area_10_disabled = false;
        this.is_text_editable10 = true;
        break;
      case 'text_area_11':
        this.text_area_11_disabled = false;
        this.is_text_editable11 = true;
        break;
      case 'text_area_12':
        this.text_area_12_disabled = false;
        this.is_text_editable12 = true;
        break;

      case 'text_area_13':
        this.text_area_13_disabled = false;
        this.is_text_editable13 = true;
        break;
      case 'text_area_14':
        this.text_area_14_disabled = false;
        this.is_text_editable14 = true;
        break;
      case 'text_area_15':
        this.text_area_15_disabled = false;
        this.is_text_editable15 = true;
        break;
      case 'text_area_16':
        this.text_area_16_disabled = false;
        this.is_text_editable16 = true;
        break;
      case 'text_area_17':
        this.text_area_17_disabled = false;
        this.is_text_editable17 = true;
        break;
      case 'text_area_18':
        this.text_area_18_disabled = false;
        this.is_text_editable18 = true;
        break;
      case 'text_area_19':
        this.text_area_19_disabled = false;
        this.is_text_editable19 = true;
        break;
      case 'text_area_20':
        this.text_area_20_disabled = false;
        this.is_text_editable20 = true;
        break;
      case 'text_area_21':
        this.text_area_21_disabled = false;
        this.is_text_editable21 = true;
        break;
      case 'text_area_22':
        this.text_area_22_disabled = false;
        this.is_text_editable22 = true;
        break;
      case 'text_area_23':
        this.text_area_23_disabled = false;
        this.is_text_editable23 = true;
        break;
      case 'text_area_24':
        this.text_area_24_disabled = false;
        this.is_text_editable24 = true;
        break;
      case 'text_area_25':
        this.text_area_25_disabled = false;
        this.is_text_editable25 = true;
        break;

    }


  }

  disablePopupEdit() {
    this.is_Popup_Disabled[this.text_index - 1] = true
    this.is_Popup_Editable[this.text_index - 1] = false;
  }

  disableEdit(target) {
    switch (target) {
      case 'text_area_1':
        this.text_area_1_disabled = true;
        this.is_text_editable1 = false;
        break;
      case 'text_area_2':
        this.text_area_2_disabled = true;
        this.is_text_editable2 = false;

        break;
      case 'text_area_3':
        this.text_area_3_disabled = true;
        this.is_text_editable3 = false;

        break;
      case 'text_area_4':
        this.text_area_4_disabled = true;
        this.is_text_editable4 = false;

        break;
      case 'text_area_5':
        this.text_area_5_disabled = true;
        this.is_text_editable5 = false;

        break;
      case 'text_area_6':
        this.text_area_6_disabled = true;
        this.is_text_editable6 = false;
        break;

      case 'text_area_7':
        this.text_area_7_disabled = true;
        this.is_text_editable7 = false;
        break;
      case 'text_area_8':
        this.text_area_8_disabled = true;
        this.is_text_editable8 = false;
        break;
      case 'text_area_9':
        this.text_area_9_disabled = true;
        this.is_text_editable9 = false;
        break;
      case 'text_area_10':
        this.text_area_10_disabled = true;
        this.is_text_editable10 = false;
        break;
      case 'text_area_11':
        this.text_area_11_disabled = true;
        this.is_text_editable11 = false;
        break;
      case 'text_area_12':
        this.text_area_12_disabled = true;
        this.is_text_editable12 = false;
        break;

      case 'text_area_13':
        this.text_area_13_disabled = true;
        this.is_text_editable13 = false;
        break;
      case 'text_area_14':
        this.text_area_14_disabled = true;
        this.is_text_editable14 = false;
        break;
      case 'text_area_15':
        this.text_area_15_disabled = true;
        this.is_text_editable15 = false;
        break;
      case 'text_area_16':
        this.text_area_16_disabled = true;
        this.is_text_editable16 = false;
        break;
      case 'text_area_17':
        this.text_area_17_disabled = true;
        this.is_text_editable17 = false;
        break;
      case 'text_area_18':
        this.text_area_18_disabled = true;
        this.is_text_editable18 = false;
        break;
      case 'text_area_19':
        this.text_area_19_disabled = true;
        this.is_text_editable19 = false;

        break;
      case 'text_area_20':
        this.text_area_20_disabled = true;
        this.is_text_editable20 = false;
        break;
      case 'text_area_21':
        this.text_area_21_disabled = true;
        this.is_text_editable21 = false;
        break;
      case 'text_area_22':
        this.text_area_22_disabled = true;
        this.is_text_editable22 = false;
        break;
      case 'text_area_23':
        this.text_area_23_disabled = true;
        this.is_text_editable23 = false;
        break;
      case 'text_area_24':
        this.text_area_24_disabled = true;
        this.is_text_editable24 = false;
        break;
      case 'text_area_25':
        this.text_area_25_disabled = true;
        this.is_text_editable25 = false;
        break;

    }

  }
  renderSelectedText(text_area, popup ? : boolean) {

    switch (text_area) {

      case 'text_area_1':
        this.first_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_first_text_area' : '#first_text_area').selectionStart;
        this.first_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_first_text_area' : '#first_text_area').selectionEnd;
        if (popup) {
          this.selectedText =
            this.popup_text_area_value[this.text_index - 1].substring(this.first_text_area_start_position, this.first_text_area_end_position);
        } else {
          this.selectedText = this.first_text_area_value.substring(this.first_text_area_start_position, this.first_text_area_end_position);
        }
        break;

      case 'text_area_2':
        this.second_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_second_text_area' : '#second_text_area').selectionStart;
        this.second_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_second_text_area' : '#second_text_area').selectionEnd;
        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.second_text_area_start_position, this.second_text_area_end_position);
        } else {
          this.selectedText = this.second_text_area_value.substring(this.second_text_area_start_position, this.second_text_area_end_position);
        }
        break;

      case 'text_area_3':
        this.third_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_third_text_area' : '#third_text_area').selectionStart;
        this.third_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_third_text_area' : '#third_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.third_text_area_start_position, this.third_text_area_end_position);
        } else {
          this.selectedText = this.third_text_area_value.substring(this.third_text_area_start_position, this.third_text_area_end_position);
        }
        break;

      case 'text_area_4':
        this.fourth_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fourth_text_area' : '#fourth_text_area').selectionStart;
        this.fourth_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fourth_text_area' : '#fourth_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.fourth_text_area_start_position, this.fourth_text_area_end_position);
        } else {
          this.selectedText = this.fourth_text_area_value.substring(this.fourth_text_area_start_position, this.fourth_text_area_end_position);
        }
        break;

      case 'text_area_5':
        this.fifth_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fifth_text_area' : '#fifth_text_area').selectionStart;
        this.fifth_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fifth_text_area' : '#fifth_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.fifth_text_area_start_position, this.fifth_text_area_end_position);
        } else {
          this.selectedText = this.fifth_text_area_value.substring(this.fifth_text_area_start_position, this.fifth_text_area_end_position);
        }
        break;

      case 'text_area_6':
        this.sixth_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_sixth_text_area' : '#sixth_text_area').selectionStart;
        this.sixth_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_sixth_text_area' : '#sixth_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.sixth_text_area_start_position, this.sixth_text_area_end_position);
        } else {
          this.selectedText = this.sixth_text_area_value.substring(this.sixth_text_area_start_position, this.sixth_text_area_end_position);
        }
        break;

      case 'text_area_7':
        this.seventh_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_seventh_text_area' : '#seventh_text_area').selectionStart;
        this.seventh_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_seventh_text_area' : '#seventh_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.seventh_text_area_start_position, this.seventh_text_area_end_position);
        } else {
          this.selectedText = this.sevent_text_area_value.substring(this.seventh_text_area_start_position, this.seventh_text_area_end_position);
        }
        break;

      case 'text_area_8':
        this.eighth_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_eighth_text_area' : '#eighth_text_area').selectionStart;
        this.eighth_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_eighth_text_area' : '#eighth_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.eighth_text_area_start_position, this.eighth_text_area_end_position);
        } else {
          this.selectedText = this.eighth_text_area_value.substring(this.eighth_text_area_start_position, this.eighth_text_area_end_position);
        }
        break;

      case 'text_area_9':
        this.ninth_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_ninth_text_area' : '#ninth_text_area').selectionStart;
        this.ninth_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_ninth_text_area' : '#ninth_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.ninth_text_area_start_position, this.ninth_text_area_end_position);
        } else {
          this.selectedText = this.ninth_text_area_value.substring(this.ninth_text_area_start_position, this.ninth_text_area_end_position);
        }
        break;

      case 'text_area_10':
        this.tenth_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_tenth_text_area' : '#tenth_text_area').selectionStart;
        this.tenth_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_tenth_text_area' : '#tenth_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.tenth_text_area_start_position, this.tenth_text_area_end_position);
        } else {
          this.selectedText = this.tenth_text_area_value.substring(this.tenth_text_area_start_position, this.tenth_text_area_end_position);
        }
        break;

      case 'text_area_11':
        this.eleventh_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_eleventh_text_area' : '#eleventh_text_area').selectionStart;
        this.eleventh_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_eleventh_text_area' : '#eleventh_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.eleventh_text_area_start_position, this.eleventh_text_area_end_position);
        } else {
          this.selectedText = this.eleventh_text_area_value.substring(this.eleventh_text_area_start_position, this.eleventh_text_area_end_position);
        }
        break;

      case 'text_area_12':
        this.tweleve_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_tweleve_text_area' : '#tweleve_text_area').selectionStart;
        this.tweleve_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_tweleve_text_area' : '#tweleve_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.tweleve_text_area_start_position, this.tweleve_text_area_end_position);
        } else {
          this.selectedText = this.tweleve_text_area_value.substring(this.tweleve_text_area_start_position, this.tweleve_text_area_end_position);
        }
        break;

      case 'text_area_13':
        this.thirteen_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_thirteen_text_area' : '#thirteen_text_area').selectionStart;
        this.thirteen_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_thirteen_text_area' : '#thirteen_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.thirteen_text_area_start_position, this.thirteen_text_area_end_position);
        } else {
          this.selectedText = this.thirteen_text_area_value.substring(this.thirteen_text_area_start_position, this.thirteen_text_area_end_position);
        }
        break;

      case 'text_area_14':
        this.fourteen_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fourteen_text_area' : '#fourteen_text_area').selectionStart;
        this.fourteen_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fourteen_text_area' : '#fourteen_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.fourteen_text_area_start_position, this.fourteen_text_area_end_position);
        } else {
          this.selectedText = this.fourteen_text_area_value.substring(this.fourteen_text_area_start_position, this.fourteen_text_area_end_position);
        }
        break;

      case 'text_area_15':
        this.fifteen_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fifteen_text_area' : '#fifteen_text_area').selectionStart;
        this.fifteen_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fifteen_text_area' : '#fifteen_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.fifteen_text_area_start_position, this.fifteen_text_area_end_position);
        } else {
          this.selectedText = this.fifteen_text_area_value.substring(this.fifteen_text_area_start_position, this.fifteen_text_area_end_position);
        }
        break;

      case 'text_area_16':
        this.sixteen_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_sixteen_text_area' : '#sixteen_text_area').selectionStart;
        this.sixteen_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_sixteen_text_area' : '#sixteen_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.sixteen_text_area_start_position, this.sixteen_text_area_end_position);
        } else {
          this.selectedText = this.sixteen_text_area_value.substring(this.sixteen_text_area_start_position, this.sixteen_text_area_end_position);
        }
        break;

      case 'text_area_17':
        this.seventeen_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_seventeen_text_area' : '#seventeen_text_area').selectionStart;
        this.seventeen_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_seventeen_text_area' : '#seventeen_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.seventeen_text_area_start_position, this.seventeen_text_area_end_position);
        } else {
          this.selectedText = this.seventeen_text_area_value.substring(this.seventeen_text_area_start_position, this.seventeen_text_area_end_position);
        }
        break;

      case 'text_area_18':
        this.eighteen_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_eighteen_text_area' : '#eighteen_text_area').selectionStart;
        this.eighteen_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_eighteen_text_area' : '#eighteen_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.eighteen_text_area_start_position, this.eighteen_text_area_end_position);
        } else {
          this.selectedText = this.eighteen_text_area_value.substring(this.eighteen_text_area_start_position, this.eighteen_text_area_end_position);
        }
        break;

      case 'text_area_19':
        this.nineteen_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_nineteen_text_area' : '#nineteen_text_area').selectionStart;
        this.nineteen_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_nineteen_text_area' : '#nineteen_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.nineteen_text_area_start_position, this.nineteen_text_area_end_position);
        } else {
          this.selectedText = this.nineteen_text_area_value.substring(this.nineteen_text_area_start_position, this.nineteen_text_area_end_position);
        }
        break;

      case 'text_area_20':
        this.twenty_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twenty_text_area' : '#twenty_text_area').selectionStart;
        this.twenty_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twenty_text_area' : '#twenty_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.twenty_text_area_start_position, this.twenty_text_area_end_position);
        } else {
          this.selectedText = this.twenty_text_area_value.substring(this.twenty_text_area_start_position, this.twenty_text_area_end_position);
        }
        break;

      case 'text_area_21':
        this.twentyone_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentyone_text_area' : '#twentyone_text_area').selectionStart;
        this.twentyone_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentyone_text_area' : '#twentyone_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.twentyone_text_area_start_position, this.twentyone_text_area_end_position);
        } else {
          this.selectedText = this.twentyone_text_area_value.substring(this.twentyone_text_area_start_position, this.twentyone_text_area_end_position);
        }
        break;

      case 'text_area_22':
        this.twentytwo_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentytwo_text_area' : '#twentytwo_text_area').selectionStart;
        this.twentytwo_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentytwo_text_area' : '#twentytwo_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.twentytwo_text_area_start_position, this.twentytwo_text_area_end_position);
        } else {
          this.selectedText = this.twentytwo_text_area_value.substring(this.twentytwo_text_area_start_position, this.twentytwo_text_area_end_position);
        }
        break;

      case 'text_area_23':
        this.twentythree_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentythree_text_area' : '#twentythree_text_area').selectionStart;
        this.twentythree_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentythree_text_area' : '#twentythree_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.twentythree_text_area_start_position, this.twentythree_text_area_end_position);
        } else {
          this.selectedText = this.twentythree_text_area_value.substring(this.twentythree_text_area_start_position, this.twentythree_text_area_end_position);
        }
        break;

      case 'text_area_24':
        this.twentyfour_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentyfour_text_area' : '#twentyfour_text_area').selectionStart;
        this.twentyfour_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentyfour_text_area' : '#twentyfour_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.twentyfour_text_area_start_position, this.twentyfour_text_area_end_position);
        } else {
          this.selectedText = this.twentyfour_text_area_value.substring(this.twentyfour_text_area_start_position, this.twentyfour_text_area_end_position);
        }
        break;

      case 'text_area_25':
        this.twentyfive_text_area_start_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentyfive_text_area' : '#twentyfive_text_area').selectionStart;
        this.twentyfive_text_area_end_position = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentyfive_text_area' : '#twentyfive_text_area').selectionEnd;

        if (popup) {
          this.selectedText = this.popup_text_area_value[this.text_index - 1].substring(this.twentyfive_text_area_start_position, this.twentyfive_text_area_end_position);
        } else {
          this.selectedText = this.twentyfive_text_area_value.substring(this.twentyfive_text_area_start_position, this.twentyfive_text_area_end_position);
        }
        break;


    }
  }


  addParamterOrCorvet(separator, text_area, popup: boolean, ref) {
    let element = this.elementRef.nativeElement.querySelector('#' + ref);

    if (this.selectedText.includes('#')) {
      this.focusTextArea(element);
      return;
    }


    switch (text_area) {
      case 'text_area_1':
        this.selectedText = this.selectedText.replace(/\s+/g, "");

        if (this.first_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_first_text_area' : '#first_text_area');
          this.first_text_area_start_position = ref.selectionStart;
          this.first_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.first_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.first_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.first_text_area_value = this.first_text_area_value.substring(0, this.first_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.first_text_area_value.substring(this.first_text_area_end_position, this.first_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.first_text_area_value;
          }

          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.first_text_area_value;
          ref.focus();
          ref.selectionEnd = this.first_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }
        break;

      case 'text_area_2':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.second_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_second_text_area' : '#second_text_area');
          this.second_text_area_start_position = ref.selectionStart;
          this.second_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.second_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.second_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);

          } else {
            this.second_text_area_value = this.second_text_area_value.substring(0, this.second_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.second_text_area_value.substring(this.second_text_area_end_position, this.second_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.second_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.second_text_area_value;
          ref.focus();
          ref.selectionEnd = this.second_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_3':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.third_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_third_text_area' : '#third_text_area');
          this.third_text_area_start_position = ref.selectionStart;
          this.third_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.third_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.third_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.third_text_area_value = this.third_text_area_value.substring(0, this.third_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.third_text_area_value.substring(this.third_text_area_end_position, this.third_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.third_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.third_text_area_value;
          ref.focus();
          ref.selectionEnd = this.third_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_4':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.fourth_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fourth_text_area' : '#fourth_text_area');
          this.fourth_text_area_start_position = ref.selectionStart;
          this.fourth_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.fourth_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.fourth_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.fourth_text_area_value = this.fourth_text_area_value.substring(0, this.fourth_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.fourth_text_area_value.substring(this.fourth_text_area_end_position, this.fourth_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.fourth_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.fourth_text_area_value;
          ref.focus();
          ref.selectionEnd = this.fourth_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_5':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.fifth_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fifth_text_area' : '#fifth_text_area');
          this.fifth_text_area_start_position = ref.selectionStart;
          this.fifth_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.fifth_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.fifth_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.fifth_text_area_value = this.fifth_text_area_value.substring(0, this.fifth_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.fifth_text_area_value.substring(this.fifth_text_area_end_position, this.fifth_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.fifth_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.fifth_text_area_value;
          ref.focus();
          ref.selectionEnd = this.fifth_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_6':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.sixth_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_sixth_text_area' : '#sixth_text_area');
          this.sixth_text_area_start_position = ref.selectionStart;
          this.sixth_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.sixth_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.sixth_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.sixth_text_area_value = this.sixth_text_area_value.substring(0, this.sixth_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.sixth_text_area_value.substring(this.sixth_text_area_end_position, this.sixth_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.sixth_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.sixth_text_area_value;
          ref.focus();
          ref.selectionEnd = this.sixth_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_7':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.sevent_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_seventh_text_area' : '#seventh_text_area');
          this.seventh_text_area_start_position = ref.selectionStart;
          this.seventh_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.seventh_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.seventh_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.sevent_text_area_value = this.sevent_text_area_value.substring(0, this.seventh_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.sevent_text_area_value.substring(this.seventh_text_area_end_position, this.sevent_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.sevent_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.sevent_text_area_value;
          ref.focus();
          ref.selectionEnd = this.seventh_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_8':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.eighth_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_eighth_text_area' : '#eighth_text_area');
          this.eighth_text_area_start_position = ref.selectionStart;
          this.eighth_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.eighth_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.eighth_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.eighth_text_area_value = this.eighth_text_area_value.substring(0, this.eighth_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.eighth_text_area_value.substring(this.eighth_text_area_end_position, this.eighth_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.eighth_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.eighth_text_area_value;
          ref.focus();
          ref.selectionEnd = this.eighth_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_9':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.ninth_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_ninth_text_area' : '#ninth_text_area');
          this.ninth_text_area_start_position = ref.selectionStart;
          this.ninth_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.ninth_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.ninth_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.ninth_text_area_value = this.ninth_text_area_value.substring(0, this.ninth_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.ninth_text_area_value.substring(this.ninth_text_area_end_position, this.ninth_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.ninth_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.ninth_text_area_value;
          ref.focus();
          ref.selectionEnd = this.ninth_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_10':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.tenth_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_tenth_text_area' : '#tenth_text_area');
          this.tenth_text_area_start_position = ref.selectionStart;
          this.tenth_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.tenth_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.tenth_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.tenth_text_area_value = this.tenth_text_area_value.substring(0, this.tenth_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.tenth_text_area_value.substring(this.tenth_text_area_end_position, this.tenth_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.tenth_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.tenth_text_area_value;
          ref.focus();
          ref.selectionEnd = this.tenth_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_11':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.eleventh_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_eleventh_text_area' : '#eleventh_text_area');
          this.eleventh_text_area_start_position = ref.selectionStart;
          this.eleventh_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.eleventh_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.eleventh_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.eleventh_text_area_value = this.eleventh_text_area_value.substring(0, this.eleventh_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.eleventh_text_area_value.substring(this.eleventh_text_area_end_position, this.eleventh_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.eleventh_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.eleventh_text_area_value;
          ref.focus();
          ref.selectionEnd = this.eleventh_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_12':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.tweleve_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_tweleve_text_area' : '#tweleve_text_area');
          this.tweleve_text_area_start_position = ref.selectionStart;
          this.tweleve_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.tweleve_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.tweleve_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.tweleve_text_area_value = this.tweleve_text_area_value.substring(0, this.tweleve_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.tweleve_text_area_value.substring(this.tweleve_text_area_end_position, this.tweleve_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.tweleve_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.tweleve_text_area_value;
          ref.focus();
          ref.selectionEnd = this.tweleve_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_13':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.thirteen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_thirteen_text_area' : '#thirteen_text_area');
          this.thirteen_text_area_start_position = ref.selectionStart;
          this.thirteen_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.thirteen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.thirteen_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.thirteen_text_area_value = this.thirteen_text_area_value.substring(0, this.thirteen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.thirteen_text_area_value.substring(this.thirteen_text_area_end_position, this.thirteen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.thirteen_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.thirteen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.thirteen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_14':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.fourteen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fourteen_text_area' : '#fourteen_text_area');
          this.fourteen_text_area_start_position = ref.selectionStart;
          this.fourteen_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.fourteen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.fourteen_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.fourteen_text_area_value = this.fourteen_text_area_value.substring(0, this.fourteen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.fourteen_text_area_value.substring(this.fourteen_text_area_end_position, this.fourteen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.fourteen_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.fourteen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.fourteen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';

        }

        break;

      case 'text_area_15':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.fifteen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_fifteen_text_area' : '#fifteen_text_area');
          this.fifteen_text_area_start_position = ref.selectionStart;
          this.fifteen_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.fifteen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.fifteen_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.fifteen_text_area_value = this.fifteen_text_area_value.substring(0, this.fifteen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.fifteen_text_area_value.substring(this.fifteen_text_area_end_position, this.fifteen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.fifteen_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.fifteen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.fifteen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_16':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.sixteen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_sixteen_text_area' : '#sixteen_text_area');
          this.sixteen_text_area_start_position = ref.selectionStart;
          this.sixteen_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.sixteen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.sixteen_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.sixteen_text_area_value = this.sixteen_text_area_value.substring(0, this.sixteen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.sixteen_text_area_value.substring(this.sixteen_text_area_end_position, this.sixteen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.sixteen_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.sixteen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.sixteen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_17':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.seventeen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_seventeen_text_area' : '#seventeen_text_area');
          this.seventeen_text_area_start_position = ref.selectionStart;
          this.seventeen_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.seventeen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.seventeen_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.seventeen_text_area_value = this.seventeen_text_area_value.substring(0, this.seventeen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.seventeen_text_area_value.substring(this.seventeen_text_area_end_position, this.seventeen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.seventeen_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.seventeen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.seventeen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_18':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.eighteen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_eighteen_text_area' : '#eighteen_texeighteen_text_areat_area');
          this.eighteen_text_area_start_position = ref.selectionStart;
          this.eighteen_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.eighteen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.eighteen_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.eighteen_text_area_value = this.eighteen_text_area_value.substring(0, this.eighteen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.eighteen_text_area_value.substring(this.eighteen_text_area_end_position, this.eighteen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.eighteen_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.eighteen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.eighteen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';

        }

        break;

      case 'text_area_19':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.nineteen_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_nineteen_text_area' : '#nineteen_text_area');
          this.nineteen_text_area_start_position = ref.selectionStart;
          this.nineteen_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.nineteen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.nineteen_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.nineteen_text_area_value = this.nineteen_text_area_value.substring(0, this.nineteen_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.nineteen_text_area_value.substring(this.nineteen_text_area_end_position, this.nineteen_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.nineteen_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.nineteen_text_area_value;
          ref.focus();
          ref.selectionEnd = this.nineteen_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';

        }

        break;

      case 'text_area_20':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.twenty_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twenty_text_area' : '#twenty_text_area');
          this.twenty_text_area_start_position = ref.selectionStart;
          this.twenty_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.twenty_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.twenty_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.twenty_text_area_value = this.twenty_text_area_value.substring(0, this.twenty_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.twenty_text_area_value.substring(this.twenty_text_area_end_position, this.twenty_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.twenty_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.twenty_text_area_value;
          ref.focus();
          ref.selectionEnd = this.twenty_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_21':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.twentyone_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentyone_text_area' : '#twentyone_text_area');
          this.twentyone_text_area_start_position = ref.selectionStart;
          this.twentyone_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.twentyone_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.twentyone_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.twentyone_text_area_value = this.twentyone_text_area_value.substring(0, this.twentyone_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.twentyone_text_area_value.substring(this.twentyone_text_area_end_position, this.twentyone_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.twentyone_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.twentyone_text_area_value;
          ref.focus();
          ref.selectionEnd = this.twentyone_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';

        }

        break;

      case 'text_area_22':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.twentytwo_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentytwo_text_area' : '#twentytwo_text_area');
          this.twentytwo_text_area_start_position = ref.selectionStart;
          this.twentytwo_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.twentytwo_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.twentytwo_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.twentytwo_text_area_value = this.twentytwo_text_area_value.substring(0, this.twentytwo_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.twentytwo_text_area_value.substring(this.twentytwo_text_area_end_position, this.twentytwo_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.twentytwo_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.twentytwo_text_area_value;
          ref.focus();
          ref.selectionEnd = this.twentytwo_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_23':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.twentythree_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentythree_text_area' : '#twentythree_text_area');
          this.twentythree_text_area_start_position = ref.selectionStart;
          this.twentythree_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.twentythree_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.twentythree_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.twentythree_text_area_value = this.twentythree_text_area_value.substring(0, this.twentythree_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.twentythree_text_area_value.substring(this.twentythree_text_area_end_position, this.twentythree_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.twentythree_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.twentythree_text_area_value;
          ref.focus();
          ref.selectionEnd = this.twentythree_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_24':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.twentyfour_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentyfour_text_area' : '#twentyfour_text_area');
          this.twentyfour_text_area_start_position = ref.selectionStart;
          this.twentyfour_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.twentyfour_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.twentyfour_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.twentyfour_text_area_value = this.twentyfour_text_area_value.substring(0, this.twentyfour_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.twentyfour_text_area_value.substring(this.twentyfour_text_area_end_position, this.twentyfour_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.twentyfour_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.twentyfour_text_area_value;
          ref.focus();
          ref.selectionEnd = this.twentyfour_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';
        }


        break;

      case 'text_area_25':
        this.selectedText = this.selectedText.replace(/\s+/g, "");
        if (this.twentyfive_text_area_value.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

          let ref = this.elementRef.nativeElement.querySelector(popup ? '#maximized_twentyfive_text_area' : '#twentyfive_text_area');
          this.twentyfive_text_area_start_position = ref.selectionStart;
          this.twentyfive_text_area_end_position = ref.selectionEnd;

          if (popup) {
            this.popup_text_area_value[this.text_index - 1] =
              this.popup_text_area_value[this.text_index - 1].substring(0, this.twentyfive_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.text_index - 1].substring(this.twentyfive_text_area_end_position, this.popup_text_area_value[this.text_index - 1].length);
          } else {
            this.twentyfive_text_area_value = this.twentyfive_text_area_value.substring(0, this.twentyfive_text_area_start_position) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.twentyfive_text_area_value.substring(this.twentyfive_text_area_end_position, this.twentyfive_text_area_value.length);
            this.popup_text_area_value[this.text_index - 1] = this.twentyfive_text_area_value;
          }
          ref.value = popup ? this.popup_text_area_value[this.text_index - 1] : this.twentyfive_text_area_value;
          ref.focus();
          ref.selectionEnd = this.twentyfive_text_area_end_position + separator.length;
          ref.selectionStart = ref.selectionEnd;
          this.selectedText = '';

        }

        break;


    }
    this.selectedText = '';
  }

  focusTextArea(element) {
    if (element && /INPUT|TEXTAREA/i.test(element.tagName)) {
      if ('selectionStart' in element) {
        element.selectionEnd = element.selectionStart;
      }
      element.blur();
    }

    if (window.getSelection) { // All browsers, except IE <=8
      window.getSelection().removeAllRanges();
    } else if (element.selection) { // IE <=8
      element.selection.empty();
    }
    element.focus();
  }

  moveTextArea(index) {

    this.compInteraction.moveInformationBlocks(index, this._ref);

  }

  resetSelectedText() {
    if (this.selectedText !== '') {
      this.selectedText = '';
    }

  }

  doNothing(ref) {
    var element = this.elementRef.nativeElement.querySelector('#' + ref);
    this.focusTextArea(element);
  }


  openModal() {
    let reordered: boolean = false;
    let instance;
    try {
      instance = this.ngxSmartModalService.getModal(this.textareaReference);
    } catch (error) {
      console.log(error);
    }

    if (instance && reordered == false) {
      instance.open();
    } else {
      instance = this.ngxSmartModalService.getModal(this.manualTextareaReference(this.text_index + 1));
      instance.identifier = this.manualTextareaReference(this.text_index + 1);
      instance.open();
      reordered = true;
      this.clearPopupValue(this.textAreaName);
    }

  }

  closeModal() {

    let instance;
    try {
      instance = this.ngxSmartModalService.getModal(this.textareaReference);
    } catch (error) {
      console.log(error);
    }

    if (instance) {
      instance.close();
    } else {
      instance = this.ngxSmartModalService.getModal(this.manualTextareaReference(this.text_index + 1));

      instance.close();

    }
  }

  manualTextareaReference(index) {
    switch (index) {

      case 1:
        return 'first_text_area';

      case 2:
        return 'second_text_area';

      case 3:
        return 'third_text_area';

      case 4:
        return 'fourth_text_area';

      case 5:
        return 'fifth_text_area';

      case 6:
        return 'sixth_text_area';

      case 7:
        return 'seventh_text_area';

      case 8:
        return 'eighth_text_area';

      case 9:
        return 'ninth_text_area';

      case 10:
        return 'tenth_text_area';

      case 11:
        return 'eleventh_text_area';

      case 12:
        return 'tweleve_text_area';

      case 13:
        return 'thirteen_text_area';

      case 14:
        return 'fourteen_text_area';

      case 15:
        return 'fifteen_text_area';

      case 16:
        return 'sixteen_text_area';

      case 17:
        return 'seventeen_text_area';

      case 18:
        return 'eighteen_text_area';

      case 19:
        return 'nineteen_text_area';

      case 20:
        return 'twenty_text_area';

      case 21:
        return 'twentyone_text_area';

      case 22:
        return 'twentytwo_text_area';

      case 23:
        return 'twentythree_text_area';

      case 24:
        return 'twentyfour_text_area';

      case 25:
        return 'twentyfive_text_area';
    }
  }


  docSoaTitle: string = '';
  docSoaNumber: string = '';
  nestedModal: boolean;

  openDocSoa(nestedModal) {
    this.displayDocSoa = true;
    this.nestedModal = nestedModal;
  }

  closeDocSoa() {
    this.displayDocSoa = false;
    this.docSoaNumber = '';
    this.docSoaTitle = '';
  }


  generateDocSoa() {

      let docSoa = `@D#${this.docSoaTitle.trim()}||${this.docSoaNumber.trim()}#`;

      if (this.textareaValue.length > 0 || this.popup_text_area_value[this.text_index - 1].length > 0) {

      this.enterText(docSoa, this.textAreaName, this.nestedModal);

      } else {
      this.popup_text_area_value[this.text_index - 1] += docSoa;
      this.prepareDocSoa(docSoa);
      }

      this.closeDocSoa();
  }

  isInValid(str) {
      return (!str || str.length === 0 || str === ' ');
  }

  prepareDocSoa(docSoa) {
    switch (this.text_index) {

      case 1:
        this.first_text_area_value += docSoa;
        break;

      case 2:
        this.second_text_area_value += docSoa;

      case 3:
        this.third_text_area_value += docSoa;
        break;

      case 4:
        this.fourth_text_area_value += docSoa;
        break;

      case 5:
        this.fifth_text_area_value += docSoa;
        break;

      case 6:
        this.sixth_text_area_value += docSoa;
        break;

      case 7:
        this.sevent_text_area_value += docSoa;
        break;

      case 8:
        this.eighth_text_area_value += docSoa;
        break;

      case 9:
        this.ninth_text_area_value += docSoa;
        break;

      case 10:
        this.tenth_text_area_value += docSoa;
        break;

      case 11:
        this.eleventh_text_area_value += docSoa;
        break;

      case 12:
        this.tweleve_text_area_value += docSoa;
        break;

      case 13:
        this.thirteen_text_area_value += docSoa;
        break;

      case 14:
        this.fourteen_text_area_value += docSoa;
        break;

      case 15:
        this.fifteen_text_area_value += docSoa;
        break;

      case 16:
        this.sixteen_text_area_value += docSoa;
        break;

      case 17:
        this.seventeen_text_area_value += docSoa;
        break;

      case 18:
        this.eighteen_text_area_value += docSoa;
        break;

      case 19:
        this.nineteen_text_area_value += docSoa;
        break;

      case 20:
        this.twenty_text_area_value += docSoa;
        break;


      case 21:
        this.twentyone_text_area_value += docSoa;
        break;

      case 22:
        this.twentytwo_text_area_value += docSoa;
        break;

      case 23:
        this.twentythree_text_area_value += docSoa;
        break;

      case 24:
        this.twentyfour_text_area_value += docSoa;
        break;

      case 25:
        this.twentyfive_text_area_value += docSoa;
        break;
    }
  }

}