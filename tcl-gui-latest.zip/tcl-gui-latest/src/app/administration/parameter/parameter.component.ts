import {
  Component,
  OnInit,
  Input
} from '@angular/core';
import {
  AdminService
} from 'src/app/service/administration/admin.service';
import { NotificationsService } from 'angular2-notifications';

@Component({
  selector: 'app-parameter',
  templateUrl: './parameter.component.html',
  styleUrls: ['./parameter.component.scss']
})
export class ParameterComponent  {

  displayDialog: boolean;
  parameter: any = {};
  newParameter: boolean;
  @Input('parametersContent') parametersContent: any;
  @Input('selectedParameter') selectedParameter: any;
  @Input('parameters')  parameters: any;
  @Input('parameterCols')  parameterCols: any[];
  @Input('currentParameterType')  currentParameterType;
  _ref;
  compInteraction;
  componentRef;

  constructor(private adminService: AdminService,private _service: NotificationsService) {}


      showDialogToAdd() {
        this.newParameter = true;
        this.parameter = {};
        this.displayDialog = true;
      }

      saveParameter(caption: any) {
        let type = caption._projectedViews[0].nodes[0].renderText.data.trim();
       
    
        if (!this.parameters) {
          this.parameters = [];
        }

         if (this.newParameter) { 
              this.parameter.id = null;
              this.parameter.type = type;
          }

        this.adminService.editParameter(this.parameter).subscribe(data => {

            let parameters = [...this.parameters];

            if (this.newParameter) {
              this.parameter.id = data.id;
              this.parameter.type = type;
              parameters.push(this.parameter);
            } else {
              parameters[this.parameters.indexOf(this.selectedParameter)] = this.parameter;
            }

        this.parameters = parameters;
        this.parameter = {};
        this.displayDialog = false;
        }); 
        
      }

      deleteParameterOnEdit() {

        this.displayDialog = false;
          let index = this.parameters.indexOf(this.selectedParameter);
          this.adminService.deleteParameterById(this.selectedParameter.id).subscribe(
            data => {
              this.parameters = this.parameters.filter((val, i) => i != index);
  
              this.selectedParameter = null;
            }
          );
        

      }

      onRowSelect(event) {

        this.newParameter = false;
        this.parameter = this.cloneParameter(event.data);
        this.displayDialog = true;
      }

      cloneParameter(existingParameter) {
        let parameter = {};
        for (let prop in existingParameter) {
          parameter[prop] = existingParameter[prop];
        }
        return parameter;
      }

      isInvalid(str) {
        return (!str || str.length === 0 || /^\s*$/.test(str))
      }

}