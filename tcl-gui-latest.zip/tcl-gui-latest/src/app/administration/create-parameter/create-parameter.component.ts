import { Component, Input, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-create-parameter',
  templateUrl: './create-parameter.component.html',
  styleUrls: ['./create-parameter.component.scss']
})
export class CreateParameterComponent   {
 @Input('parametersContent') parametersContent;
 compInteraction;
 _ref;
 selectedValues:any[] = [];
 label:string = '';
@ViewChild('animateSaveBtn')animateSaveBtn:ElementRef;

 animate() {
  let $button =  document.querySelector('#animateSave');
  if(
    $button.classList.contains('active') ||
    $button.classList.contains('success')
    ) {
      return;
    }
    $button.classList.add('active');
    $button.classList.add('circle');
    setTimeout(() => {
      $button.classList.add('loader');
    }, 125);
  
    setTimeout(() => {
      $button.classList.remove('loader');
      $button.classList.remove('active');
      $button.classList.remove('circle');
      $button.textContent = 'Succès';
      $button.classList.add('success');
      $button.classList.add('animated');
      $button.classList.add('pulse');
    }, 1600);

    setTimeout(()=> {
      $button.textContent = 'Save';
      $button.classList.remove('success');
      $button.classList.remove('animated');
      $button.classList.remove('pulse');
      this.animateSaveBtn.nativeElement.blur();
    }, 2900);
    
}

 createParameter() {
   let parameter = {
    type: this.label,
    columnes: [...this.selectedValues]
   }
   console.log("TCL: CreateParameterComponent -> createParameter -> parameter", JSON.stringify(parameter))
   this.animate();
  }
}
