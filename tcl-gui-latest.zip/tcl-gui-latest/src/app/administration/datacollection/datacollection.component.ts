import { ElementRef } from '@angular/core';
import { Component, OnInit, Input, OnDestroy, ViewChild } from '@angular/core';
import { AdminService } from 'src/app/service/administration/admin.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotificationsService } from 'angular2-notifications';

@Component({
  selector: 'app-datacollection',
  templateUrl: './datacollection.component.html',
  styleUrls: ['./datacollection.component.scss']
})
export class DatacollectionComponent implements OnDestroy{

  
  constructor(private adminService: AdminService,private elementRef: ElementRef,private _service: NotificationsService) { }
  compInteraction;
  _ref;
  @ViewChild('animateSaveBtn') animateSaveBtn:ElementRef;
  @Input('dataCollectionTitle') dataCollectionTitle:string;
  @Input('targetTopics') targetTopics: any;
  @Input('DataCollectionContent') DataCollectionContent:any[];
  @Input('sourceTopics') sourceTopics:any;
  @Input('dataCollectionId') dataCollectionId:number;
  
  ngOnDestroy() {
    this.sourceTopics = [];
    this.targetTopics = [];
    this.dataCollectionTitle = '';
    this.dataCollectionId = 0;
  }

  sort(){
    this.sourceTopics.sort((a,b) => this.compare(a,b));
  }

  startAnimation() {
    let $button =  document.querySelector('#animateSave');
    if(
      $button.classList.contains('active') ||
      $button.classList.contains('success')
      ) {
        return;
      }
      $button.classList.add('active');
      $button.classList.add('circle');
      setTimeout(() => {
        $button.classList.add('loader');
      }, 125);
    
     
      
  }

  stopAnimation() {
    let $button =  document.querySelector('#animateSave');
    setTimeout(() => {
      $button.classList.remove('loader');
      $button.classList.remove('active');
      $button.classList.remove('circle');
      $button.textContent = 'Succès';
      $button.classList.add('success');
      $button.classList.add('animated');
      $button.classList.add('pulse');
    }, 1000);

    setTimeout(()=> {
      $button.textContent = 'Save';
      $button.classList.remove('success');
      $button.classList.remove('animated');
      $button.classList.remove('pulse');
      this.animateSaveBtn.nativeElement.blur();
    }, 1500);
  }
  savedataCollection(){

    let $inputRef =  document.querySelector('#dcLabel');
    let $errorField =  document.querySelector('#labelError');
    let $inputNativeRef = this.elementRef.nativeElement.querySelector('#dcLabel');

    if(this.duplicateDataCollection($inputRef,$inputNativeRef)) {
      return;
    }
   

    if(this.isInValid(this.dataCollectionTitle)) {

      $inputRef.classList.add('emptyLabel');
      $errorField.classList.remove('hideError');
      $inputNativeRef.focus();

    }else {

      $inputRef.classList.remove('emptyLabel');
      $errorField.classList.add('hideError');
    
    
      this.startAnimation();
      this.adminService.editOrSaveDataCollection(this.getDataCollection()).subscribe(data => {

        let existingCollection = false;

          for(let i=0; i < this.DataCollectionContent.length;i++) {
            if(this.DataCollectionContent[i].id == data.id) {
              this.DataCollectionContent[i] = {
                id: this.dataCollectionId,
                label: this.dataCollectionTitle
              }
              existingCollection = true;
            }
          }
          if(!existingCollection) {
            this.DataCollectionContent.push({
              id: data.id,
              label: data.label
            });
          }
        this.stopAnimation();
       
      })
 
    }

    this.animateSaveBtn.nativeElement.blur();
  }

  detectLabel() {
    if(!this.isInValid(this.dataCollectionTitle)) { 
      let $inputRef =  document.querySelector('#dcLabel');
      let $errorField =  document.querySelector('#labelError');
      $inputRef.classList.remove('emptyLabel');
      $errorField.classList.add('hideError');
    }
  }

  compare(a,b) {
     if (a.id == b.id) 
         return a.id - b.id; 
     return a.id > b.id ? 1 : -1;
  }

      duplicateDataCollection($inputRef,$inputNativeRef){
        let duplicate = false;
        this.DataCollectionContent.forEach(dataCollection => {
          if(dataCollection.label == this.dataCollectionTitle &&
              this.dataCollectionId == 0
            ) {
    
            $inputRef.classList.add('emptyLabel');
            $inputNativeRef.focus();
            let options = 
            {
              animate: 'scale',
              timeOut: 3000,
            }
            this._service.warn(
               'Error',
               `Une collection de données existe déjà avec le nom ${this.dataCollectionTitle}`,
               options
               )
              duplicate = true;
          }
        });
        return duplicate;
      }

      getDataCollection(){
        let topics = [];
        this.targetTopics.forEach(element => {
           topics.push({
            topicId: element.id,
            displayMode: element.displayMode
           })
        });

        let dc ={
         id: this.dataCollectionId > 0 ? this.dataCollectionId : null,
         label: this.dataCollectionTitle,
         collectionContent:[...topics]
        };
        
        return dc;
			
      }

      isInValid(str) {
        return (!str || str.length === 0 || /^\s*$/.test(str))
      }
}
