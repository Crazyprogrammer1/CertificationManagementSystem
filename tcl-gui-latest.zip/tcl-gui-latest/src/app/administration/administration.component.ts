import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ComponentFactoryResolver,
  ViewContainerRef
} from '@angular/core';
import {
  AdminService
} from '../service/administration/admin.service';
import {
  Subscription,
  Observable,
  of
} from 'rxjs';
import {
  ParameterComponent
} from './parameter/parameter.component';
import {
  DatacollectionComponent
} from './datacollection/datacollection.component';
import {
  NgxSpinnerService
} from 'ngx-spinner';
import 'rxjs/add/observable/forkJoin';
import {
  NotificationsService
} from 'angular2-notifications';
import {
  filter,
  catchError
} from 'rxjs/operators';
import {
  CreateParameterComponent
} from './create-parameter/create-parameter.component';
import {
  EditBaseTopicsComponent
} from './edit-base-topics/edit-base-topics.component';
import {
  NgxCoolDialogsService
} from 'ngx-cool-dialogs';
const unAuthorizedMsg = `Vous n'avez pas accès pour effectuer cette opération`;
@Component({
  selector: 'app-administration',
  templateUrl: './administration.component.html',
  styleUrls: ['./administration.component.scss'],
  providers: [AdminService]
})
export class AdministrationComponent implements OnInit, OnDestroy {

  parametersContent: any;
  DataCollectionContent: any;
  dataCollectionTitle: string = '';
  dataCollectionId: number = 0;
  subscription: Subscription;
  parametersLoaded: boolean;
  CollectionLoaded: boolean;
  baseDataCollectionTopics: any = [];
  baseDataCollection: any = [];
  targetDataCollectionTopics: any = [];
  selectedParameter: any;
  parameters: any;
  parameterCols: any[];
  currentParameterType;

  @ViewChild('viewContainerRef', {
    read: ViewContainerRef
  }) VCR: ViewContainerRef;

  constructor(
    private coolDialogs: NgxCoolDialogsService,
    private adminService: AdminService,
    private CFR: ComponentFactoryResolver,
    private spinner: NgxSpinnerService,
    private _service: NotificationsService
  ) {}

  async ngOnInit() {
    this.initializeBaseDataCollection();
    this.initializeBaseTopics();
    let paramContent = await this.adminService.populateParameters().pipe(catchError(error => of (error)));
    let dcContent = await this.adminService.populateDataCollection().pipe(catchError(error => of (error)));


    this.subscription = Observable.forkJoin([paramContent, dcContent]).subscribe(
      result => {

        if (result[0].status) {
          this.parametersContent = [];
        } else {
          this.parametersContent = result[0];
          this.validateParameterContent();
        }

        if (result[1].status) {
          this.DataCollectionContent = [];
        } else {
          this.DataCollectionContent = result[1];
        }

        this.parametersLoaded = true;
        this.CollectionLoaded = true;

      },
      error => {
        console.log("TCL: AdministrationComponent -> ngOnInit -> error", error)
        this.CollectionLoaded = false;
        this.parametersLoaded = false;

      }
    );
  }

  async initializeBaseTopics() {
    let baseTopics = await this.adminService.getDefaultTopics();
    this.baseDataCollectionTopics = await baseTopics;
  }

  async initializeBaseDataCollection() {
    let baseDataCollection = await this.adminService.getBaseDataCollection();
    this.baseDataCollection = await baseDataCollection;
  }

  async validateBaseTopics() {
    if (!this.baseDataCollectionTopics || this.baseDataCollectionTopics.length == 0) {
      await this.initializeBaseTopics();
    }
  }

  async addDataCollectionScreen() {
    this.VCR.clear();
    let componentFactory = this.CFR.resolveComponentFactory(DatacollectionComponent);
    let componentRef = this.VCR.createComponent(componentFactory);
    let currentComponent = componentRef.instance;
    currentComponent.compInteraction = this;
    componentRef.instance._ref = componentRef;


    ( < DatacollectionComponent > componentRef.instance).targetTopics = this.targetDataCollectionTopics;
    ( < DatacollectionComponent > componentRef.instance).DataCollectionContent = this.DataCollectionContent;
    ( < DatacollectionComponent > componentRef.instance).dataCollectionTitle = this.dataCollectionTitle;
    ( < DatacollectionComponent > componentRef.instance).dataCollectionId = this.dataCollectionId;
    ( < DatacollectionComponent > componentRef.instance).sourceTopics = await this.getCopyOfBaseList();

  }

  async getCopyOfBaseList() {
    await this.validateBaseTopics();

    if (this.targetDataCollectionTopics && this.targetDataCollectionTopics.length > 0) {

      let baseList: Array < any > = JSON.parse(JSON.stringify(this.baseDataCollectionTopics));
      this.targetDataCollectionTopics.forEach(
        targetTopic => {

          for (let i = 0; i < baseList.length; i++) {
            if (baseList[i].id == targetTopic.id) {
              baseList.splice(i, 1);
            }
          }
        });
      return JSON.parse(JSON.stringify(baseList));
    } else {
      return JSON.parse(JSON.stringify(this.baseDataCollectionTopics));
    }
  }


  askForDcDelete(valueToRemove, ref) {

    this.coolDialogs.confirm('Voulez-vous supprimer cette Collection de données ?')
      .subscribe(res => {
        if (res) {
          this.deleteCollection(valueToRemove, ref);
        } else {
          console.log('You clicked Cancel. You smart.');
        }
      });
  }

  deleteParameter(valueToRemove, ref) {
    let options = {
      animate: 'scale'
    }
    switch (valueToRemove) {
      case 'NATURE_CLASS':
        this._service.warn(
          'Error',
          unAuthorizedMsg,
          options
        )

        return;

      case 'LANGUAGES':
        this._service.warn(
          'Error',
          unAuthorizedMsg,
          options
        )
        return;

      case 'THESEE':
        this._service.warn(
          'Error',
          unAuthorizedMsg,
          options
        )
        return;

      case 'VEHICULES':
        this._service.warn(
          'Error',
          unAuthorizedMsg,
          options
        )
        return;

      case 'separators':
        this._service.warn(
          'Error',
          unAuthorizedMsg,
          options
        )
        return;
    }

    this.adminService.deleteParameterType(valueToRemove)
      .subscribe(() => {

        document.querySelector(`#${ref}`)
          .classList.add('fadeOutLeft');

        setTimeout(() => {
          for (let i = 0; i < this.parametersContent.length; i++) {
            if (this.parametersContent[i].type == valueToRemove) {
              this.parametersContent.splice(i, 1);
            }
          }
        }, 500);
      });

  }

  editParameter(selectedParameter) {
    this.parameters = null;
    this.adminService.getParameterByType(selectedParameter)
      .subscribe(
        parameter => {

          this.selectedParameter = false;
          this.initializeParameterEditColumns(selectedParameter);
          this.parameters = parameter;
          this.currentParameterType = parameter[0].type;
          this.addParameterScreen();
        }
      )
  }

  addParameterScreen() {
    this.VCR.clear();
    let componentFactory = this.CFR.resolveComponentFactory(ParameterComponent);
    let componentRef = this.VCR.createComponent(componentFactory);
    let currentComponent = componentRef.instance;
    currentComponent.compInteraction = this;
    componentRef.instance._ref = componentRef;

    ( < ParameterComponent > componentRef.instance).selectedParameter = this.selectedParameter;
    ( < ParameterComponent > componentRef.instance).parameters = this.parameters;
    ( < ParameterComponent > componentRef.instance).parameterCols = this.parameterCols;
    ( < ParameterComponent > componentRef.instance).currentParameterType = this.currentParameterType;
    ( < ParameterComponent > componentRef.instance).parametersContent = this.parametersContent;

  }

  initializeParameterEditColumns(selectedParameter) {
    switch (selectedParameter) {
      case 'NATURE_CLASS':
        this.parameterCols = [{
            field: 'label',
            header: 'Code'
          },
          {
            field: 'value',
            header: 'Libelle'
          }
        ];
        break;

      case 'LANGUAGES':
        this.parameterCols = [{
            field: 'label',
            header: 'Code langue'
          },
          {
            field: 'value',
            header: 'Libelle langue'
          },
          {
            field: 'value3',
            header: 'Langue par defaut'
          },
          {
            field: 'selected',
            header: 'Traduction Thésée'
          }
        ];
        break;

      case 'VEHICULES':
        this.parameterCols = [{
            field: 'label',
            header: 'Nom commercial véhicule'
          },
          {
            field: 'value',
            header: 'Code famille LCDV'
          },
          {
            field: 'selected',
            header: 'En cours de commercialisation'
          },
          {
            field: 'selected2',
            header: "Eligible a l'affichage"
          },
        ];
        break;

      default:
        this.parameterCols = [{
            field: 'label',
            header: 'Label'
          },
          {
            field: 'value',
            header: 'Value'
          }
        ];
        break;
    }
  }

  resetDataCollectionFields() {
    this.targetDataCollectionTopics = [];
    this.dataCollectionTitle = '';
    this.dataCollectionId = 0;
  }

  addDataCollection() {
    this.resetDataCollectionFields();
    this.addDataCollectionScreen();
  }

  askForDelete(parameter, elementId) {

    // Confirm
    this.coolDialogs.confirm('Voulez-vous supprimer ce paramètre ?')
      .subscribe(res => {
        if (res) {
          this.deleteParameter(parameter, elementId);
        } else {
          console.log('You clicked Cancel. You smart.');
        }
      });
  }

  deleteCollection(valueToRemove, ref) {

    if (valueToRemove == 1) {
      let options = {
        animate: 'scale'
      }
      this._service.warn(
        'Error',
        unAuthorizedMsg,
        options
      )
      return;
    }

    this.adminService.deleteDataCollection(valueToRemove).subscribe(success => {
      document.querySelector(`#${ref}`)
        .classList.add('fadeOutLeft');

      setTimeout(() => {
        for (let i = 0; i < this.DataCollectionContent.length; i++) {
          if (this.DataCollectionContent[i].id == valueToRemove) {
            this.DataCollectionContent.splice(i, 1);
          }
        }
        this.resetDataCollectionFields();
        this.VCR.clear();
      }, 500);
    })

  }

  editCollection(title, id) {
    this.resetDataCollectionFields();
    this.dataCollectionTitle = title;
    this.dataCollectionId = id;

    this.adminService.getTopicByCollectionId(id).subscribe(
      targetTopics => {
        this.targetDataCollectionTopics = targetTopics;
        this.addDataCollectionScreen();
      },
      error => {
        this.targetDataCollectionTopics = [];
        this.addDataCollectionScreen();
      }
    );

  }

  createParameter() {

    let options = {
      animate: 'scale'
    }
    this._service.warn(
      'Error',
      unAuthorizedMsg,
      options
    )
    return;

    /* Below code will generate the Create Parameter Screen, Since it is not in scope now so commenting it  */

    /* this.VCR.clear();
     let componentFactory = this.CFR.resolveComponentFactory(CreateParameterComponent);
     let componentRef = this.VCR.createComponent(componentFactory);
     let currentComponent = componentRef.instance;
     currentComponent.compInteraction = this;
     componentRef.instance._ref = componentRef;

     ( < CreateParameterComponent > componentRef.instance).parametersContent = this.parametersContent; */
  }

  validateParameterContent() {
    for (let i = 0; i < this.parametersContent.length; i++) {
      if (
        this.parametersContent[i].type.toString() == 'THESEE' ||
        this.parametersContent[i].type.toString() == 'separators'
      ) {
        this.parametersContent.splice(i, 1);
        i = 0;
      }
    }
  }

  async editBaseTopics() {
    this.VCR.clear();
    let componentFactory = this.CFR.resolveComponentFactory(EditBaseTopicsComponent);
    let componentRef = this.VCR.createComponent(componentFactory);
    let currentComponent = componentRef.instance;
    currentComponent.compInteraction = this;
    componentRef.instance._ref = componentRef;

    ( < EditBaseTopicsComponent > componentRef.instance).baseTopics = await this.getBaseDataCollection();

  }

  async getBaseDataCollection() {
    if (this.baseDataCollection.length == 0) {
      await this.initializeBaseDataCollection();
      return this.baseDataCollection;
    } else {
      return this.baseDataCollection;
    }
  }

  reject() {
    return;
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}