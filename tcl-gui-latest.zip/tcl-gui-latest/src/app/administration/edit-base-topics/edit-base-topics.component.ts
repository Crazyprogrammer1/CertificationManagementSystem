import {
  Style
} from './../../image-upload/style';
import {
  Subscription
} from 'rxjs';
import {
  Component,
  OnInit,
  ElementRef,
  OnDestroy,
  ChangeDetectorRef
} from '@angular/core';
import {
  MessageService
} from 'primeng/api';
import {
  NotificationsService
} from 'angular2-notifications';
import {
  TopicService
} from 'src/app/service/topic/topic.service';
import {
  AdminService
} from 'src/app/service/administration/admin.service';

@Component({
  selector: 'app-edit-base-topics',
  templateUrl: './edit-base-topics.component.html',
  styleUrls: ['./edit-base-topics.component.scss'],
  providers: [MessageService]
})
export class EditBaseTopicsComponent implements OnDestroy {

  baseTopics: any[] = [];
  compInteraction;
  blank: string = '';
  _ref;
  isIEOrEdge;
  emptyFilterLabel = "Aucun résultat trouvé..";
  typePlaceholder = "Sélectionnez un type";
  filterPlaceholder = "Rechercher";
  topic: any;
  displayDialog: boolean;
  subsciprton: Subscription;
  popupHeader: string = '';
  invalidTopicNumber: boolean = true;
  invalidNumberInfo: boolean = true;
  types = [];
  query: any;
  allowedTypes = [];
  constructor(
    private topicService: TopicService,
    private _service: NotificationsService,
    private elementRef: ElementRef,
    private changeRef: ChangeDetectorRef,
    private adminService: AdminService
  ) {
    this.isIEOrEdge = /msie\s|trident\/|edge\//i.test(window.navigator.userAgent);
    this.subsciprton = this.topicService.getDisplayModes().subscribe(displayModes => {
      displayModes.forEach(element => {
        this.types.push({
          label: element.displayMode,
          value: element.displayMode
        })
      });
    })
  }

  editTopic(topic) {
    this.adminService.getEditableTopic(topic.id).subscribe(editableTopic => {
      this.topic = editableTopic[0];

      let topicNumbers = this.topic.topicNumber.split('.');
      topicNumbers = topicNumbers.filter(function (e) {
        return e
      });

      this.filterTypes(topicNumbers.length)
      this.popupHeader = 'Modifier un sujet';
      this.displayDialog = true;
    })
  }

  changeNumberInfo() {

    let $input = document.querySelector('#numberInfo');
    let $nativeInputRef = this.elementRef.nativeElement.querySelector('#numberInfo');
    let $topicError = this.elementRef.nativeElement.querySelector('#numberInfoError');

    console.log("TCL: EditBaseTopicsComponent -> changeNumberInfo -> this.topic.topicNumberInfo", this.topic.topicNumberInfo)

    if (this.isInValid(this.topic.topicNumberInfo.toString())) {
      this.invalidNumberInfo = true;
      $input.classList.remove('invalid-topic-number');
      $topicError.innerHTML = '';
      return;
    }
    if (!/^\d+$/.test(this.topic.topicNumberInfo.toString())) {

      $input.classList.add('invalid-topic-number');
      $nativeInputRef.focus();
      $topicError.innerHTML = `Le numéro d'information doit contenir uniquement des valeurs numériques`;
      this.invalidNumberInfo = false;
    } else {
      this.invalidNumberInfo = true;
      $input.classList.remove('invalid-topic-number');
      $topicError.innerHTML = '';
    }

  }

  changeTopicNumber() {
    let $input = document.querySelector('#topicNumber');
    let $nativeInputRef = this.elementRef.nativeElement.querySelector('#topicNumber');
    let $topicError = this.elementRef.nativeElement.querySelector('#topicError');

    if (this.isInValid(this.topic.topicNumber.toString())) {
      this.invalidTopicNumber = true;
      $input.classList.remove('invalid-topic-number');
      $topicError.innerHTML = '';
      return;
    }

    let topicNumberInteger = 0;
    let allDots = [];
    let enteredIntegers = this.topic.topicNumber.split('.');
    enteredIntegers = enteredIntegers.filter(function (e) {
      return e
    });

    for (let i = 0; i < this.topic.topicNumber.length; i++) {

      if (this.topic.topicNumber.charAt(i) !== '.') {
        topicNumberInteger += this.topic.topicNumber.charAt(i);
      } else {
        allDots.push(this.topic.topicNumber.charAt(i));
      }
    }

    /* Topic Number Must end with a Dot */
    if (!this.topic.topicNumber.endsWith('.') || this.isInValid(this.topic.topicNumber)) {

      $input.classList.add('invalid-topic-number');
      $nativeInputRef.focus();
      $topicError.innerHTML = 'Le numéro de sujet doit se terminer par .';
      this.invalidTopicNumber = false;

      /* Topic Number Must start with a Numeric Value */
    } else if (!/^\d/.test(this.topic.topicNumber)) {

      $input.classList.add('invalid-topic-number');
      $nativeInputRef.focus();
      $topicError.innerHTML = `Le numéro du sujet doit commencer par un numéro`;
      this.invalidTopicNumber = false;

      /* Topic Number should not contain any alpahates or Special Characters */
    } else if (!/^\d+$/.test(topicNumberInteger.toString())) {

      $input.classList.add('invalid-topic-number');
      $nativeInputRef.focus();
      $topicError.innerHTML = `Le numéro de sujet ne doit contenir que des valeurs numériques`;
      this.invalidTopicNumber = false;

      /* Topic Number should not contain More than one dot between two numbers */
    } else if (allDots.length !== enteredIntegers.length) {
      $input.classList.add('invalid-topic-number');
      $nativeInputRef.focus();
      $topicError.innerHTML = `numéro de sujet invalide, veuillez vous référer au modèle requis`;
      this.invalidTopicNumber = false;

    }
    /* A Valid Topic number e,g:1.2.3.4.  */
    else {
      this.invalidTopicNumber = true;
      $input.classList.remove('invalid-topic-number');
      $topicError.innerHTML = '';
      this.filterTypes(enteredIntegers.length);
    }

  }

  filterTypes(count: number) {
    this.allowedTypes = this.types.filter(element => {
      return element.label.endsWith(count.toString())
    });
    let missingLabel: boolean = true;
    for (let i = 0; i < this.allowedTypes.length; i++) {
      if (this.allowedTypes[i].label == this.topic.displayMode) {
        missingLabel = false;
      } else if (i == this.allowedTypes.length - 1 && missingLabel) {
        this.topic.displayMode = null;
      }
    }
  }

  saveTopic() {

    let options = {
      animate: 'scale'
    };
    let $input = document.querySelector('#topicNumber');
    let $nativeInputRef = this.elementRef.nativeElement.querySelector('#topicNumber');

    if (!this.isInValid(this.topic.topicNumberInfo)) {
      for (let i = 0; i < this.baseTopics.length; i++) {
        if (this.baseTopics[i].topicNumber == this.topic.topicNumber &&
          this.baseTopics[i].numInfo == this.topic.topicNumberInfo && this.topic.id != this.baseTopics[i].id
        ) {
          $input.classList.add('invalid-topic-number');
          $nativeInputRef.focus();
          this._service.error(
            'Erreur',
            `Sujet numéro ${this.topic.topicNumber} avec le numéro d'information ${this.topic.topicNumberInfo} existe déjà
              `,
            options
          )
          return;
        }
      }
    } else {
      for (let i = 0; i < this.baseTopics.length; i++) {
        if (this.baseTopics[i].topicNumber == this.topic.topicNumber && this.topic.id != this.baseTopics[i].id) {
          $input.classList.add('invalid-topic-number');
          $nativeInputRef.focus();
          this._service.error(
            'Erreur',
            `Sujet numéro ${this.topic.topicNumber} existe déjà
              `,
            options
          )
          return;
        }
      }
    }


    this.topicService.saveTopic(this.topic).subscribe(data => {
        this.topic.id = data.id

        this.topic.numInfo = this.topic.topicNumberInfo;
        delete this.topic.topicNumberInfo;

        let newBaseTopic = {
          boInformation: this.topic.boInformation,
          displayMode: this.topic.displayMode,
          id: this.topic.id,
          numInfo: this.topic.numInfo,
          title: this.topic.title,
          topicNumber: this.topic.topicNumber
        }


        let existingTopic = false;
        for (let i = 0; i < this.baseTopics.length; i++) {
          if (this.baseTopics[i].id == this.topic.id) {
            this.baseTopics.splice(i, 1);
            this.baseTopics.splice(i, 0, newBaseTopic);
            existingTopic = true;
          }
        }

        if(!existingTopic) {
          this.baseTopics.push(newBaseTopic);
        }



        this.topic.topicNumberInfo = this.topic.numInfo;
        delete this.topic.numInfo;
        $input.classList.remove('invalid-topic-number');
        this._service.remove();
        this._service.success(
          'Succès',
          `Sujet enregistré avec succès `,
          options
        )
      });



  }



  closeEditPopup() {
    this._service.remove();
    this.displayDialog = false;
    let $input = document.querySelector('#topicNumber');
    $input.classList.remove('invalid-topic-number');
  }

  isInValid(str) {
    return (!str || str.length === 0 || /^\s*$/.test(str))
  }

  ngOnDestroy() {
    this.subsciprton.unsubscribe();
  }

  addNewTopic() {
    this.topic = JSON.parse(JSON.stringify(new Topic()));
    this.popupHeader = 'Ajouter un sujet';
    this.displayDialog = true;
  }

  validateDisplayMode() {
    if (this.topic.displayMode) {
      if (this.topic.displayMode.startsWith('S') || this.topic.displayMode.startsWith('H')) {
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }
}

export class Topic {
  id: number;
  title: string;
  description: string;
  comment: string;
  type: string;
  topicNumber: number;
}