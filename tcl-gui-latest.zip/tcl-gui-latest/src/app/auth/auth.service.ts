import {Injectable} from '@angular/core';
import {Observable,BehaviorSubject} from 'rxjs'; 

@Injectable()
export class AuthService{
  
    current_name_subject = new BehaviorSubject(false);
    isAllChecked  = new BehaviorSubject(false);
    isSaise  = new BehaviorSubject(false);
    

    get currentNameSubject()
    {
        return this.current_name_subject;
    }
    set setCurrentNameSubject(val){
        this.current_name_subject.next(val);
    }

    get isAllParamChecked()
    {
        return this.isAllChecked;
    }
    set isAllParamChecked(val){

        this.isAllChecked.next(val.value);
    }

    get isSaiseActive()
    {
        return this.isSaise;
    }
    set isSaiseActive(val){

        this.isSaise.next(val.value);
    }
}