import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { LoginService } from '../../login/login.service';
import { Observable } from 'rxjs';
import {AuthService} from './auth.service';

@Injectable()
export class AuthGuardService implements CanActivate {
  
  constructor(private loginService: LoginService, private _router: Router,private authService : AuthService) {
  }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
 
    let  isUserAuthenticated =localStorage.getItem('isUserAuthenticated') ? localStorage.getItem('isUserAuthenticated').toString() : 'false';

  if (isUserAuthenticated == 'true') {
        return true;
   } else{
    this._router.navigate(['/login']);
    return false;
   }
     
  }
   
}