import { Component, OnInit, AfterViewInit, AfterContentInit } from '@angular/core';
import { TopicService } from '../service/topic/topic.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-saisie',
  templateUrl: './saisie.component.html',
  styleUrls: ['./saisie.component.scss']
})
export class SaisieComponent  {

  public topics:  Array<object> = [];

  constructor(private svc: TopicService) {
    this.loadTopics();
    localStorage.setItem('saise_visited','true');
  }

  loadTopics(){
    
    this.svc.getTopicByCollectionId().subscribe((data:  Array<object>) => {
      this.topics  =  data;
    });
   
  }
}
