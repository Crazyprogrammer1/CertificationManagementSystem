import {
  ComplexApplicabilityComponent
} from './../complex-applicability/complex-applicability.component';
import {
  ImageareaComponent
} from './../imagearea/imagearea.component';
import {
  ToastModule
} from 'primeng/toast';
import {
  TopicService
} from '../service/topic/topic.service';
import {
  ActivatedRoute
} from '@angular/router';
import {
  Information
} from '../model/information';
import {
  VehicleParam
} from '../model/vehicle-param';
import {
  Http
} from '@angular/http';
import {
  Component,
  OnInit,
  Input,
  ViewChild,
  ViewEncapsulation,
  OnChanges,
  AfterViewInit,
  ViewChildren,
  QueryList,
  Directive,
  OnDestroy
} from '@angular/core';
import {
  ViewContainerRef,
  ComponentFactoryResolver,
  ChangeDetectorRef,
  Type
} from '@angular/core';
import {
  log
} from 'util';
import {
  InformationService
} from '../service/information/information.service';
import {
  Topic
} from '../model/Topic';
import {
  FormGroup,
  FormControl,
  FormArray,
  FormBuilder,
  RequiredValidator
} from '@angular/forms';
import {
  TextareaComponent
} from '../textarea/textarea.component';
import {
  MessageService,
  ConfirmationService
} from 'primeng/api';
import {
  TooltipModule
} from 'primeng/tooltip';
import {
  ComponentRef
} from "@angular/core";
import {
  ApplicabilityService
} from '../service/applicability/applicability.service';
import {
  AuthService
} from '../auth/auth.service';
import {
  Variable
} from '@angular/compiler/src/render3/r3_ast';
import {
  FormatWidth
} from '@angular/common';
import {
  NgxSpinnerService
} from 'ngx-spinner';
import {
  TopmenuComponent
} from '../topmenu/topmenu.component';
import { InformationImageService } from '../service/Image/image.service';


@Component({
  selector: 'app-topic',
  templateUrl: './topic.component.html',
  styleUrls: ['./topic.component.css'],
  providers: [ConfirmationService],

})  
export class TopicComponent implements OnInit, OnDestroy {
  inputInformation: string = '';
  fileCounter: number = 0;
  disableCaption: boolean;
  firstClickofImage: boolean = true;
  @ViewChild(ComplexApplicabilityComponent) complex_app_ref;

  ImageBinaryData:any[] = [];
  ImagesToBedeleted:any[] = [];

  popup_text_area_value: any[] = [];

  image_names_from_rest_call_collection: any[] = [];
  complex_app: boolean;
  first_image_names_from_rest_call = [];
  second_image_names_from_rest_call = [];
  third_image_names_from_rest_call = [];
  fourth_image_names_from_rest_call = [];
  fifth_image_names_from_rest_call = [];
  sixth_image_names_from_rest_call = [];
  seven_image_names_from_rest_call = [];
  eight_image_names_from_rest_call = [];
  nine_image_names_from_rest_call = [];
  ten_image_names_from_rest_call = [];
  eleven_image_names_from_rest_call = [];
  twelve_image_names_from_rest_call = [];
  thirteen_image_names_from_rest_call = [];
  fourteen_image_names_from_rest_call = [];
  fifteen_image_names_from_rest_call = [];
  sixteen_image_names_from_rest_call = [];
  seventeen_image_names_from_rest_call = [];
  eighteen_image_names_from_rest_call = [];
  nineteen_image_names_from_rest_call = [];
  twenty_image_names_from_rest_call = [];
  twenty_one_image_names_from_rest_call = [];
  twenty_two_image_names_from_rest_call = [];
  twenty_three_image_names_from_rest_call = [];
  twenty_four_image_names_from_rest_call = [];
  twenty_five_image_names_from_rest_call = [];

  @ViewChild('viewContainerRef', {
    read: ViewContainerRef
  }) VCR: ViewContainerRef;
  @ViewChildren('viewContainerRef') viewChildren;


  image_names_from_rest_call = [];
  informations: Information[];
  selectedInformation: any;
  selectedInformations: Information[];
  topicInformations: any;
  topicInformation: any;
  selectedInformationId: any;
  parameterVal: any;

  textarea_no_counter: number = 0;
  imagearea_no_counter: number = 0;

  displayinformation: string;
  vehicleParams: VehicleParam[];
  selectedVehicleParam: VehicleParam;
  selectedVehicleParams: VehicleParam[];
  jsonObject: any = {};
  title: string;
  informationId: number;
  selectedAll: boolean;
  title_of_information: string;
  topic_id: any;
  information_id: number;

  separator_dot: string;
  separator_colon: string;
  separator_semicolon: string;
  separator_dash: string;
  separator_rc: string;

  selectedApplicabilty: {} = {};
  public separators;
  public topic;
  public parameters: any[] = [];
  public paramToSubmit;

  private text_cloning_counter: number = 0;
  private area_position_counter: number = 0;


  public enable_information_screen: boolean;

  image_names1: string[] = [];
  image_names2: string[] = [];
  image_names3: string[] = [];
  image_names4: string[] = [];
  image_names5: string[] = [];
  image_names6: string[] = [];
  image_names7: string[] = [];
  image_names8: string[] = [];
  image_names9: string[] = [];
  image_names10: string[] = [];
  image_names11: string[] = [];
  image_names12: string[] = [];
  image_names13: string[] = [];
  image_names14: string[] = [];
  image_names15: string[] = [];
  image_names16: string[] = [];
  image_names17: string[] = [];
  image_names18: string[] = [];
  image_names19: string[] = [];
  image_names20: string[] = [];
  image_names21: string[] = [];
  image_names22: string[] = [];
  image_names23: string[] = [];
  image_names24: string[] = [];
  image_names25: string[] = [];


  public first_text_area_value: string = '';
  public second_text_area_value: string = '';
  public third_text_area_value: string = '';
  public fourth_text_area_value: string = '';
  public fifth_text_area_value: string = '';
  public sixth_text_area_value: string = '';

  sevent_text_area_value: string = '';
  eighth_text_area_value: string = '';
  ninth_text_area_value: string = '';
  tenth_text_area_value: string = '';

  eleventh_text_area_value: string = '';
  tweleve_text_area_value: string = '';
  thirteen_text_area_value: string = '';
  fourteen_text_area_value: string = '';
  fifteen_text_area_value: string = '';

  sixteen_text_area_value: string = '';
  seventeen_text_area_value: string = '';
  eighteen_text_area_value: string = '';
  nineteen_text_area_value: string = '';
  twenty_text_area_value: string = '';

  twentyone_text_area_value: string = '';
  twentytwo_text_area_value: string = '';
  twentythree_text_area_value: string = '';
  twentyfour_text_area_value: string = '';
  twentyfive_text_area_value: string = '';


 
  text_view_generation_sequence: any[] = [];
  image_view_generation_sequence: any[] = [];
  generate_view_using_sequence: boolean = false;



  imageToShow1: any[] = [];
  imageToShow2: any[] = [];
  imageToShow3: any[] = [];
  imageToShow4: any[] = [];
  imageToShow5: any[] = [];
  imageToShow6: any[] = [];
  imageToShow7: any[] = [];
  imageToShow8: any[] = [];
  imageToShow9: any[] = [];
  imageToShow10: any[] = [];
  imageToShow11: any[] = [];
  imageToShow12: any[] = [];
  imageToShow13: any[] = [];
  imageToShow14: any[] = [];
  imageToShow15: any[] = [];
  imageToShow16: any[] = [];
  imageToShow17: any[] = [];
  imageToShow18: any[] = [];
  imageToShow19: any[] = [];
  imageToShow20: any[] = [];
  imageToShow21: any[] = [];
  imageToShow22: any[] = [];
  imageToShow23: any[] = [];
  imageToShow24: any[] = [];
  imageToShow25: any[] = [];


  image_names: string[] = [];

  image_name_array: string[] = [];

  imageNameArray1: string[] = [];
  imageNameArray2: string[] = [];
  imageNameArray3: string[] = [];
  imageNameArray4: string[] = [];
  imageNameArray5: string[] = [];
  imageNameArray6: string[] = [];
  imageNameArray7: string[] = [];
  imageNameArray8: string[] = [];
  imageNameArray9: string[] = [];
  imageNameArray10: string[] = [];
  imageNameArray11: string[] = [];
  imageNameArray12: string[] = [];
  imageNameArray13: string[] = [];
  imageNameArray14: string[] = [];
  imageNameArray15: string[] = [];
  imageNameArray16: string[] = [];
  imageNameArray17: string[] = [];
  imageNameArray18: string[] = [];
  imageNameArray19: string[] = [];
  imageNameArray20: string[] = [];
  imageNameArray21: string[] = [];
  imageNameArray22: string[] = [];
  imageNameArray23: string[] = [];
  imageNameArray24: string[] = [];
  imageNameArray25: string[] = [];


  public applicablity_first_time = false;
  stringToSubmit: string;
  stringToSelect: string;
  type_of_textarea: string = 'textarea';
  length_of_info: number = 0;

  private image_cloning_counter: number = 0;
  counter: number = 0;
  image_area_position_counter: number = 1;
  selfRef;
  index = 0;
  componentsReferences = [];
  imageComponentsReferences = []

  public parametersTemp: any;

  @ViewChild(TextareaComponent) textareaComponent;


  constructor(
    private spinner: NgxSpinnerService,
    private CFR: ComponentFactoryResolver,
    private formBuilder: FormBuilder,
    private svc: TopicService,
    private route: ActivatedRoute,
    private http: Http,
    private infoSvc: InformationService,
    private ref: ChangeDetectorRef,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private applicabilityService: ApplicabilityService,
    public authService: AuthService,
    private imageService: InformationImageService
  ) {

  }

  image_index = 0;
  max_image_cloning_reached: boolean;

  onImageClick(createJson: boolean, showPopup: boolean,displayMode:boolean) {

    if (showPopup) {
      if (this.image_cloning_counter > 24) {
        this.max_image_cloning_reached = true
        this.messageService.add({
          severity: 'warn',
          summary: 'Imagearea limit reached !',
          detail: 'You cannot have more than 25 Imagearea at a time',
          closable: true,
          life: 1000

        });
        return;
      }
    }

    if (createJson) {
      if (this.imagearea_no_counter > 0) {
        this.imagearea_no_counter = Math.max(...this.image_view_generation_sequence);
      }
      if (this.imagearea_no_counter == (-Infinity)) {
        this.imagearea_no_counter = 0;
      }
      this.prepareJsonOnImageClick();
    }

    let componentFactory = this.CFR.resolveComponentFactory(ImageareaComponent);
    let componentRef: ComponentRef < ImageareaComponent > = this.VCR.createComponent(componentFactory);
    let currentComponent = componentRef.instance;


    this.index++;
    currentComponent.compInteraction = this;
    componentRef.instance._ref = componentRef;
    this.image_cloning_counter++;
    this.image_index++;


    ( < ImageareaComponent > componentRef.instance).form = this.form;

    ( < ImageareaComponent > componentRef.instance).imageToShow1 = this.imageToShow1;
    ( < ImageareaComponent > componentRef.instance).imageToShow2 = this.imageToShow2;
    ( < ImageareaComponent > componentRef.instance).imageToShow3 = this.imageToShow3;
    ( < ImageareaComponent > componentRef.instance).imageToShow4 = this.imageToShow4;
    ( < ImageareaComponent > componentRef.instance).imageToShow5 = this.imageToShow5;
    ( < ImageareaComponent > componentRef.instance).imageToShow6 = this.imageToShow6;
    ( < ImageareaComponent > componentRef.instance).imageToShow7 = this.imageToShow7;
    ( < ImageareaComponent > componentRef.instance).imageToShow8 = this.imageToShow8;
    ( < ImageareaComponent > componentRef.instance).imageToShow9 = this.imageToShow9;
    ( < ImageareaComponent > componentRef.instance).imageToShow10 = this.imageToShow10;
    ( < ImageareaComponent > componentRef.instance).imageToShow11 = this.imageToShow11;
    ( < ImageareaComponent > componentRef.instance).imageToShow12 = this.imageToShow12;
    ( < ImageareaComponent > componentRef.instance).imageToShow13 = this.imageToShow13;
    ( < ImageareaComponent > componentRef.instance).imageToShow14 = this.imageToShow14;
    ( < ImageareaComponent > componentRef.instance).imageToShow15 = this.imageToShow15;
    ( < ImageareaComponent > componentRef.instance).imageToShow16 = this.imageToShow16;
    ( < ImageareaComponent > componentRef.instance).imageToShow17 = this.imageToShow17;
    ( < ImageareaComponent > componentRef.instance).imageToShow18 = this.imageToShow18;
    ( < ImageareaComponent > componentRef.instance).imageToShow19 = this.imageToShow19;
    ( < ImageareaComponent > componentRef.instance).imageToShow20 = this.imageToShow20;
    ( < ImageareaComponent > componentRef.instance).imageToShow21 = this.imageToShow21;
    ( < ImageareaComponent > componentRef.instance).imageToShow22 = this.imageToShow22;
    ( < ImageareaComponent > componentRef.instance).imageToShow23 = this.imageToShow23;
    ( < ImageareaComponent > componentRef.instance).imageToShow24 = this.imageToShow24;
    ( < ImageareaComponent > componentRef.instance).imageToShow25 = this.imageToShow25;



    this.detectFileCounter(componentRef);
    this.ImageBinaryData[this.image_index] = [];
    this.ImagesToBedeleted[this.image_index] = [];

    ( < ImageareaComponent > componentRef.instance).ImageBinaryData = this.ImageBinaryData[this.image_index];
  
    ( < ImageareaComponent > componentRef.instance).ImagesToBedeleted = this.ImagesToBedeleted[this.image_index];
   
    ( < ImageareaComponent > componentRef.instance).first_image_names_from_rest_call = this.first_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).second_image_names_from_rest_call = this.second_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).third_image_names_from_rest_call = this.third_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).fourth_image_names_from_rest_call = this.fourth_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).fifth_image_names_from_rest_call = this.fifth_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).sixth_image_names_from_rest_call = this.sixth_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).seven_image_names_from_rest_call = this.seven_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).eight_image_names_from_rest_call = this.eight_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).nine_image_names_from_rest_call = this.nine_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).ten_image_names_from_rest_call = this.ten_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).eleven_image_names_from_rest_call = this.eleven_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).twelve_image_names_from_rest_call = this.twelve_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).thirteen_image_names_from_rest_call = this.thirteen_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).fourteen_image_names_from_rest_call = this.fourteen_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).fifteen_image_names_from_rest_call = this.fifteen_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).sixteen_image_names_from_rest_call = this.sixteen_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).seventeen_image_names_from_rest_call = this.seventeen_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).eighteen_image_names_from_rest_call = this.eighteen_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).nineteen_image_names_from_rest_call = this.nineteen_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).twenty_image_names_from_rest_call = this.twenty_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).twenty_one_image_names_from_rest_call = this.twenty_one_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).twenty_two_image_names_from_rest_call = this.twenty_two_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).twenty_three_image_names_from_rest_call = this.twenty_three_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).twenty_four_image_names_from_rest_call = this.twenty_four_image_names_from_rest_call;
    ( < ImageareaComponent > componentRef.instance).twenty_five_image_names_from_rest_call = this.twenty_five_image_names_from_rest_call;


      let detectCaption = displayMode ? true : false;

    if(this.image_names_from_rest_call_collection[this.image_index - 1]){
      if(this.image_names_from_rest_call_collection[this.image_index - 1].length == 0) {
        ( < ImageareaComponent > componentRef.instance).disableCaption = false;
      }else {
        ( < ImageareaComponent > componentRef.instance).disableCaption = detectCaption;
      }
    }
    else {
      ( < ImageareaComponent > componentRef.instance).disableCaption = detectCaption;
    }
   


    if (this.generate_view_using_sequence) {
      if (this.image_view_generation_sequence.length > this.image_cloning_counter - 1)
        ( < ImageareaComponent > componentRef.instance).image_index = this.image_view_generation_sequence[this.image_cloning_counter - 1];

    } else {
      this.image_view_generation_sequence.push(this.image_index);
      ( < ImageareaComponent > componentRef.instance).image_index = this.image_index;
    }

    if (this.image_view_generation_sequence.length < this.image_cloning_counter) {
      this.image_view_generation_sequence.push(this.image_index);
      ( < ImageareaComponent > componentRef.instance).image_index = this.image_index;

    }

    ( < ImageareaComponent > componentRef.instance).image_names1 = this.image_names1;
    ( < ImageareaComponent > componentRef.instance).image_names2 = this.image_names2;
    ( < ImageareaComponent > componentRef.instance).image_names3 = this.image_names3;
    ( < ImageareaComponent > componentRef.instance).image_names4 = this.image_names4;
    ( < ImageareaComponent > componentRef.instance).image_names5 = this.image_names5;
    ( < ImageareaComponent > componentRef.instance).image_names6 = this.image_names6;
    ( < ImageareaComponent > componentRef.instance).image_names7 = this.image_names7;
    ( < ImageareaComponent > componentRef.instance).image_names8 = this.image_names8;
    ( < ImageareaComponent > componentRef.instance).image_names9 = this.image_names9;
    ( < ImageareaComponent > componentRef.instance).image_names10 = this.image_names10;
    ( < ImageareaComponent > componentRef.instance).image_names11 = this.image_names11;
    ( < ImageareaComponent > componentRef.instance).image_names12 = this.image_names12;
    ( < ImageareaComponent > componentRef.instance).image_names13 = this.image_names13;
    ( < ImageareaComponent > componentRef.instance).image_names14 = this.image_names14;
    ( < ImageareaComponent > componentRef.instance).image_names15 = this.image_names15;
    ( < ImageareaComponent > componentRef.instance).image_names16 = this.image_names16;
    ( < ImageareaComponent > componentRef.instance).image_names17 = this.image_names17;
    ( < ImageareaComponent > componentRef.instance).image_names18 = this.image_names18;
    ( < ImageareaComponent > componentRef.instance).image_names19 = this.image_names19;
    ( < ImageareaComponent > componentRef.instance).image_names20 = this.image_names20;
    ( < ImageareaComponent > componentRef.instance).image_names21 = this.image_names21;
    ( < ImageareaComponent > componentRef.instance).image_names22 = this.image_names22;
    ( < ImageareaComponent > componentRef.instance).image_names23 = this.image_names23;
    ( < ImageareaComponent > componentRef.instance).image_names24 = this.image_names24;
    ( < ImageareaComponent > componentRef.instance).image_names25 = this.image_names25;





    ( < ImageareaComponent > componentRef.instance).image_name_array = this.image_name_array;
    ( < ImageareaComponent > componentRef.instance).imageNameArray1 = this.imageNameArray1;
    ( < ImageareaComponent > componentRef.instance).imageNameArray2 = this.imageNameArray2;
    ( < ImageareaComponent > componentRef.instance).imageNameArray3 = this.imageNameArray3;
    ( < ImageareaComponent > componentRef.instance).imageNameArray4 = this.imageNameArray4;
    ( < ImageareaComponent > componentRef.instance).imageNameArray5 = this.imageNameArray5;
    ( < ImageareaComponent > componentRef.instance).imageNameArray6 = this.imageNameArray6;
    ( < ImageareaComponent > componentRef.instance).imageNameArray7 = this.imageNameArray7;
    ( < ImageareaComponent > componentRef.instance).imageNameArray8 = this.imageNameArray8;
    ( < ImageareaComponent > componentRef.instance).imageNameArray9 = this.imageNameArray9;
    ( < ImageareaComponent > componentRef.instance).imageNameArray10 = this.imageNameArray10;
    ( < ImageareaComponent > componentRef.instance).imageNameArray11 = this.imageNameArray11;
    ( < ImageareaComponent > componentRef.instance).imageNameArray12 = this.imageNameArray12;
    ( < ImageareaComponent > componentRef.instance).imageNameArray13 = this.imageNameArray13;
    ( < ImageareaComponent > componentRef.instance).imageNameArray14 = this.imageNameArray14;
    ( < ImageareaComponent > componentRef.instance).imageNameArray15 = this.imageNameArray15;
    ( < ImageareaComponent > componentRef.instance).imageNameArray16 = this.imageNameArray16;
    ( < ImageareaComponent > componentRef.instance).imageNameArray17 = this.imageNameArray17;
    ( < ImageareaComponent > componentRef.instance).imageNameArray18 = this.imageNameArray18;
    ( < ImageareaComponent > componentRef.instance).imageNameArray19 = this.imageNameArray19;
    ( < ImageareaComponent > componentRef.instance).imageNameArray20 = this.imageNameArray20;
    ( < ImageareaComponent > componentRef.instance).imageNameArray21 = this.imageNameArray21;
    ( < ImageareaComponent > componentRef.instance).imageNameArray22 = this.imageNameArray22;
    ( < ImageareaComponent > componentRef.instance).imageNameArray23 = this.imageNameArray23;
    ( < ImageareaComponent > componentRef.instance).imageNameArray24 = this.imageNameArray24;
    ( < ImageareaComponent > componentRef.instance).imageNameArray25 = this.imageNameArray25;

    let isImageEditable = displayMode ? false : true;

    ( < ImageareaComponent > componentRef.instance).is_image_editable1 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable2 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable3 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable4 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable5 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable6 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable7 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable8 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable9 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable10 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable11 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable12 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable13 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable14 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable15 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable16 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable17 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable18 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable19 =isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable20 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable21 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable22 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable23 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable24 = isImageEditable;
    ( < ImageareaComponent > componentRef.instance).is_image_editable25 = isImageEditable;

    let isImageAreaDisable = displayMode ? true : false;

    ( < ImageareaComponent > componentRef.instance).image_area_1_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_2_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_3_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_4_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_5_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_6_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_7_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_8_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_9_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_10_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_11_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_12_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_13_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_14_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_15_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_16_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_17_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_18_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_19_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_20_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_21_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_22_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_23_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_24_disabled = isImageAreaDisable;
    ( < ImageareaComponent > componentRef.instance).image_area_25_disabled = isImageAreaDisable;


    this.imageComponentsReferences.push(componentRef);
  }
  text_index = 0;
  max_text_cloning_reached: boolean;

  detectFileCounter(componentRef: ComponentRef < ImageareaComponent > ) {
    if (this.image_names_from_rest_call_collection.length > 0) {
      try {
        ( < ImageareaComponent > componentRef.instance).fileCounter =
          this.image_names_from_rest_call_collection[this.image_index - 1].length;
      } catch (error) {
        ( < ImageareaComponent > componentRef.instance).fileCounter = 0;
      }

    } else {
      return;
    }
  }



  onTextClick(createJson: boolean, showPopup: boolean,displayMode:boolean) {

    if (showPopup) {
      if (this.text_cloning_counter > 24) {
        this.max_text_cloning_reached = true
        this.messageService.add({
          severity: 'warn',
          summary: 'Textarea limit reached !',
          detail: 'You cannot have more than 25 Textarea at a time',
          closable: true,
          life: 1000

        });
        return;
      }
    }
    if (createJson) {
      if (this.textarea_no_counter > 0) {
        this.textarea_no_counter = Math.max(...this.text_view_generation_sequence);
      }
      if (this.textarea_no_counter == (-Infinity)) {
        this.textarea_no_counter = 0;
      }
      this.prepareJsonOnTextClick();
    }


    let componentFactory = this.CFR.resolveComponentFactory(TextareaComponent);
    let componentRef: ComponentRef < TextareaComponent > = this.VCR.createComponent(componentFactory);
    let currentComponent = componentRef.instance;

    this.selfRef = currentComponent;
    this.index++;
    this.text_index++;



    this.text_cloning_counter++;

    currentComponent.compInteraction = this;
    componentRef.instance._ref = componentRef;




    if (this.generate_view_using_sequence) {
      if (this.text_view_generation_sequence.length > this.text_cloning_counter - 1)
        ( < TextareaComponent > componentRef.instance).text_index = this.text_view_generation_sequence[this.text_cloning_counter - 1];
    } else {
      this.text_view_generation_sequence.push(this.text_index);
      ( < TextareaComponent > componentRef.instance).text_index = this.text_index;
    }

    if (this.text_view_generation_sequence.length < this.text_cloning_counter) {

      this.text_view_generation_sequence.push(this.text_index);
      ( < TextareaComponent > componentRef.instance).text_index = this.text_index;

    }

    ( < TextareaComponent > componentRef.instance).form = this.form;

    ( < TextareaComponent > componentRef.instance).popup_text_area_value = this.popup_text_area_value;


    ( < TextareaComponent > componentRef.instance).first_text_area_value = this.first_text_area_value;

    ( < TextareaComponent > componentRef.instance).second_text_area_value = this.second_text_area_value;
    ( < TextareaComponent > componentRef.instance).third_text_area_value = this.third_text_area_value;
    ( < TextareaComponent > componentRef.instance).fourth_text_area_value = this.fourth_text_area_value;
    ( < TextareaComponent > componentRef.instance).fifth_text_area_value = this.fifth_text_area_value;
    ( < TextareaComponent > componentRef.instance).sixth_text_area_value = this.sixth_text_area_value;



    ( < TextareaComponent > componentRef.instance).sevent_text_area_value = this.sevent_text_area_value;
    ( < TextareaComponent > componentRef.instance).eighth_text_area_value = this.eighth_text_area_value;
    ( < TextareaComponent > componentRef.instance).ninth_text_area_value = this.ninth_text_area_value;
    ( < TextareaComponent > componentRef.instance).tenth_text_area_value = this.tenth_text_area_value;
    ( < TextareaComponent > componentRef.instance).eleventh_text_area_value = this.eleventh_text_area_value;
    ( < TextareaComponent > componentRef.instance).tweleve_text_area_value = this.tweleve_text_area_value;

    ( < TextareaComponent > componentRef.instance).thirteen_text_area_value = this.thirteen_text_area_value;
    ( < TextareaComponent > componentRef.instance).fourteen_text_area_value = this.fourteen_text_area_value;
    ( < TextareaComponent > componentRef.instance).fifteen_text_area_value = this.fifteen_text_area_value;
    ( < TextareaComponent > componentRef.instance).sixteen_text_area_value = this.sixteen_text_area_value;
    ( < TextareaComponent > componentRef.instance).seventeen_text_area_value = this.seventeen_text_area_value;
    ( < TextareaComponent > componentRef.instance).eighteen_text_area_value = this.eighteen_text_area_value;

    ( < TextareaComponent > componentRef.instance).nineteen_text_area_value = this.nineteen_text_area_value;
    ( < TextareaComponent > componentRef.instance).twenty_text_area_value = this.twenty_text_area_value;
    ( < TextareaComponent > componentRef.instance).twentyone_text_area_value = this.twentyone_text_area_value;
    ( < TextareaComponent > componentRef.instance).twentytwo_text_area_value = this.twentytwo_text_area_value;
    ( < TextareaComponent > componentRef.instance).twentythree_text_area_value = this.twentythree_text_area_value;
    ( < TextareaComponent > componentRef.instance).twentyfour_text_area_value = this.twentyfour_text_area_value;

    ( < TextareaComponent > componentRef.instance).twentyfive_text_area_value = this.twentyfive_text_area_value;


    //(<TextareaComponent>componentRef.instance).sep_values = this.sep_values;
    ( < TextareaComponent > componentRef.instance).separator_dot = this.separator_dot;
    ( < TextareaComponent > componentRef.instance).separator_colon = this.separator_colon;
    ( < TextareaComponent > componentRef.instance).separator_semicolon = this.separator_semicolon;
    ( < TextareaComponent > componentRef.instance).separator_dash = this.separator_dash;
    ( < TextareaComponent > componentRef.instance).separator_rc = this.separator_rc;

    let isTextEditable = displayMode ? false : true;

    ( < TextareaComponent > componentRef.instance).is_text_editable1 = isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable2 = isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable3 = isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable4 = isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable5 = isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable6 = isTextEditable;

    ( < TextareaComponent > componentRef.instance).is_text_editable7 = isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable8 = isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable9 = isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable10 = isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable11 =  isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable12 =  isTextEditable;

    ( < TextareaComponent > componentRef.instance).is_text_editable13 =  isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable14 =  isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable15 =  isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable16 =  isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable17 =  isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable18 =  isTextEditable;

    ( < TextareaComponent > componentRef.instance).is_text_editable19 =  isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable20 =  isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable21 =  isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable22 =  isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable23 =  isTextEditable;
    ( < TextareaComponent > componentRef.instance).is_text_editable24 =  isTextEditable;

    ( < TextareaComponent > componentRef.instance).is_text_editable25 =  isTextEditable;

    let isTextDisable = displayMode ? true : false;

    ( < TextareaComponent > componentRef.instance).text_area_1_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_2_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_3_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_4_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_5_disabled =  isTextDisable;
    
    ( < TextareaComponent > componentRef.instance).text_area_6_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_7_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_8_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_9_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_10_disabled =  isTextDisable;

    ( < TextareaComponent > componentRef.instance).text_area_11_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_12_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_13_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_14_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_15_disabled =  isTextDisable;

    ( < TextareaComponent > componentRef.instance).text_area_16_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_17_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_18_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_19_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_20_disabled =  isTextDisable;

    ( < TextareaComponent > componentRef.instance).text_area_21_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_22_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_23_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_24_disabled =  isTextDisable;
    ( < TextareaComponent > componentRef.instance).text_area_25_disabled =  isTextDisable;
    

    this.componentsReferences.push(componentRef);

  }

  removeImageComponent(index: number) {

    let informations = ( < FormArray > this.form.controls['informations']);
    let areas = informations.at(0).get('areas') as FormArray;

    if (this.VCR.length < 1)
      return;

    let componentRef = this.imageComponentsReferences.filter(x => x.instance.image_index == index)[0];
    let vcrIndex: number = this.VCR.indexOf(componentRef)
    this.VCR.remove(vcrIndex);
    this.imageComponentsReferences = this.imageComponentsReferences.filter(x => x.instance.image_index !== index);


    this.image_index = this.image_index - 1;


    for (let i = 0; i < this.imageComponentsReferences.length; i++) {
      this.imageComponentsReferences[i]._component.image_index = i + 1;
    }


    this.image_cloning_counter = this.image_cloning_counter - 1;
    let count = 0;
    for (let i = 0; i < areas.length; i++) {
      if (areas.at(i).get('type').value == 'imagearea') {
        areas.at(i).get('imagearea_no').setValue(count + 1);
        this.imagearea_no_counter = count + 1;
        count++;
      }
    }
    if (areas.length == 0) {

      this.imageComponentsReferences = [];
    }

    if (this.imageComponentsReferences.length == 0) {
      this.imagearea_no_counter = 0;
      this.image_index = 0;
      this.resetAllImageFields();
    }


    for (let i = 0; i < this.imageComponentsReferences.length; i++) {

      switch (index) {

        case 1:
          this.imageComponentsReferences[i]._component.imageToShow1 =
            this.imageComponentsReferences[i]._component.imageToShow2;
          this.imageToShow1 = [];
          this.first_image_names_from_rest_call = [];

        case 2:

          this.imageComponentsReferences[i]._component.imageToShow2 =
            this.imageComponentsReferences[i]._component.imageToShow3;
          this.imageToShow2 = [];
          this.second_image_names_from_rest_call = [];

        case 3:
          this.imageComponentsReferences[i]._component.imageToShow3 =
            this.imageComponentsReferences[i]._component.imageToShow4;
          this.imageToShow3 = [];
          this.third_image_names_from_rest_call = [];

        case 4:
          this.imageComponentsReferences[i]._component.imageToShow4 =
            this.imageComponentsReferences[i]._component.imageToShow5;
          this.imageToShow4 = [];
          this.fourth_image_names_from_rest_call = [];

        case 5:
          this.imageComponentsReferences[i]._component.imageToShow5 =
            this.imageComponentsReferences[i]._component.imageToShow6;
          this.imageToShow5 = [];
          this.fifth_image_names_from_rest_call = [];

        case 6:
          this.imageComponentsReferences[i]._component.imageToShow6 =
            this.imageComponentsReferences[i]._component.imageToShow7;
          this.imageToShow6 = [];
          this.sixth_image_names_from_rest_call = [];


        case 7:
          this.imageComponentsReferences[i]._component.imageToShow7 =
            this.imageComponentsReferences[i]._component.imageToShow8;
          this.imageToShow7 = [];
          this.seven_image_names_from_rest_call = [];


        case 8:
          this.imageComponentsReferences[i]._component.imageToShow8 =
            this.imageComponentsReferences[i]._component.imageToShow9;
          this.imageToShow8 = [];
          this.eight_image_names_from_rest_call = [];

        case 9:
          this.imageComponentsReferences[i]._component.imageToShow9 =
            this.imageComponentsReferences[i]._component.imageToShow10;
          this.imageToShow9 = [];
          this.imageToShow9 = [];
          this.nine_image_names_from_rest_call = [];

        case 10:
          this.imageComponentsReferences[i]._component.imageToShow10 =
            this.imageComponentsReferences[i]._component.imageToShow11;
          this.imageToShow10 = [];
          this.ten_image_names_from_rest_call = [];

        case 11:
          this.imageComponentsReferences[i]._component.imageToShow11 =
            this.imageComponentsReferences[i]._component.imageToShow12;
          this.imageToShow11 = [];
          this.eleven_image_names_from_rest_call = [];


        case 12:
          this.imageComponentsReferences[i]._component.imageToShow12 =
            this.imageComponentsReferences[i]._component.imageToShow13;
          this.imageToShow12 = [];
          this.twelve_image_names_from_rest_call = [];


        case 13:
          this.imageComponentsReferences[i]._component.imageToShow13 =
            this.imageComponentsReferences[i]._component.imageToShow14;
          this.imageToShow13 = [];
          this.thirteen_image_names_from_rest_call = [];


        case 14:
          this.imageComponentsReferences[i]._component.imageToShow14 =
            this.imageComponentsReferences[i]._component.imageToShow15;
          this.imageToShow14 = [];
          this.fourteen_image_names_from_rest_call = [];


        case 15:
          this.imageComponentsReferences[i]._component.imageToShow15 =
            this.imageComponentsReferences[i]._component.imageToShow16;
          this.imageToShow15 = [];
          this.fifteen_image_names_from_rest_call = [];


        case 16:
          this.imageComponentsReferences[i]._component.imageToShow16 =
            this.imageComponentsReferences[i]._component.imageToShow17;
          this.imageToShow16 = [];
          this.sixteen_image_names_from_rest_call = [];


        case 17:
          this.imageComponentsReferences[i]._component.imageToShow17 =
            this.imageComponentsReferences[i]._component.imageToShow18;
          this.imageToShow17 = [];
          this.seventeen_image_names_from_rest_call = [];


        case 18:
          this.imageComponentsReferences[i]._component.imageToShow18 =
            this.imageComponentsReferences[i]._component.imageToShow19;
          this.imageToShow18 = [];
          this.eighteen_image_names_from_rest_call = [];

        case 19:
          this.imageComponentsReferences[i]._component.imageToShow19 =
            this.imageComponentsReferences[i]._component.imageToShow20;
          this.imageToShow19 = [];
          this.nineteen_image_names_from_rest_call = [];

        case 20:
          this.imageComponentsReferences[i]._component.imageToShow20 =
            this.imageComponentsReferences[i]._component.imageToShow21;
          this.imageToShow20 = [];
          this.twenty_image_names_from_rest_call = [];

        case 21:
          this.imageComponentsReferences[i]._component.imageToShow21 =
            this.imageComponentsReferences[i]._component.imageToShow22;
          this.imageToShow21 = [];
          this.twenty_one_image_names_from_rest_call = [];

        case 22:
          this.imageComponentsReferences[i]._component.imageToShow22 =
            this.imageComponentsReferences[i]._component.imageToShow23;
          this.imageToShow22 = [];
          this.twenty_two_image_names_from_rest_call = [];

        case 23:
          this.imageComponentsReferences[i]._component.imageToShow23 =
            this.imageComponentsReferences[i]._component.imageToShow24;
          this.imageToShow23 = [];
          this.twenty_three_image_names_from_rest_call = [];


        case 24:
          this.imageComponentsReferences[i]._component.imageToShow24 =
            this.imageComponentsReferences[i]._component.imageToShow25;
          this.imageToShow24 = [];
          this.twenty_four_image_names_from_rest_call = [];

        case 25:
          this.imageComponentsReferences[i]._component.imageToShow25 =
            '';
          this.imageToShow25 = [];
          this.twenty_five_image_names_from_rest_call = [];
      }

      switch (index) {

        case 1:
          this.imageComponentsReferences[i]._component.image_names1 =
            this.imageComponentsReferences[i]._component.image_names2;
          this.image_names1 = [];

        case 2:
          this.imageComponentsReferences[i]._component.image_names2 =
            this.imageComponentsReferences[i]._component.image_names3;
          this.image_names2 = [];

        case 3:
          this.imageComponentsReferences[i]._component.image_names3 =
            this.imageComponentsReferences[i]._component.image_names4;
          this.image_names3 = [];

        case 4:
          this.imageComponentsReferences[i]._component.image_names4 =
            this.imageComponentsReferences[i]._component.image_names5;
          this.image_names4 = [];

        case 5:
          this.imageComponentsReferences[i]._component.image_names5 =
            this.imageComponentsReferences[i]._component.image_names6;
          this.image_names5 = [];

        case 6:
          this.imageComponentsReferences[i]._component.image_names6 =
            this.imageComponentsReferences[i]._component.image_names7;
          this.image_names6 = [];

        case 7:
          this.imageComponentsReferences[i]._component.image_names7 =
            this.imageComponentsReferences[i]._component.image_names8;
          this.image_names7 = [];

        case 8:
          this.imageComponentsReferences[i]._component.image_names8 =
            this.imageComponentsReferences[i]._component.image_names9;
          this.image_names8 = [];

        case 9:
          this.imageComponentsReferences[i]._component.image_names9 =
            this.imageComponentsReferences[i]._component.image_names10;
          this.image_names9 = [];

        case 10:
          this.imageComponentsReferences[i]._component.image_names10 =
            this.imageComponentsReferences[i]._component.image_names11;
          this.image_names10 = [];

        case 11:
          this.imageComponentsReferences[i]._component.image_names11 =
            this.imageComponentsReferences[i]._component.image_names12;
          this.image_names11 = [];

        case 12:
          this.imageComponentsReferences[i]._component.image_names12 =
            this.imageComponentsReferences[i]._component.image_names13;
          this.image_names12 = [];


        case 13:
          this.imageComponentsReferences[i]._component.image_names13 =
            this.imageComponentsReferences[i]._component.image_names14;
          this.image_names13 = [];


        case 14:
          this.imageComponentsReferences[i]._component.image_names14 =
            this.imageComponentsReferences[i]._component.image_names15;
          this.image_names14 = [];


        case 15:
          this.imageComponentsReferences[i]._component.image_names15 =
            this.imageComponentsReferences[i]._component.image_names16;
          this.image_names15 = [];

        case 16:
          this.imageComponentsReferences[i]._component.image_names16 =
            this.imageComponentsReferences[i]._component.image_names17;
          this.image_names16 = [];


        case 17:
          this.imageComponentsReferences[i]._component.image_names17 =
            this.imageComponentsReferences[i]._component.image_names18;
          this.image_names17 = [];


        case 18:
          this.imageComponentsReferences[i]._component.image_names18 =
            this.imageComponentsReferences[i]._component.image_names19;
          this.image_names18 = [];

        case 19:
          this.imageComponentsReferences[i]._component.image_names19 =
            this.imageComponentsReferences[i]._component.image_names20;
          this.image_names19 = [];

        case 20:
          this.imageComponentsReferences[i]._component.image_names20 =
            this.imageComponentsReferences[i]._component.image_names21;
          this.image_names20 = [];

        case 21:
          this.imageComponentsReferences[i]._component.image_names21 =
            this.imageComponentsReferences[i]._component.image_names22;
          this.image_names21 = [];

        case 22:
          this.imageComponentsReferences[i]._component.image_names22 =
            this.imageComponentsReferences[i]._component.image_names23;
          this.image_names22 = [];

        case 23:
          this.imageComponentsReferences[i]._component.image_names23 =
            this.imageComponentsReferences[i]._component.image_names24;
          this.image_names23 = [];


        case 24:
          this.imageComponentsReferences[i]._component.image_names24 =
            this.imageComponentsReferences[i]._component.image_names25;
          this.image_names24 = [];

        case 25:
          this.imageComponentsReferences[i]._component.image_names25 =
            '';
          this.image_names25 = [];
      }


    }



  }


  removeComponent(index: number) {


    if (this.VCR.length < 1)
      return;

    let componentRef = this.componentsReferences.filter(x => x.instance.text_index == index)[0];

    let vcrIndex: number = this.VCR.indexOf(componentRef)

    // removing component from container
    this.VCR.remove(vcrIndex);

    this.componentsReferences = this.componentsReferences.filter(x => x.instance.text_index !== index);




    let informations = ( < FormArray > this.form.controls['informations']);
    let areas = informations.at(0).get('areas') as FormArray;
    this.text_index = this.text_index - 1;
    let counter = 1;



    // this.viewChildren.forEach(instance => 
    //   this.componentsReferences =   instance._parentView.component.componentsReferences
    // )



    for (let i = 0; i < this.componentsReferences.length; i++) {
      this.componentsReferences[i]._component.text_index = i + 1;

    }

    for (let i = 0; i < this.componentsReferences.length; i++) {

      switch (index) {

        case 1:
          this.componentsReferences[i]._component.first_text_area_value =
            this.componentsReferences[i]._component.second_text_area_value;
          this.first_text_area_value = '';
          
        case 2:
          this.componentsReferences[i]._component.second_text_area_value =
            this.componentsReferences[i]._component.third_text_area_value;
          this.second_text_area_value = '';

        case 3:
          this.componentsReferences[i]._component.third_text_area_value =
            this.componentsReferences[i]._component.fourth_text_area_value;
          this.third_text_area_value = '';

        case 4:
          this.componentsReferences[i]._component.fourth_text_area_value =
            this.componentsReferences[i]._component.fifth_text_area_value;
          this.fourth_text_area_value = '';

        case 5:
          this.componentsReferences[i]._component.fifth_text_area_value =
            this.componentsReferences[i]._component.sixth_text_area_value;
          this.fifth_text_area_value = '';

        case 6:
          this.componentsReferences[i]._component.sixth_text_area_value =
            this.componentsReferences[i]._component.sevent_text_area_value;
          this.sixth_text_area_value = '';

        case 7:
          this.componentsReferences[i]._component.sevent_text_area_value =
            this.componentsReferences[i]._component.eighth_text_area_value;
          this.sevent_text_area_value = '';

        case 8:
          this.componentsReferences[i]._component.eighth_text_area_value =
            this.componentsReferences[i]._component.ninth_text_area_value;
          this.eighth_text_area_value = '';

        case 9:
          this.componentsReferences[i]._component.ninth_text_area_value =
            this.componentsReferences[i]._component.tenth_text_area_value;
          this.ninth_text_area_value = '';

        case 10:
          this.componentsReferences[i]._component.tenth_text_area_value =
            this.componentsReferences[i]._component.eleventh_text_area_value;
          this.tenth_text_area_value = '';

        case 11:
          this.componentsReferences[i]._component.eleventh_text_area_value =
            this.componentsReferences[i]._component.tweleve_text_area_value;
          this.eleventh_text_area_value = '';

        case 12:
          this.componentsReferences[i]._component.tweleve_text_area_value =
            this.componentsReferences[i]._component.thirteen_text_area_value;
          this.tweleve_text_area_value = '';

        case 13:
          this.componentsReferences[i]._component.thirteen_text_area_value =
            this.componentsReferences[i]._component.fourteen_text_area_value;
          this.thirteen_text_area_value = '';

        case 14:
          this.componentsReferences[i]._component.fourteen_text_area_value =
            this.componentsReferences[i]._component.fifteen_text_area_value;
          this.fourteen_text_area_value = '';

        case 15:
          this.componentsReferences[i]._component.fifteen_text_area_value =
            this.componentsReferences[i]._component.sixteen_text_area_value;
          this.fourteen_text_area_value = '';

        case 16:
          this.componentsReferences[i]._component.sixteen_text_area_value =
            this.componentsReferences[i]._component.seventeen_text_area_value;
          this.sixteen_text_area_value = '';

        case 17:
          this.componentsReferences[i]._component.seventeen_text_area_value =
            this.componentsReferences[i]._component.eighteen_text_area_value;
          this.seventeen_text_area_value = '';

        case 18:
          this.componentsReferences[i]._component.eighteen_text_area_value =
            this.componentsReferences[i]._component.nineteen_text_area_value;
          this.eighth_text_area_value = '';

        case 19:
          this.componentsReferences[i]._component.nineteen_text_area_value =
            this.componentsReferences[i]._component.twenty_text_area_value;
          this.nineteen_text_area_value = '';

        case 20:
          this.componentsReferences[i]._component.twenty_text_area_value =
            this.componentsReferences[i]._component.twentyone_text_area_value;
          this.twenty_text_area_value = '';

        case 21:
          this.componentsReferences[i]._component.twentyone_text_area_value =
            this.componentsReferences[i]._component.twentytwo_text_area_value;
          this.twentyone_text_area_value = '';

        case 22:
          this.componentsReferences[i]._component.twentytwo_text_area_value =
            this.componentsReferences[i]._component.twentythree_text_area_value;
          this.twentytwo_text_area_value = '';

        case 23:
          this.componentsReferences[i]._component.twentythree_text_area_value =
            this.componentsReferences[i]._component.twentyfour_text_area_value;
          this.twentythree_text_area_value = '';

        case 24:
          this.componentsReferences[i]._component.twentyfour_text_area_value =
            this.componentsReferences[i]._component.twentyfive_text_area_value;
          this.twentyfour_text_area_value = '';

        case 25:
          this.componentsReferences[i]._component.twentyfive_text_area_value =
            '';
          this.twentyfive_text_area_value = '';
      }


    }

    this.text_cloning_counter = this.text_cloning_counter - 1;
    let count = 0;
    for (let i = 0; i < areas.length; i++) {
      if (areas.at(i).get('type').value == 'textarea') {
        areas.at(i).get('textarea_no').setValue(count + 1);
        this.textarea_no_counter = count + 1;
        count++;
      }

    }
    if (areas.length == 0) {
      this.textarea_no_counter = 0;
      this.text_index = 0;
      this.componentsReferences = [];
    }

    if (this.componentsReferences.length == 0) {
      this.textarea_no_counter = 0;
      this.text_index = 0;
      this.emptyAllTextareas();
    }
  }


  createImageFromBlob(image: Blob, imageAreaNumber: number, imagePosition: number, filename: string) {
    let reader = new FileReader();
    reader.addEventListener("load", () => {
      this.setImages(imageAreaNumber, imagePosition, reader, filename);
    }, false);
    if (image) {
      reader.readAsDataURL(image);
    }
  }
  setImages(imageAreaNumber: number, imagePosition: number, reader: FileReader, filename: string) {

    if (imageAreaNumber === 1)
      this.imageToShow1[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 2)
      this.imageToShow2[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 3)
      this.imageToShow3[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 4)
      this.imageToShow4[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 5)
      this.imageToShow5[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 6)
      this.imageToShow6[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 7)
      this.imageToShow7[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 8)
      this.imageToShow8[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 9)
      this.imageToShow9[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 10)
      this.imageToShow10[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 11)
      this.imageToShow11[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 12)
      this.imageToShow12[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 13)
      this.imageToShow13[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 14)
      this.imageToShow14[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 15)
      this.imageToShow15[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 16)
      this.imageToShow16[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 17)
      this.imageToShow17[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 18)
      this.imageToShow18[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 19)
      this.imageToShow19[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 20)
      this.imageToShow20[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 21)
      this.imageToShow21[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 22)
      this.imageToShow22[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 23)
      this.imageToShow23[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 24)
      this.imageToShow24[imagePosition] = [reader.result, filename];

    if (imageAreaNumber === 25)
      this.imageToShow25[imagePosition] = [reader.result, filename];


  }

  getImageFromService(partId: string, filename: string, index: number, imagePosition: number) {
    this.infoSvc.getImage(partId, filename).subscribe(data => {
      this.createImageFromBlob(data, index, imagePosition, filename);
    }, error => {
      console.log(error);
    });
  }

  info_data: any[] = [];
  info_area: any[] = [];
  text_data: string;
  text_area_value: string[] = [];
  image_data: any[] = [];
  image_area_value: string[] = [];
  image_dataa: string;
  selecting_from_list: boolean;

  form = new FormGroup({});

  image_url: string;

  addnewPart() {

    let programmingFormArray = this.form.get('areas') as FormArray;

    programmingFormArray.push(new FormGroup({
      partId: new FormControl(''),
      type: new FormControl(''),
      position: new FormControl(''),
      phraseId: new FormControl(''),
      value: new FormControl('')
    }));
  }

  selectInformation(id ? : number, showSpinner ? : boolean) {

    if (id == undefined && this.selectedInformation == undefined) {
      return;
    }

    if (!showSpinner && this.selectedInformation !== '')
      this.spinner.show();

    this.disableCaption = true;
    this.text_cloning_counter = 0;
    this.image_cloning_counter = 0;
    this.max_image_cloning_reached = false;
    this.max_text_cloning_reached = false;
    this.area_position_counter = 0;

    this.text_index = 0;
    this.image_index = 0;

    this.authService.isAllChecked.next(false);
    this.form = new FormGroup({});
    this.index = 0;
    this.componentsReferences = [];
    this.imageComponentsReferences = [];
    this.VCR.clear();


    this.selecting_from_list = true;
    this.topic_id = '';
    this.information_id = null;
    this.enable_information_screen = true;
    this.text_area_value = [];
    this.image_area_value = [];
    this.info_area = [];


    this.text_cloning_counter = 0;


    this.first_text_area_value = '';
    this.second_text_area_value = '';
    this.third_text_area_value = '';
    this.fourth_text_area_value = '';
    this.fifth_text_area_value = '';
    this.sixth_text_area_value = '';

    this.sevent_text_area_value = '';
    this.eighth_text_area_value = '';
    this.ninth_text_area_value = '';
    this.tenth_text_area_value = '';

    this.eleventh_text_area_value = '';
    this.tweleve_text_area_value = '';
    this.thirteen_text_area_value = '';
    this.fourteen_text_area_value = '';
    this.fifteen_text_area_value = '';

    this.sixteen_text_area_value = '';
    this.seventeen_text_area_value = '';
    this.eighteen_text_area_value = '';
    this.nineteen_text_area_value = '';
    this.twenty_text_area_value = '';

    this.twentyone_text_area_value = '';
    this.twentytwo_text_area_value = '';
    this.twentythree_text_area_value = '';
    this.twentyfour_text_area_value = '';
    this.twentyfive_text_area_value = '';





    this.imageToShow1 = [];
    this.imageToShow2 = [];
    this.imageToShow3 = [];
    this.imageToShow4 = [];
    this.imageToShow5 = [];
    this.imageToShow6 = [];
    this.imageToShow7 = [];
    this.imageToShow8 = [];
    this.imageToShow9 = [];
    this.imageToShow10 = [];
    this.imageToShow11 = [];
    this.imageToShow12 = [];
    this.imageToShow13 = [];
    this.imageToShow14 = [];
    this.imageToShow15 = [];
    this.imageToShow16 = [];
    this.imageToShow17 = [];
    this.imageToShow18 = [];
    this.imageToShow19 = [];
    this.imageToShow20 = [];
    this.imageToShow21 = [];
    this.imageToShow22 = [];
    this.imageToShow23 = [];
    this.imageToShow24 = [];
    this.imageToShow25 = [];

    this.selectedInformationId = this.selectedInformation.id ? this.selectedInformation.id : id;

    this.infoSvc.getInformationsById(id ? id : this.selectedInformation.id).subscribe((data: any) => {

      this.jsonObject = data;

      this.title_of_information = this.jsonObject.title;
      this.informationId = this.jsonObject.id;

      //Gets the Json Ready to be edited afterwards..
      this.prepareJsonFromGetCall();

      let info = ( < FormArray > this.form.controls['informations']);
      let applicability = info.at(0).get('applicability') as FormGroup;
      let criterias = applicability.get('criterias') as FormArray;

      if (this.jsonObject.areas)
        this.length_of_info = this.jsonObject.areas.length;

      for (let i = 0; i < this.length_of_info; i++) {
        this.info_area[i] = this.jsonObject.areas[i];
      }
      for (let i = 0, k = -1, n = -1; i < this.info_area.length; i++) {


        if (this.info_area[i].type === 'textarea') {
          n++;
          this.text_data = '';
          this.info_data = this.info_area[i].parts;
          for (let j = 0; j < this.info_data.length; j++) {
            this.text_data += this.info_data[j].value;
          }
          this.text_area_value[n] = this.text_data;
        }

        if (this.info_area[i].type === 'imagearea') {
          k++;
          this.image_dataa = '';
          this.info_data = this.info_area[i].parts;
          for (let j = 0; j < this.info_data.length; j++) {
            this.image_dataa += this.info_data[j].value + ' ';

          }
          this.image_area_value[k] = this.image_dataa;
        }

      }



      this.reOrderTextInformation();
      this.reOrderImageInformation();



      if (this.jsonObject.applicability != null) {

        if(this.jsonObject.applicability.criterias)
        if (this.jsonObject.applicability.criterias.length >= 0) {

          if (this.jsonObject.applicability.type === 'C') {
            this.parameters = [];
          } else {
            this.parameters = [];
            for (let i = 0; i < this.parametersTemp.length; i++) {
              this.parametersTemp[i].selected = false;
            }
            this.parameters = this.parametersTemp;
          }
          for (let count = 0; count < this.jsonObject.applicability.criterias.length; count++) {
            let criteria = this.jsonObject.applicability.criterias[count];

            if (this.jsonObject.applicability.type === 'V') {

              for (let i = 0; i < this.parameters.length; i++) {
                let parametersLabel = this.parameters[i].value;
                let applicabilityLabel = criteria.value;
                if (parametersLabel == applicabilityLabel) {
                  this.parameters[i].selected = true;
                }
              }
            } else {
              this.parameters.push(criteria);
              this.parameters[count].type = 'C';
            }
          }
        }
      }

      if (criterias.length == this.parameters.length) {

        this.authService.isAllChecked.next(true);
      } else {

        this.authService.isAllChecked.next(false);
      }

      if (this.jsonObject.applicability) {
        this.jsonObject.applicability.type == 'C' ? this.complex_app = true : this.complex_app = false;
      } else {
        this.complex_app = false;
      }

      /* If the information has Simple applicability then the checked applicability will be displayed first*/
      if (!this.complex_app) {
        let chekcedApp = [];
        let unCheckedApp = [];

        /*To ensure that every time the checked and uncheked array are empty before processing */
        chekcedApp.splice(0, chekcedApp.length);
        unCheckedApp.splice(0, unCheckedApp.length);


        for (let i = 0; i < this.parameters.length; i++) {
          if (this.parameters[i].selected) {
            chekcedApp.push(this.parameters[i]);
          } else {
            unCheckedApp.push(this.parameters[i]);
          }
        }

        this.parameters.splice(0, this.parameters.length);
        
        chekcedApp.sort((a,b) => this.compare(a,b))
        this.parameters.push(...chekcedApp);

        unCheckedApp.sort((a,b) => this.compare(a,b))
        this.parameters.push(...unCheckedApp);
        

      }

      this.image_area_value = [];
      this.generateView();

      setTimeout(() => {
        this.spinner.hide();
      }, 1);

    });
    /** spinner ends after Loading all the data */

  }

  generateView() {
    let informations = ( < FormArray > this.form.controls['informations']);
    let areas = informations.at(0).get('areas') as FormArray;
    for (let i = 0; i < areas.length; i++) {
      if (areas.at(i).get('type').value == 'textarea') {
        this.onTextClick(false, false,true);
      }
      if (areas.at(i).get('type').value == 'imagearea') {
        this.onImageClick(false, false,true);
      }
    }
  }



  topicid: any;

  ngOnDestroy() {

    localStorage.removeItem('saise_visited');

  }


   compare(a,b) {
    if (a.value < b.value)
      return -1;
    if (a.value > b.value)
      return 1;
    return 0;
  }

  ngOnInit() {
    if (localStorage.getItem('saise_visited') == 'true') {

      this.authService.isSaise.next(true);

    }

    this.route.params.subscribe(params => {
      this.stringToSubmit = params.stringToSubmit;
      this.svc.getTopicById(this.stringToSubmit).subscribe((data: any) => {
        this.topic = data;
        this.topicInformations = data.informations;
        this.topicid = this.topic.id;

      });
    });

    this.route.params.subscribe(params1 => {
      this.paramToSubmit = params1.paramToSubmit;
      this.infoSvc.getParametersByType(this.paramToSubmit).subscribe((data: Array < object > ) => {
        data.sort((a,b) => 
         this.compare(a,b)
        ); 
        this.parameters = data;
        this.parametersTemp = data;
    

      });
    });


    // this.parameters = Array.prototype.sort.apply(this.parameters);

    this.route.params.subscribe(params2 => {
      this.paramToSubmit = params2.paramToSubmit;
      this.infoSvc.getParametersBySeparator(this.paramToSubmit).subscribe((data: Array < object > ) => {
        this.separators = data;
        for (var i = 0; i < this.separators.length; i++) {
          if (this.separators[i].label == ".") {
            this.separator_dot = this.separators[i].value;
          } else if (this.separators[i].label == ":") {
            this.separator_colon = this.separators[i].value;
          } else if (this.separators[i].label == ";") {
            this.separator_semicolon = this.separators[i].value;
          } else if (this.separators[i].label == "-") {
            this.separator_dash = this.separators[i].value;
          } else if (this.separators[i].label == ".RC") {
            this.separator_rc = this.separators[i].value;
          }
        }
      });
    });
  }

  createImageParts(value, index, type, partId): FormGroup {
    return new FormGroup({
      partId: new FormControl(partId),
      type: new FormControl(type),
      position: new FormControl(index + 1),
      value: new FormControl(value[index])
    })
  }


  createAreaGroup(informations: any) {

    let info = ( < FormGroup > informations.at(0));
    let areas = info.get('areas') as FormArray;
    areas.push(new FormGroup({
      type: new FormControl('imagearea'),
      position: new FormControl(this.image_area_position_counter),
      parts: new FormArray([])
    }));
    this.image_area_position_counter++;
  }

  @ViewChild('saveButton') saveButton;

  saveInformation(reorder ? : boolean) {
    
    this.generate_view_using_sequence = true;
    if (this.title_of_information == '') {
      this.messageService.add({
        severity: 'warn',
        summary: 'Title is Mandatory !',
        detail: 'Please Enter a Title',
        closable: true,
        life: 2000

      });
      return;
    }

    this.spinner.show();
    
    for(let imageArea = 0; imageArea < this.ImageBinaryData.length; imageArea++){
          if(this.ImageBinaryData[imageArea]) {
            
            for(let image=0; image < this.ImageBinaryData[imageArea].length; image++){

              this.infoSvc.persistImages(
                this.ImageBinaryData[imageArea][image].file,
                this.ImageBinaryData[imageArea][image].id,
                this.ImageBinaryData[imageArea][image].fileName).subscribe((data => {
                  
                }));

            }

          }
    }
    
    if(this.ImagesToBedeleted)
    for(let imageArae = 0 ; imageArae < this.ImagesToBedeleted.length ; imageArae++) {

      if(this.ImagesToBedeleted[imageArae])
      for(let image=0 ; image < this.ImagesToBedeleted[imageArae].length; image++) {

        this.imageService.deleteImage(
          this.ImagesToBedeleted[imageArae][image].fileName
        ).subscribe(data => console.log);
      }

    }
   


    this.svc.persistInformation(JSON.stringify(this.form.value)).subscribe((data => {

      //  this.enable_information_screen = false;

      this.messageService.add({
        severity: 'success',
        summary: 'Information Saved Successfully',
        closable: true,
        life: 2000
      });

      this.selectInformation(parseInt(JSON.stringify(data)), false);

      this.svc.getTopicById(this.stringToSubmit).subscribe((data: any) => {
        this.topic = data;
        this.topicInformations = data.informations;
        this.topicid = this.topic.id;

      });
    }));
    this.route.params.subscribe(params1 => {
      this.paramToSubmit = params1.paramToSubmit;
      this.infoSvc.getParametersByType(this.paramToSubmit).subscribe((data: Array < object > ) => {
        this.parameters = data;
        this.parametersTemp = data;
      });
    });

    this.resetFields();

  }

  onClickPlus() {

    this.form = new FormGroup({});
    this.text_view_generation_sequence = [];
    this.image_view_generation_sequence = [];
    this.generate_view_using_sequence = false;
    this.ImageBinaryData = [];
    this.ImagesToBedeleted = [];
    this.imageComponentsReferences = [];
    this.componentsReferences = [];
    this.image_names_from_rest_call = [];
    this.image_names_from_rest_call_collection = [];
    this.popup_text_area_value = [];
    this.first_image_names_from_rest_call = [];

    this.second_image_names_from_rest_call = [];
    this.third_image_names_from_rest_call = [];
    this.fourth_image_names_from_rest_call = [];
    this.fifth_image_names_from_rest_call = [];
    this.sixth_image_names_from_rest_call = [];
    this.seven_image_names_from_rest_call = [];
    this.eight_image_names_from_rest_call = [];
    this.nine_image_names_from_rest_call = [];
    this.ten_image_names_from_rest_call = [];
    this.eleven_image_names_from_rest_call = [];
    this.twelve_image_names_from_rest_call = [];
    this.thirteen_image_names_from_rest_call = [];
    this.fourteen_image_names_from_rest_call = [];
    this.fifteen_image_names_from_rest_call = [];
    this.sixteen_image_names_from_rest_call = [];
    this.seventeen_image_names_from_rest_call = [];
    this.eighteen_image_names_from_rest_call = [];
    this.nineteen_image_names_from_rest_call = [];
    this.twenty_image_names_from_rest_call = [];
    this.twenty_one_image_names_from_rest_call = [];
    this.twenty_two_image_names_from_rest_call = [];
    this.twenty_three_image_names_from_rest_call = [];
    this.twenty_four_image_names_from_rest_call = [];
    this.twenty_five_image_names_from_rest_call = [];

    this.enable_information_screen = true;

    this.resetApplicability();

    this.resetFields();
  }

  deleteConfirm() {
    this.confirmationService.confirm({
      message: 'Do you want to delete this information?',
      header: 'Delete Confirmation',
      icon: 'pi pi-info-circle',
      accept: () => {
        this.deleteInformation();
      },
      reject: () => {
        console.log('You have rejected');
      }
    });
  }


  deleteInformation() {
    this.infoSvc.deleteInformation(this.informationId).subscribe((data => {
      this.messageService.add({
        severity: 'success',
        summary: 'Information Deleted Successfully',
        closable: true,
        life: 2000
      });
      this.svc.getTopicById(this.stringToSubmit).subscribe((data: any) => {
        this.topic = data;
        this.topicInformations = data.informations;
        this.topicid = this.topic.id;
      });
      this.route.params.subscribe(params1 => {
        this.paramToSubmit = params1.paramToSubmit;
        this.infoSvc.getParametersByType(this.paramToSubmit).subscribe((data: Array < object > ) => {
          this.parameters = data;
          this.parametersTemp = data;
        });
      });
      this.enable_information_screen = false;
      this.resetFields();
    }));
  }
  value;
  id;
  dontCreateJson = false;
  prepareJson() {
    this.id = this.topicid;
    let informations = this.form.get('informations') as FormArray;
    this.value = this.title_of_information;

    if (this.dontCreateJson == false) {
      this.form.addControl('informations', new FormArray([
        new FormGroup({
          id: new FormControl(),
          title: new FormControl(this.title_of_information),
          areas: new FormArray([])
        })
      ]));
      this.dontCreateJson = true;
    }
    if (this.dontCreateJson) {

      informations.at(0).get('title').setValue(this.value);
      informations.at(0).get('id').setValue(this.id);
    }
  }

  createApplicability(info, parameterValue) {
    this.checkFormState();
    let type = 'V';
    if (this.jsonObject.applicability) {
      type = this.jsonObject.applicability.type ? this.jsonObject.applicability.type : 'V'
    }

    let informations = this.form.get('informations') as FormArray;
    ( < FormGroup > informations.at(0)).addControl('applicability', new FormGroup({
      type: new FormControl(type),
      criterias: new FormArray([
        new FormGroup({
          label: new FormControl(parameterValue),
          value: new FormControl(parameterValue),
          selected: new FormControl(true),
          lcdvcharacterstics: new FormArray([])
        })
      ])
    }));
    let applicability = informations.at(0).get('applicability') as FormGroup;
    let criterias = applicability.get('criterias') as FormArray;

    if (this.jsonObject.applicability)
      if (this.jsonObject.applicability.type === 'C') {
        if (this.jsonObject.applicability.criterias.length > 0) {
          for (let i = 0; i < this.jsonObject.applicability.criterias.length; i++) {
            if (this.jsonObject.applicability.criterias[i].lcdvcharacterstics.length > 0) {
              for (let k = 0; k < this.jsonObject.applicability.criterias[i].lcdvcharacterstics.length; k++) {


                let lcdv = this.jsonObject.applicability.criterias[i].lcdvcharacterstics[k];
                let lcdvcharacterstics = criterias.at(i).get('lcdvcharacterstics') as FormArray;
                lcdvcharacterstics.push(
                  new FormGroup({
                    lcdvLabel: new FormControl(lcdv.lcdvLabel),
                    lcdvCode: new FormControl(lcdv.lcdvCode),
                  })
                );


              }
            }
          }
        }
      }
    let infor = this.form.get('informations') as FormArray;
    let app = infor.at(0).get('applicability') as FormGroup;

    return app;
  }

  fillExistingApplicability(criterias, parameterValue, applicability) {
    criterias.push(
      new FormGroup({
        label: new FormControl(parameterValue),
        value: new FormControl(parameterValue),
        selected: new FormControl(true),
        lcdvcharacterstics: new FormArray([])
      })
    );

    let app_ref = this.jsonObject.applicability ? this.jsonObject.applicability : applicability;

    if (app_ref.type === 'C') {
      if (app_ref.criterias.length > 0) {
        for (let i = 0; i < app_ref.criterias.length; i++) {
          if (app_ref.criterias[i].lcdvcharacterstics.length > 0) {
            for (let k = 0; k < app_ref.criterias[i].lcdvcharacterstics.length; k++) {

              let lcdv = app_ref.criterias[i].lcdvcharacterstics[k];
              let lcdvcharacterstics = criterias.at(i).get('lcdvcharacterstics') as FormArray;
              lcdvcharacterstics.push(
                new FormGroup({
                  lcdvLabel: new FormControl(lcdv.lcdvLabel),
                  lcdvCode: new FormControl(lcdv.lcdvCode),
                })
              );

            }
          }
        }
      }
    }
  }

  addApplicability($event, parameterValue, parameter) {

    this.checkFormState();

    this.parameterVal = parameterValue;
    let informations = this.form.get('informations') as FormArray;
    let applicability = ( < FormGroup > informations.at(0).get('applicability'));


    if (this.applicablity_first_time == false) {

      if ((applicability == null || applicability == undefined) && $event.srcElement.checked) {
        this.createApplicability(informations, this.parameterVal);
      } else if ($event.srcElement.checked) {
        let criterias = applicability.get('criterias') as FormArray;
        criterias.push(
          new FormGroup({
            label: new FormControl(this.parameterVal),
            value: new FormControl(this.parameterVal),
            selected: new FormControl(true),
            lcdvcharacterstics: new FormArray([])
          }));
      } else {
        let criteria = applicability.get('criterias') as FormArray;
        let lcdvCodes = [];

        if (parameter.lcdvcharacterstics) {
          for (let i = 0; i < parameter.lcdvcharacterstics.length; i++) {
            lcdvCodes.push(parameter.lcdvcharacterstics[i].lcdvCode);
          }
        }

        for (let i = 0; i < criteria.controls.length; i++) {
          let label = criteria.controls[i].value.value;
          let criteriaLcdv = [];

          if (label == this.parameterVal) {
            if (lcdvCodes) {


              for (let j = 0; j < criteria.controls[i].value.lcdvcharacterstics.length; j++) {
                criteriaLcdv.push(criteria.controls[i].value.lcdvcharacterstics[j].lcdvCode);
              }

              if (lcdvCodes.length === criteriaLcdv.length &&
                lcdvCodes.sort().every(function (value, index) {
                  return value === criteriaLcdv.sort()[index]
                })
              ) {
                criteria.removeAt(i);
              }

            } else {
              criteria.removeAt(i);
            }

          }
        }
      }
      this.applicablity_first_time = true;
    } else {
      let criterias = applicability.get('criterias') as FormArray;
      if ($event.srcElement.checked) {
        this.fillExistingApplicability(criterias, this.parameterVal, applicability);
      } else {
        for (var i = 0; i < criterias.controls.length; i++) {
          let label = criterias.controls[i].value.value;
          if (label == this.parameterVal) {
            criterias.removeAt(i);
          }
        }

      }
    }
    
    if (applicability) {
      let criterias = applicability.get('criterias') as FormArray;
      if (criterias.length == 0) {
        applicability.get('type').patchValue('V');
      }
    }

  }
  
  selectAll(evt) {

    this.authService.isAllChecked.next(evt.target.checked);
    let informations = this.form.get('informations') as FormArray;
    let applicability;
    if (informations) {
      applicability = ( < FormGroup > informations.at(0).get('applicability'));
    }
    let criterias;
    if (informations != null || informations != undefined) {
      applicability = ( < FormGroup > informations.at(0).get('applicability'));
      if (applicability)
        criterias = applicability.get('criterias') as FormArray;
      if (criterias != null || criterias != undefined) {
        while (criterias.length) {
          criterias.removeAt(0);
        }
      }
    }
    for (var i = 0; i < this.parameters.length; i++) {
      if (this.authService.isAllChecked.getValue()) {
        this.parameters[i].selected = true;

        this.authService.isAllChecked.next(true);

        if (applicability == null || applicability == undefined) {
          applicability = this.createApplicability(informations, this.parameters[i].value);
        } else {
          criterias = applicability.get('criterias') as FormArray;
          this.fillExistingApplicability(criterias, this.parameters[i].value, applicability);
        }
      } else {
        this.parameters[i].selected = false;
      }
    }
    if (!this.authService.isAllChecked.getValue()) {

      this.authService.isAllChecked.next(false);

      if (informations != null || informations != undefined) {
        let app = ( < FormArray > informations.at(0).get('applicability'));
        if (app != null || app != undefined) {
          while (app.length) {
            app.removeAt(0);
          }
        }
        let criteriaArray = app.get('criterias') as FormArray;
        if (criteriaArray.length == 0 && app.get('type').value == 'C') {
          this.parameters = this.parametersTemp;
          app.get('type').patchValue('V');
          this.complex_app = false;
          this.complex_app_ref.complex_app = false;
        }
      }

    }

  }
  resetAllImageFields() {

    this.imageToShow1 = [];
    this.imageToShow2 = [];
    this.imageToShow3 = [];
    this.imageToShow4 = [];
    this.imageToShow5 = [];
    this.imageToShow6 = [];
    this.imageToShow7 = [];
    this.imageToShow8 = [];
    this.imageToShow9 = [];
    this.imageToShow10 = [];
    this.imageToShow11 = [];
    this.imageToShow12 = [];
    this.imageToShow13 = [];
    this.imageToShow14 = [];
    this.imageToShow15 = [];
    this.imageToShow16 = [];
    this.imageToShow17 = [];
    this.imageToShow18 = [];
    this.imageToShow19 = [];
    this.imageToShow20 = [];
    this.imageToShow21 = [];
    this.imageToShow22 = [];
    this.imageToShow23 = [];
    this.imageToShow24 = [];
    this.imageToShow25 = [];

    this.first_image_names_from_rest_call = [];
    this.image_names_from_rest_call_collection = [];
    this.popup_text_area_value = [];
    this.second_image_names_from_rest_call = [];
    this.third_image_names_from_rest_call = [];
    this.fourth_image_names_from_rest_call = [];
    this.fifth_image_names_from_rest_call = [];
    this.sixth_image_names_from_rest_call = [];
    this.seven_image_names_from_rest_call = [];
    this.eight_image_names_from_rest_call = [];
    this.nine_image_names_from_rest_call = [];
    this.ten_image_names_from_rest_call = [];
    this.eleven_image_names_from_rest_call = [];
    this.twelve_image_names_from_rest_call = [];
    this.thirteen_image_names_from_rest_call = [];
    this.fourteen_image_names_from_rest_call = [];
    this.fifteen_image_names_from_rest_call = [];
    this.sixteen_image_names_from_rest_call = [];
    this.seventeen_image_names_from_rest_call = [];
    this.eighteen_image_names_from_rest_call = [];
    this.nineteen_image_names_from_rest_call = [];
    this.twenty_image_names_from_rest_call = [];
    this.twenty_one_image_names_from_rest_call = [];
    this.twenty_two_image_names_from_rest_call = [];
    this.twenty_three_image_names_from_rest_call = [];
    this.twenty_four_image_names_from_rest_call = [];
    this.twenty_five_image_names_from_rest_call = [];


    this.image_names1 = [];
    this.image_names2 = [];
    this.image_names3 = [];
    this.image_names4 = [];
    this.image_names5 = [];
    this.image_names6 = [];
    this.image_names7 = [];
    this.image_names8 = [];
    this.image_names9 = [];
    this.image_names10 = [];
    this.image_names11 = [];
    this.image_names12 = [];
    this.image_names13 = [];
    this.image_names14 = [];
    this.image_names15 = [];
    this.image_names16 = [];
    this.image_names17 = [];
    this.image_names18 = [];
    this.image_names19 = [];
    this.image_names20 = [];
    this.image_names21 = [];
    this.image_names22 = [];
    this.image_names23 = [];
    this.image_names24 = [];
    this.image_names25 = [];
  }
  resetFields() {
    if (this.saveButton) {
      this.saveButton.nativeElement.blur();
    }

    this.disableCaption = true;
    this.index = 0;
    this.text_index = 0;
    this.image_index = 0;

    this.authService.isAllChecked.next(false);

    this.imageToShow1 = [];
    this.imageToShow2 = [];
    this.imageToShow3 = [];
    this.imageToShow4 = [];
    this.imageToShow5 = [];
    this.imageToShow6 = [];
    this.imageToShow7 = [];
    this.imageToShow8 = [];
    this.imageToShow9 = [];
    this.imageToShow10 = [];
    this.imageToShow11 = [];
    this.imageToShow12 = [];
    this.imageToShow13 = [];
    this.imageToShow14 = [];
    this.imageToShow15 = [];
    this.imageToShow16 = [];
    this.imageToShow17 = [];
    this.imageToShow18 = [];
    this.imageToShow19 = [];
    this.imageToShow20 = [];
    this.imageToShow21 = [];
    this.imageToShow22 = [];
    this.imageToShow23 = [];
    this.imageToShow24 = [];
    this.imageToShow25 = [];


    this.textarea_no_counter = 0;
    this.imagearea_no_counter = 0;
    this.area_position_counter = 0;



    // this.max_text_cloning_reached = false;
    // this.textareaComponent.max_image_cloning_reached = false;
    this.text_cloning_counter = 0;
    this.image_cloning_counter = 0;
    this.max_image_cloning_reached = false;
    this.max_text_cloning_reached = false;



    this.title_of_information = '';
    this.selectedInformation = '';
    this.selectedInformationId = '';
    this.informationId = null;
    this.jsonObject = {};
    this.form = new FormGroup({});
    this.applicablity_first_time = false;
    this.complex_app = false;
    this.complex_app_ref.complex_app = false;

    this.first_text_area_value = '';
    this.second_text_area_value = '';
    this.third_text_area_value = '';
    this.fourth_text_area_value = '';
    this.fifth_text_area_value = '';
    this.sixth_text_area_value = '';

    this.sevent_text_area_value = '';
    this.eighth_text_area_value = '';
    this.ninth_text_area_value = '';
    this.tenth_text_area_value = '';

    this.eleventh_text_area_value = '';
    this.tweleve_text_area_value = '';
    this.thirteen_text_area_value = '';
    this.fourteen_text_area_value = '';
    this.fifteen_text_area_value = '';

    this.sixteen_text_area_value = '';
    this.seventeen_text_area_value = '';
    this.eighteen_text_area_value = '';
    this.nineteen_text_area_value = '';
    this.twenty_text_area_value = '';

    this.twentyone_text_area_value = '';
    this.twentytwo_text_area_value = '';
    this.twentythree_text_area_value = '';
    this.twentyfour_text_area_value = '';
    this.twentyfive_text_area_value = '';



    this.form.reset();
    if (this.parameters) {
      for (var i = 0; i < this.parameters.length; i++) {
        this.parameters[i].selected = false;
      }
    }

    this.VCR.clear();


  }

  private prepareJsonFromGetCall() {

    this.image_names_from_rest_call = [];

    this.first_image_names_from_rest_call = [];
    this.image_names_from_rest_call_collection = [];
    this.popup_text_area_value = [];
    this.second_image_names_from_rest_call = [];
    this.third_image_names_from_rest_call = [];
    this.fourth_image_names_from_rest_call = [];
    this.fifth_image_names_from_rest_call = [];
    this.sixth_image_names_from_rest_call = [];
    this.seven_image_names_from_rest_call = [];
    this.eight_image_names_from_rest_call = [];
    this.nine_image_names_from_rest_call = [];
    this.ten_image_names_from_rest_call = [];
    this.eleven_image_names_from_rest_call = [];
    this.twelve_image_names_from_rest_call = [];
    this.thirteen_image_names_from_rest_call = [];
    this.fourteen_image_names_from_rest_call = [];
    this.fifteen_image_names_from_rest_call = [];
    this.sixteen_image_names_from_rest_call = [];
    this.seventeen_image_names_from_rest_call = [];
    this.eighteen_image_names_from_rest_call = [];
    this.nineteen_image_names_from_rest_call = [];
    this.twenty_image_names_from_rest_call = [];
    this.twenty_one_image_names_from_rest_call = [];
    this.twenty_two_image_names_from_rest_call = [];
    this.twenty_three_image_names_from_rest_call = [];
    this.twenty_four_image_names_from_rest_call = [];
    this.twenty_five_image_names_from_rest_call = [];


    this.form.addControl('id', new FormControl(this.topicid));
    let type = 'V';
    if (this.jsonObject.applicability) {
      type = this.jsonObject.applicability.type ? this.jsonObject.applicability.type : 'V';
    }
    this.form.addControl('informations', new FormArray([
      new FormGroup({
        id: new FormControl(this.selectedInformationId),
        title: new FormControl(this.title_of_information),
        areas: new FormArray([]),
        applicability: new FormGroup({
          type: new FormControl(
            type
          ),
          criterias: new FormArray([])
        })
      })
    ]));


    //Applicabilty starts
    let info = ( < FormArray > this.form.controls['informations']);
    let applicability = info.at(0).get('applicability') as FormGroup;
    let criterias = applicability.get('criterias') as FormArray;
    if (this.jsonObject.applicability != undefined) {
      if(this.jsonObject.applicability.criterias) {
        if (this.jsonObject.applicability.criterias.length > 0) {
          for (let i = 0; i < this.jsonObject.applicability.criterias.length; i++) {
            criterias.push(
              new FormGroup({
                label: new FormControl(this.jsonObject.applicability.criterias[i].label),
                value: new FormControl(this.jsonObject.applicability.criterias[i].value),
                selected: new FormControl(this.jsonObject.applicability.criterias[i].selected),
                lcdvcharacterstics: new FormArray([])
              })
            );
            for (let k = 0; k < this.jsonObject.applicability.criterias[i].lcdvcharacterstics.length; k++) {
              let lcdv = this.jsonObject.applicability.criterias[i].lcdvcharacterstics[k];
              let lcdvcharacterstics = criterias.at(i).get('lcdvcharacterstics') as FormArray;
              lcdvcharacterstics.push(
                new FormGroup({
                  lcdvLabel: new FormControl(lcdv.lcdvLabel),
                  lcdvCode: new FormControl(lcdv.lcdvCode),
                })
              );
            }
          }
        }
      }

    }



    //Applicabilty ends

    let areas = info.at(0).get('areas') as FormArray;

    if (this.jsonObject.areas) {
      for (let count = 0; count < this.jsonObject.areas.length; count++) {
        areas.push(
          new FormGroup({
            areaId: new FormControl(this.jsonObject.areas[count].areaId),
            type: new FormControl(this.jsonObject.areas[count].type),
            textarea_no: new FormControl(this.jsonObject.areas[count].textarea_no),
            imagearea_no: new FormControl(this.jsonObject.areas[count].imagearea_no),
            position: new FormControl(this.jsonObject.areas[count].position),
            parts: new FormArray([])
          })
        );

        this.textarea_no_counter = parseInt(this.jsonObject.areas[count].textarea_no) ?
          parseInt(this.jsonObject.areas[count].textarea_no) : this.textarea_no_counter;

        this.area_position_counter = parseInt(this.jsonObject.areas[count].position);


        this.imagearea_no_counter = parseInt(this.jsonObject.areas[count].imagearea_no) ?
          parseInt(this.jsonObject.areas[count].imagearea_no) : this.imagearea_no_counter;








        for (let k = 0; k < this.jsonObject.areas[count].parts.length; k++) {
          let parts = areas.at(count).get('parts') as FormArray;

          parts.push(
            new FormGroup({
              partId: new FormControl(this.jsonObject.areas[count].parts[k].partId),
              type: new FormControl(this.jsonObject.areas[count].parts[k].type),
              position: new FormControl(this.jsonObject.areas[count].parts[k].position),
              phraseId: new FormControl(''),
              value: new FormControl(this.jsonObject.areas[count].parts[k].value)
            })
          )


          if (this.jsonObject.areas[count].type == 'imagearea') {


            switch (this.imagearea_no_counter) {
              case 1:
                this.first_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);
                break;
              case 2:
                this.second_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 3:
                this.third_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 4:
                this.fourth_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 5:
                this.fifth_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 6:
                this.sixth_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 7:
                this.seven_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 8:
                this.eight_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 9:
                this.nine_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 10:
                this.ten_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 11:
                this.eleven_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 12:
                this.twelve_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 13:
                this.thirteen_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 14:
                this.fourteen_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 15:
                this.fifteen_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 16:
                this.sixteen_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 17:
                this.seventeen_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 18:
                this.eighteen_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 19:
                this.nineteen_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 20:
                this.twenty_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 21:
                this.twenty_one_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 22:
                this.twenty_two_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 23:
                this.twenty_three_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 24:
                this.twenty_four_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
              case 25:
                this.twenty_five_image_names_from_rest_call.push(this.jsonObject.areas[count].parts[k].value);

                break;
            }
          }

        }
      }




    }
    this.detectGenerationSequence();
    this.initializeFilesCounter();

  }
  prepareTitle() {
    let type = 'V';
    if (this.jsonObject.applicability) {
      type = this.jsonObject.applicability.type ? this.jsonObject.applicability.type : 'V';
    }

    let info = ( < FormArray > this.form.controls['informations']);
    if (info == null) {

      this.form.addControl('id', new FormControl(this.topicid));
      this.form.addControl('informations', new FormArray([
        new FormGroup({
          id: new FormControl(this.selectedInformationId),
          title: new FormControl(''),
          areas: new FormArray([]),
          applicability: new FormGroup({
            type: new FormControl(type),
            criterias: new FormArray([])
          })
        })
      ]));
    }

    let information = ( < FormArray > this.form.controls['informations']);
    let title = information.at(0).get('title') as FormControl;
    title.patchValue(this.title_of_information);
  }



  prepareJsonOnTextClick() {
    let informations = this.form.get('informations') as FormArray;
    if (informations === null && this.text_cloning_counter < 26) {
      this.textarea_no_counter++;
      this.form.addControl('id', new FormControl(this.topicid));
      this.area_position_counter++;
      this.counter += 1;

      this.form.addControl('informations', new FormArray([
        new FormGroup({
          id: new FormControl(this.selectedInformationId),
          title: new FormControl(this.title_of_information),
          areas: new FormArray([
            new FormGroup({
              type: new FormControl('textarea'),
              textarea_no: new FormControl(
                this.textarea_no_counter < 26 ? this.textarea_no_counter : 1
              ),
              imagearea_no: new FormControl(''),
              position: new FormControl(this.area_position_counter),
              parts: new FormArray([])
            })
          ])
        })
      ]));

    }

    if (informations !== null && this.text_cloning_counter < 26) {
      this.textarea_no_counter++;
      this.area_position_counter++;
      const formGroup = new FormGroup({
        type: new FormControl('textarea'),
        textarea_no: new FormControl(
          this.textarea_no_counter < 26 ? this.textarea_no_counter : 1
        ),
        imagearea_no: new FormControl(''),
        position: new FormControl(this.area_position_counter),
        parts: new FormArray([])
      })

      let info = ( < FormGroup > informations.at(0));
      let areas = info.get('areas') as FormArray;
      areas.push(formGroup);


    }
  }

  prepareJsonOnImageClick() {
    let informations = this.form.get('informations') as FormArray;
    if (informations === null && this.image_cloning_counter < 26) {
      this.area_position_counter++;
      this.imagearea_no_counter++;
      this.form.addControl('id', new FormControl(this.topicid));
      this.counter += 1;
      this.form.addControl('informations', new FormArray([
        new FormGroup({
          id: new FormControl(this.selectedInformationId),
          title: new FormControl(this.title_of_information),
          areas: new FormArray([
            new FormGroup({
              type: new FormControl('imagearea'),
              textarea_no: new FormControl(''),
              imagearea_no: new FormControl(
                this.imagearea_no_counter < 26 ? this.imagearea_no_counter : 1
              ),
              position: new FormControl(this.area_position_counter),
              parts: new FormArray([])
            })
          ])
        })
      ]));




    }

    if (informations !== null && this.image_cloning_counter < 26) {
      this.imagearea_no_counter++;
      this.area_position_counter++;
      const formGroup = new FormGroup({
        type: new FormControl('imagearea'),
        textarea_no: new FormControl(''),
        imagearea_no: new FormControl(
          this.imagearea_no_counter < 26 ? this.imagearea_no_counter : 1
        ),
        position: new FormControl(this.area_position_counter),
        parts: new FormArray([])
      })

      let info = ( < FormGroup > informations.at(0));
      let areas = info.get('areas') as FormArray;
      areas.push(formGroup);

    }
  }

  emptyAllTextareas() {

    this.first_text_area_value = '';
    this.second_text_area_value = '';
    this.third_text_area_value = '';
    this.fourth_text_area_value = '';
    this.fifth_text_area_value = '';
    this.sixth_text_area_value = '';

    this.sevent_text_area_value = '';
    this.eighth_text_area_value = '';
    this.ninth_text_area_value = '';
    this.tenth_text_area_value = '';

    this.eleventh_text_area_value = '';
    this.tweleve_text_area_value = '';
    this.thirteen_text_area_value = '';
    this.fourteen_text_area_value = '';
    this.fifteen_text_area_value = '';

    this.sixteen_text_area_value = '';
    this.seventeen_text_area_value = '';
    this.eighteen_text_area_value = '';
    this.nineteen_text_area_value = '';
    this.twenty_text_area_value = '';

    this.twentyone_text_area_value = '';
    this.twentytwo_text_area_value = '';
    this.twentythree_text_area_value = '';
    this.twentyfour_text_area_value = '';
    this.twentyfive_text_area_value = '';
  }

  moveInformationBlocks(shift: number, componentRef) {


    let currentIndex = this.VCR.indexOf(componentRef.hostView);
    let containerIndex = currentIndex;
    const len = this.VCR.length;

    let destinationIndex = currentIndex + shift;
    if (destinationIndex === len) {
      destinationIndex = 0;
      return;
    }
    if (destinationIndex === -1) {
      destinationIndex = len - 1;
      return;
    }

    let text_index = componentRef._component.text_index;
    let image_index = componentRef._component.image_index;

    if (text_index) {
      currentIndex = this.searchForIndex(this.text_view_generation_sequence, text_index);
      this.getContextForRestructuring(shift, currentIndex, containerIndex, true, false);
    } else {
      currentIndex = this.searchForIndex(this.image_view_generation_sequence, image_index);
      this.getContextForRestructuring(shift, currentIndex, containerIndex, false, true);

    }


    this.VCR.move(componentRef.hostView, destinationIndex);

  }

  swap(arr: any[], index1: number, index2: number): any[] {
    arr = [...arr];
    const temp = arr[index1];
    arr[index1] = arr[index2];
    arr[index2] = temp;
    return arr;
  }

  patchJsonArray(newExtras) {
    let informations = ( < FormArray > this.form.controls['informations']);
    let areas = informations.at(0).get('areas') as FormArray;

    while (areas.length) {
      areas.removeAt(0);
    }

    for (let i = 0; i < newExtras.length; i++) {

      areas.push(
        new FormGroup({
          areaId: new FormControl(newExtras[i].areaId),
          type: new FormControl(newExtras[i].type),
          textarea_no: new FormControl(newExtras[i].textarea_no),
          imagearea_no: new FormControl(newExtras[i].imagearea_no),
          position: new FormControl(newExtras[i].position),
          parts: new FormArray([])
        })
      );
      for (let j = 0; j < newExtras[i].parts.length; j++) {
        let parts = areas.at(i).get('parts') as FormArray;

        parts.push(new FormGroup({
          partId: new FormControl(newExtras[i].parts[j].partId),
          type: new FormControl(newExtras[i].parts[j].type),
          position: new FormControl(newExtras[i].parts[j].position),
          phraseId: new FormControl(''),
          value: new FormControl(newExtras[i].parts[j].value)
        }))

      }
    }
  }

  moveJsonUp(index: number, changeSequence: boolean, isTextArea, IsImageArea, containerIndex) {
    let informations = ( < FormArray > this.form.controls['informations']);
    let areas = informations.at(0).get('areas') as FormArray;


    if (containerIndex > 0) {
      const extras = areas.value;

      if (index < this.text_view_generation_sequence.length && changeSequence && isTextArea) {
        this.text_view_generation_sequence = this.swap(this.text_view_generation_sequence, index - 1, index);
      }

      if (index < this.image_view_generation_sequence.length && changeSequence && IsImageArea) {
        this.image_view_generation_sequence = this.swap(this.image_view_generation_sequence, index - 1, index);
      }


      const newExtras = this.swap(extras, containerIndex - 1, containerIndex);
      this.patchJsonArray(newExtras);
    }

  }

  moveJsonDown(index: number, changeSequence: boolean, isTextArea, IsImageArea, containerIndex) {
    let informations = ( < FormArray > this.form.controls['informations']);
    let areas = informations.at(0).get('areas') as FormArray;

    const extras = areas.value;
    if (containerIndex < extras.length - 1) {


      if (index < this.text_view_generation_sequence.length && changeSequence && isTextArea) {
        this.text_view_generation_sequence = this.swap(this.text_view_generation_sequence, index, index + 1);
      }
      if (index < this.image_view_generation_sequence.length && changeSequence && IsImageArea) {
        this.image_view_generation_sequence = this.swap(this.image_view_generation_sequence, index, index + 1);
      }

      const newExtras = this.swap(extras, containerIndex, containerIndex + 1);
      this.patchJsonArray(newExtras);
    }
  }

  reStructureJson(index: number, currentIndex: number, changeSequence: boolean, isTextArea, IsImageArea, containerIndex) {
    index == -1 ? this.moveJsonUp(currentIndex, changeSequence, isTextArea, IsImageArea, containerIndex) :
      this.moveJsonDown(currentIndex, changeSequence, isTextArea, IsImageArea, containerIndex);
  }



  getContextForRestructuring(shift: number, currentIndex: number, containerIndex, isTextArea, IsImageArea) {

    let informations = ( < FormArray > this.form.controls['informations']);
    let areas = informations.at(0).get('areas') as FormArray;
    let destinationIndex = 0;

    shift == -1 ? destinationIndex = containerIndex - 1 : destinationIndex = containerIndex + 1;
    this.getMoveUpOrDownContext(areas, shift, currentIndex, destinationIndex, containerIndex, isTextArea, IsImageArea);

  }

  getMoveUpOrDownContext(areas: FormArray, shift: number, currentIndex: number, destinationIndex: number, containerIndex, isTextArea, IsImageArea) {
    if (areas.at(containerIndex).value.type == 'imagearea' && areas.at(destinationIndex).value.type == 'imagearea') {
      this.reStructureJson(shift, currentIndex, true, isTextArea, IsImageArea, containerIndex);
    } else if (areas.at(containerIndex).value.type == 'textarea' && areas.at(destinationIndex).value.type == 'textarea') {
      this.reStructureJson(shift, currentIndex, true, isTextArea, IsImageArea, containerIndex);
    }

    if (areas.at(containerIndex).value.type == 'imagearea' && areas.at(destinationIndex).value.type !== 'imagearea') {
      this.reStructureJson(shift, currentIndex, false, isTextArea, IsImageArea, containerIndex);
    } else if (areas.at(containerIndex).value.type == 'textarea' && areas.at(destinationIndex).value.type !== 'textarea') {
      this.reStructureJson(shift, currentIndex, false, isTextArea, IsImageArea, containerIndex);
    }
  }


  searchForIndex(view_sequence, vcrIndex) {
    for (let i = 0; i < view_sequence.length; i++) {
      if (view_sequence[i] == vcrIndex) {
        return i;
      }
    }
  }

  reOrderTextInformation() {
    let sequence_Re_gained: boolean = false;
    let tempArray = [];
    let counter = 0;

    for (let i = 0; i < this.text_view_generation_sequence.length; i++) {
      if (this.text_view_generation_sequence[i] == i + 1) {
        counter++
      }
    }

    if (counter == this.text_view_generation_sequence.length) {
      sequence_Re_gained = true;
    }
    if (sequence_Re_gained) {

      this.renderTextInformation(this.text_area_value);
      this.renderPopuInformation(this.text_area_value);
    } else {


      for (let i = 0; i < this.text_view_generation_sequence.length; i++) {

        this.assignTextAreaValue(this.text_view_generation_sequence[i], this.text_area_value[i]);
        this.popup_text_area_value[this.text_view_generation_sequence[i] - 1] = this.text_area_value[i];

      }

    }
  }

  renderPopuInformation(arr) {
    for (let i = 0; i < arr.length; i++) {
      this.popup_text_area_value[i] = arr[i];
    }
  }
  renderTextInformation(arr: any[]) {

    for (let text_counter = 0; text_counter < arr.length; text_counter++) {
      if (text_counter == 0) {

        this.first_text_area_value = arr[text_counter];

      } else if (text_counter == 1) {
        this.second_text_area_value = arr[text_counter];

      } else if (text_counter == 2) {
        this.third_text_area_value = arr[text_counter];


      } else if (text_counter == 3) {
        this.fourth_text_area_value = arr[text_counter];


      } else if (text_counter == 4) {
        this.fifth_text_area_value = arr[text_counter];


      } else if (text_counter == 5) {

        this.sixth_text_area_value = arr[text_counter];

      } else if (text_counter == 6) {

        this.sevent_text_area_value = arr[text_counter];

      } else if (text_counter == 7) {

        this.eighth_text_area_value = arr[text_counter];

      } else if (text_counter == 8) {

        this.ninth_text_area_value = arr[text_counter];

      } else if (text_counter == 9) {

        this.tenth_text_area_value = arr[text_counter];

      } else if (text_counter == 10) {

        this.eleventh_text_area_value = arr[text_counter];

      } else if (text_counter == 11) {

        this.tweleve_text_area_value = arr[text_counter];

      } else if (text_counter == 12) {

        this.thirteen_text_area_value = arr[text_counter];

      } else if (text_counter == 13) {

        this.fourteen_text_area_value = arr[text_counter];

      } else if (text_counter == 14) {

        this.fifteen_text_area_value = arr[text_counter];

      } else if (text_counter == 15) {

        this.sixteen_text_area_value = arr[text_counter];

      } else if (text_counter == 16) {

        this.seventeen_text_area_value = arr[text_counter];

      } else if (text_counter == 17) {

        this.eighteen_text_area_value = arr[text_counter];

      } else if (text_counter == 18) {

        this.nineteen_text_area_value = arr[text_counter];

      } else if (text_counter == 19) {

        this.twenty_text_area_value = arr[text_counter];

      } else if (text_counter == 20) {

        this.twentyone_text_area_value = arr[text_counter];

      } else if (text_counter == 21) {

        this.twentytwo_text_area_value = arr[text_counter];

      } else if (text_counter == 22) {

        this.twentythree_text_area_value = arr[text_counter];

      } else if (text_counter == 23) {

        this.twentyfour_text_area_value = arr[text_counter];

      } else if (text_counter == 24) {

        this.twentyfive_text_area_value = arr[text_counter];
      }

    }
    arr = [];


  }

  initializeFilesCounter() {

    for (let i = 0; i < this.image_view_generation_sequence.length; i++) {
      let switch_index = isNaN(parseInt(this.image_view_generation_sequence[i])) == false ?
        parseInt(this.image_view_generation_sequence[i]) : false;

      if (switch_index) {

        switch (switch_index) {
          case 1:
            this.image_names_from_rest_call_collection.push(this.first_image_names_from_rest_call);
            break;
          case 2:
            this.image_names_from_rest_call_collection.push(this.second_image_names_from_rest_call);
            break;
          case 3:
            this.image_names_from_rest_call_collection.push(this.third_image_names_from_rest_call);
            break;
          case 4:
            this.image_names_from_rest_call_collection.push(this.fourth_image_names_from_rest_call);
            break;
          case 5:
            this.image_names_from_rest_call_collection.push(this.fifth_image_names_from_rest_call);
            break;
          case 6:
            this.image_names_from_rest_call_collection.push(this.sixth_image_names_from_rest_call);
            break;
          case 7:
            this.image_names_from_rest_call_collection.push(this.seven_image_names_from_rest_call);
            break;
          case 8:
            this.image_names_from_rest_call_collection.push(this.eight_image_names_from_rest_call);
            break;
          case 9:
            this.image_names_from_rest_call_collection.push(this.nine_image_names_from_rest_call);
            break;
          case 10:
            this.image_names_from_rest_call_collection.push(this.ten_image_names_from_rest_call);
            break;
          case 11:
            this.image_names_from_rest_call_collection.push(this.eleven_image_names_from_rest_call);
            break;
          case 12:
            this.image_names_from_rest_call_collection.push(this.twelve_image_names_from_rest_call);
            break;
          case 13:
            this.image_names_from_rest_call_collection.push(this.thirteen_image_names_from_rest_call);
            break;
          case 14:
            this.image_names_from_rest_call_collection.push(this.fourteen_image_names_from_rest_call);
            break;
          case 15:
            this.image_names_from_rest_call_collection.push(this.fifteen_image_names_from_rest_call);
            break;
          case 16:
            this.image_names_from_rest_call_collection.push(this.sixteen_image_names_from_rest_call);
            break;
          case 17:
            this.image_names_from_rest_call_collection.push(this.seventeen_image_names_from_rest_call);
            break;
          case 18:
            this.image_names_from_rest_call_collection.push(this.eighteen_image_names_from_rest_call);
            break;
          case 19:
            this.image_names_from_rest_call_collection.push(this.nineteen_image_names_from_rest_call);
            break;
          case 20:
            this.image_names_from_rest_call_collection.push(this.twenty_image_names_from_rest_call);
            break;
          case 21:
            this.image_names_from_rest_call_collection.push(this.twenty_one_image_names_from_rest_call);
            break;
          case 22:
            this.image_names_from_rest_call_collection.push(this.twenty_two_image_names_from_rest_call);
            break;
          case 23:
            this.image_names_from_rest_call_collection.push(this.twenty_three_image_names_from_rest_call);
            break;
          case 24:
            this.image_names_from_rest_call_collection.push(this.twenty_four_image_names_from_rest_call);
            break;
          case 25:
            this.image_names_from_rest_call_collection.push(this.twenty_five_image_names_from_rest_call);
            break;
          default:
            break;
        }



      } else {

        this.image_names_from_rest_call_collection.push(this.first_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.second_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.third_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.fourth_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.fifth_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.sixth_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.seven_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.eight_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.nine_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.ten_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.eleven_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.twelve_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.thirteen_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.fourteen_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.fifteen_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.sixteen_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.seventeen_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.eighteen_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.nineteen_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.twenty_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.twenty_one_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.twenty_two_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.twenty_three_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.twenty_four_image_names_from_rest_call);


        this.image_names_from_rest_call_collection.push(this.twenty_five_image_names_from_rest_call);

        break;
      }
    }
  }

  resetApplicability() {
    this.parameters = [];
    let params;
    this.applicabilityService.getData('VEHICULE').subscribe( (vehicleData: Array <Object>) => {
      vehicleData.sort((a,b) => 
      this.compare(a,b)
     ); 
      params = vehicleData;
      this.parameters = params;
    });

  }

  checkFormState() {

    if (JSON.stringify(this.form.value) !== '{}') {
      return;
    }

    this.form.addControl('id', new FormControl(this.topicid));
    this.form.addControl('informations', new FormArray([
      new FormGroup({
        id: new FormControl(''),
        title: new FormControl(''),
        areas: new FormArray([])
      })
    ]));
  }


  assignTextAreaValue(index, value) {

    switch (index) {

      case 1:
        this.first_text_area_value = value;
        return;

      case 2:
        this.second_text_area_value = value;
        return;

      case 3:
        this.third_text_area_value = value;
        return;

      case 4:
        this.fourth_text_area_value = value;
        return;

      case 5:
        this.fifth_text_area_value = value;
        return;

      case 6:
        this.sixth_text_area_value = value;
        return;

      case 7:
        this.sevent_text_area_value = value;
        return;

      case 8:
        this.eighth_text_area_value = value;
        return;

      case 9:
        this.ninth_text_area_value = value;
        return;

      case 10:
        this.tenth_text_area_value = value;
        return;

      case 11:
        this.eleventh_text_area_value = value;
        return;

      case 12:
        this.tweleve_text_area_value = value;
        return;

      case 13:
        this.thirteen_text_area_value = value;
        return;

      case 14:
        this.fourteen_text_area_value = value;
        return;

      case 15:
        this.fifteen_text_area_value = value;
        return;

      case 16:
        this.sixteen_text_area_value = value;
        return;

      case 17:
        this.seventeen_text_area_value = value;
        return;

      case 18:
        this.eighteen_text_area_value = value;
        return;

      case 19:
        this.nineteen_text_area_value = value;
        return;

      case 20:
        this.twenty_text_area_value = value;
        return;

      case 21:
        this.twentyone_text_area_value = value;
        return;

      case 22:
        this.twentytwo_text_area_value = value;
        return;

      case 23:
        this.twentythree_text_area_value = value;
        return;

      case 24:
        this.twentyfour_text_area_value = value;
        return;

      case 25:
        this.twentyfive_text_area_value = value;
        return;
    }
  }


  reOrderImageInformation() {

    for (let i = 0; i < this.image_area_value.length; i++) {


      if (i == 0) {
        this.setImage(i, "1");

      } else if (i == 1) {
        this.setImage(i, "2");

      } else if (i == 2) {
        this.setImage(i, "3");

      } else if (i == 3) {
        this.setImage(i, "4");

      } else if (i == 4) {
        this.setImage(i, "5");

      } else if (i == 5) {
        this.setImage(i, "6");

      } else if (i == 6) {
        this.setImage(i, "7");

      } else if (i == 7) {
        this.setImage(i, "8");

      } else if (i == 8) {
        this.setImage(i, "9");

      } else if (i == 9) {
        this.setImage(i, "10");

      } else if (i == 10) {
        this.setImage(i, "11");

      } else if (i == 11) {
        this.setImage(i, "12");

      } else if (i == 12) {
        this.setImage(i, "13");

      } else if (i == 13) {
        this.setImage(i, "14");

      } else if (i == 14) {
        this.setImage(i, "15");

      } else if (i == 15) {
        this.setImage(i, "16");

      } else if (i == 16) {
        this.setImage(i, '17');

      } else if (i == 17) {
        this.setImage(i, "18");

      } else if (i == 18) {
        this.setImage(i, "19");

      } else if (i == 19) {
        this.setImage(i, "20");

      } else if (i == 20) {
        this.setImage(i, "21");

      } else if (i == 21) {
        this.setImage(i, "22");

      } else if (i == 22) {
        this.setImage(i, "23");

      } else if (i == 23) {
        this.setImage(i, "24");

      } else if (i == 24) {
        this.setImage(i, "25");

      }

    }

  }



  setImage(index: number, partId: string) {

    this.image_name_array = this.image_area_value[index].trim().split(' ');

    if (this.image_view_generation_sequence[index] == 1) {

      this.imageNameArray1 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 2) {

      this.imageNameArray2 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 3) {

      this.imageNameArray3 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 4) {

      this.imageNameArray4 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 5) {

      this.imageNameArray5 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 6) {

      this.imageNameArray6 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 7) {

      this.imageNameArray7 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 8) {

      this.imageNameArray8 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 9) {

      this.imageNameArray9 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 10) {

      this.imageNameArray10 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 11) {

      this.imageNameArray11 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 12) {

      this.imageNameArray12 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 13) {

      this.imageNameArray13 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 14) {

      this.imageNameArray14 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 15) {

      this.imageNameArray15 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 16) {

      this.imageNameArray16 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 17) {

      this.imageNameArray17 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 18) {

      this.imageNameArray18 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 19) {

      this.imageNameArray19 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 20) {

      this.imageNameArray20 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 21) {

      this.imageNameArray21 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 22) {

      this.imageNameArray22 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 23) {

      this.imageNameArray23 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 24) {

      this.imageNameArray24 = this.image_name_array;

    } else if (this.image_view_generation_sequence[index] == 25) {

      this.imageNameArray25 = this.image_name_array;

    }

    for (let j = 0; j < this.image_name_array.length; j++) {
      this.getImageFromService(partId, this.image_name_array[j], this.image_view_generation_sequence[index], j);
    }

  }

  detectGenerationSequence() {
    this.text_view_generation_sequence = [];
    this.image_view_generation_sequence = [];

    let informations = ( < FormArray > this.form.controls['informations']);
    let areas = informations.at(0).get('areas') as FormArray;

    for (let i = 0; i < areas.length; i++) {

      if (isNaN(parseInt(areas.at(i).get('textarea_no').value)) == false) {
        this.text_view_generation_sequence.push(parseInt(areas.at(i).get('textarea_no').value));
      }


      if (isNaN(parseInt(areas.at(i).get('imagearea_no').value)) == false) {
        this.image_view_generation_sequence.push(parseInt(areas.at(i).get('imagearea_no').value));
      }

    }
    if (this.text_view_generation_sequence.length > 0 || this.image_view_generation_sequence.length > 0) {
      this.generate_view_using_sequence = true;
    } else {
      this.generate_view_using_sequence = false;

    }
  }

  @ViewChild(ComplexApplicabilityComponent) ComplexApplicabilityComponent;

  editComplexApp(complex_app, counter) {

    this.ComplexApplicabilityComponent.onComplexApplicabilityClick(true, complex_app, counter)
  }

  deleteComplexApp(complex_app, counter) {
    this.ComplexApplicabilityComponent.deleteComplexApp(complex_app, counter)
    let informations = this.form.get('informations') as FormArray;
    let app = ( < FormArray > informations.at(0).get('applicability'));
    let criteriaArray = app.get('criterias') as FormArray;

    if (criteriaArray.length == 0 && app.get('type').value == 'C') {
      this.parameters = this.parametersTemp;
      this.parameters.forEach(param => param.selected = false);
      this.parameters.sort((a,b) => this.compare(a,b));
      app.get('type').patchValue('V');
      this.complex_app = false;
      this.complex_app_ref.complex_app = false;
      this.authService.isAllChecked.next(false);
    }
  }

}


