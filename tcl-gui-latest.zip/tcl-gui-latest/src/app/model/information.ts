export class Information {
    label: string;
    value: string;
}
