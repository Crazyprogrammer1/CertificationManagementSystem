import {
    Style
} from './../image-upload/style';
import {
    Component,
    OnInit,
    Input,
    ViewChild,
    ComponentRef,
    ViewEncapsulation,
    AfterViewInit,
    ChangeDetectorRef,
    ElementRef,
    Renderer2
} from '@angular/core';
import {
    NgxSmartModalComponent,
    NgxSmartModalService
} from 'ngx-smart-modal';
import {
    TopicComponent
} from '../topic/topic.component';
import {
    TextareaComponent
} from '../textarea/textarea.component';
import {
    SnackbarService
} from 'ngx-snackbar';
import {
    DialogModule
} from 'primeng/dialog';
import {
    SnackbarModule
} from 'ngx-snackbar';
import {
    TagInputModule
} from 'ngx-chips';
import {
    AgGridNg2
} from 'ag-grid-angular';
import {
    ApplicabilityService
} from '../service/applicability/applicability.service';
import {
    FormGroup,
    FormControl,
    FormArray,
    FormBuilder
} from '@angular/forms';
import {
    ActivatedRoute
} from '@angular/router';
import {
    TopicService
} from '../service/topic/topic.service';
import {
    AuthService
} from '../auth/auth.service';
import {
    RowNode
} from 'ag-grid-community';
import {
    SafeStyle,
    DomSanitizer
} from '@angular/platform-browser';

@Component({
    selector: 'complex-applicability',
    templateUrl: './complex-applicability.component.html',
    styleUrls: ['./complex-applicability.component.css'],

})
export class ComplexApplicabilityComponent implements OnInit, AfterViewInit {

    VehiculecolumnDefs;
    VehiculerowData;

    FamillecolumnDefs;
    FamillerowData;

    CharacteristiccolumnDefs;
    CharacteristicrowData;

    editComplexApp: boolean;

    topicid: any;
    editCounter: number;

    simpleApplicabilityBackup: any[] = [];
    characteristic_Input: string = '';
    @Input('parameters') parameters: any[];
    characteristicsObject: lcdvObject[] = [];
    @Input('form') form;
    @Input('enable_information_screen') enable_information_screen;
    @Input('complex_app') complex_app: boolean;
    nature_class: any;
    lcdv_nature_codes: any;
    vehicle: any;
    selectedVehicle: string = '';
    selectedVehicleLabel: string = '';
    familyLabel: string = '';
    familyValue: string = '';
    display: boolean = false;
    characteristicsChips: any[] = [];
    isScrolRequired: any;
    @ViewChild('vehicleAgGrid') vehicleAgGrid: AgGridNg2;
    @ViewChild('FamilleagGrid') FamilleAgGrid: AgGridNg2;
    @ViewChild('CharacteristicsgGrid') CharacteristicAgGrid: AgGridNg2;

    constructor(
        public ngxSmartModalService: NgxSmartModalService,
        private applicabilityService: ApplicabilityService,
        private route: ActivatedRoute,
        private svc: TopicService,
        private ref: ChangeDetectorRef,
        private snackbarService: SnackbarService,
        private fBuilder: FormBuilder,
        private authService: AuthService,
        private changeRef: ChangeDetectorRef

    ) {

        this.VehiculecolumnDefs = [{
            headerName: 'véhicule',
            field: 'value',
            unSortIcon: true,
            width: 95,
        }];

        this.FamillecolumnDefs = [{
            headerName: 'Famille',
            unSortIcon: true,
            valueGetter: function labelAndValue(params) {
                return params.data.label + "   " + params.data.value;
            },
            cellStyle: {
                'white-space': 'pre',
                'color': 'black'
            },
            width: 350,
            suppressSizeToFit: true
        }];

        this.CharacteristiccolumnDefs = [{
            headerName: 'Caractéristiques',
            unSortIcon: true,
            valueGetter: function labelAndValue(params) {
                return params.data.lcdvCode + "   " + params.data.lcdvLabel;
            },
            cellStyle: {
                'white-space': 'pre',
                'color': 'black'
            },
            width: 440,
            suppressSizeToFit: true
        }];

    }




    ngOnInit() {

        this.applicabilityService.getData('NATURE_CLASS').subscribe(data => {
            this.FamillerowData = data;
        });

        this.applicabilityService.getData('VEHICULE').subscribe((vehicleData:Array<Object>) => {
            vehicleData.sort((a,b) => this.compare(a,b))
            this.vehicle = vehicleData;
        });

        this.route.params.subscribe(params => {
            this.svc.getTopicById(params.stringToSubmit).subscribe((data: any) => {
                this.topicid = data.id;

            });
        });

    }
 
    ngAfterViewInit() {
       
        this.vehicleAgGrid.gridOptions.enableSorting = true;
        this.FamilleAgGrid.gridOptions.enableSorting = true;
        this.CharacteristicAgGrid.gridOptions.enableSorting = true;
        this.CharacteristicAgGrid.gridOptions.overlayNoRowsTemplate = '<span style=" border: 2px solid #444; background: #004770;color:white;">Aucune caractéristique disponible !</span>';
        this.CharacteristicAgGrid.api.setRowData([]);


    }

    removeChips(event) {
        if (!this.characteristicsObject) {
            return;
        }
        for (let i = 0; i < this.characteristicsObject.length; i++) {
            if (this.characteristicsObject[i].lcdvCode == event) {
                this.characteristicsObject.splice(i, 1)
            }
        }
        if (this.characteristicsChips.includes(event)) {
            let index = this.characteristicsChips.indexOf(event);
            this.characteristicsChips.splice(index, 1);
        }

    }

    resetScroll(grid) {
        switch (grid) {

            case 'vehicule':
                this.vehicleAgGrid.gridOptions.api.ensureIndexVisible(0, 'top');
                break;
            case 'Familie':
                this.FamilleAgGrid.gridOptions.api.ensureIndexVisible(0, 'top');
                break;
            case 'Characteristic':
                this.CharacteristicAgGrid.gridOptions.api.ensureIndexVisible(0, 'top');
                break;

        }

    }
    populateChips(event) {

        if (event.target.value.trim().length > 9) {
            this.snackbarService.add({
                msg: event.target.value + ' ' + ' est trop long pour être considéré! ',
                timeout: 2000,
                background: '#004770',
                color: 'white',
                action: {
                    text: 'got it',
                },
            });
            return;
        }

        if (this.isInValid(event.target.value)) {
            this.snackbarService.add({
                msg: " La valeur vide ne peut pas être ajoutée comme caractéristique !",
                timeout: 2000,
                background: '#004770',
                color: 'white',
                action: {
                    text: 'got it',
                },
            });
            event.target.value = '';
            return;
        }

        if (this.characteristicsChips.length < 5) {
            let notUnique = this.checkUniqueChar(event.target.value.trim());
            if (!notUnique) {
                this.characteristicsChips.push(event.target.value.trim());
                this.characteristicsObject.push({
                    lcdvCode: event.target.value.trim(),
                    lcdvLabel: ''
                })
            } else {
                this.snackbarService.add({
                    msg: event.target.value + ' ' + ' est déjà ajouté',
                    timeout: 2000,
                    background: '#004770',
                    color: 'white',
                    action: {
                        text: 'got it',
                    },
                });
            }
        } else {
            this.snackbarService.add({
                msg: 'Plus de 5 caractéristiques ne peuvent pas être ajoutées!',
                timeout: 2000,
                background: '#004770',
                color: 'white',
                action: {
                    text: 'got it',
                },
            });

        }
        event.target.value = '';
    }

    addCharacteristic() {

        let selectedNodes: any;
        selectedNodes = this.CharacteristicAgGrid.api.getSelectedRows();
        let value = selectedNodes[0].lcdvCode;

        if (this.characteristicsChips.length < 5) {

            let notUnique = this.checkUniqueChar(value.trim());
            if (!notUnique) {
                this.characteristicsChips.push(value.trim());
                this.characteristicsObject.push(selectedNodes[0]);
            } else {
                this.snackbarService.add({
                    msg: value + ' ' + ' est déjà ajouté',
                    timeout: 2000,
                    background: '#004770',
                    color: 'white',
                    action: {
                        text: 'got it',
                    },
                });
            }
        } else {
            this.snackbarService.add({
                msg: '  Plus de 5 caractéristiques ne peuvent pas être ajoutées !',
                timeout: 2000,
                background: '#004770',
                color: 'white',
                action: {
                    text: 'got it',
                },
            });

        }
        this.CharacteristicAgGrid.api.clearFocusedCell();
        this.CharacteristicAgGrid.gridOptions.api.deselectAll();

    }

    onComplexApplicabilityClick(editExistingApp ? : boolean, existingApp ? : any, counter ? : number) {

        if (!this.enable_information_screen) {
            this.snackbarService.add({
                msg: " S'il vous plaît créer une information d'abord !",
                timeout: 2000,
                background: '#004770',
                color: 'white',
                action: {
                    text: 'got it',
                },
            });

            return;
        }



        if (!this.complex_app || this.complex_app == undefined) {
            if (this.simpleApplicabilityBackup.length == 0) {
                for (let i = 0; i < this.parameters.length; i++) {
                    this.parameters[i].selected = false;
                    this.simpleApplicabilityBackup[i] = this.parameters[i];
                }
            }
            this.parameters.splice(0, this.parameters.length);
        } else if (this.complex_app) {
            this.resetApplicability();

        }

        this.simpleApplicabilityBackup.sort((a,b) => this.compare(a,b));
        this.VehiculerowData = this.simpleApplicabilityBackup;

        if (this.form == undefined || this.form == null || JSON.stringify(this.form.value) == '{}') {
            this.prepareInformation(true);
        }

        let info = this.form.get('informations') as FormArray;

        if (info == undefined || info == null) {
            this.prepareInformation(false, true);
        }
        let app = ( < FormGroup > info.at(0).get('applicability'));

        if (app == undefined || app == null) {
            this.prepareInformation(false, false, true);
        }

        let informations = this.form.get('informations') as FormArray;
        let applicability = ( < FormGroup > informations.at(0).get('applicability'));
        let criterias = applicability.get('criterias') as FormArray;

        if (!this.complex_app || this.complex_app == undefined) {
            while (criterias.length) {
                criterias.removeAt(0);
            }

        }

        if (editExistingApp) {

            this.editComplexApp = true;
            this.editCounter = counter;

            for (let j = 0; j < existingApp.lcdvcharacterstics.length; j++) {

                this.characteristicsChips.push(existingApp.lcdvcharacterstics[j].lcdvCode)
                this.characteristicsObject.push({
                    lcdvCode: existingApp.lcdvcharacterstics[j].lcdvCode,
                    lcdvLabel: existingApp.lcdvcharacterstics[j].lcdvLabel
                })

            }
            this.selectedVehicle = existingApp.value.toString();
            this.selectedVehicleLabel = existingApp.label.toString();

            this.vehicleAgGrid.api.forEachNode(function (node) {
                if (node.data.value === existingApp.value) {
                    node.setSelected(true);
                }
            });
        } else {
            this.editComplexApp = false;
            this.editCounter = 0;
        }

        this.display = true;

    }

    deleteComplexApp(complex_app, counter) {
        this.parameters.splice(counter,1);
        let informations = this.form.get('informations') as FormArray;
        let applicability = ( < FormGroup > informations.at(0).get('applicability'));
        let criterias = applicability.get('criterias') as FormArray;
        criterias.removeAt(counter);
    }
    addFamille() {
        if (this.selectedVehicle == '') {

            this.snackbarService.add({
                msg: "Veuillez d'abord sélectionner un véhicule",
                timeout: 2000,
                background: '#004770',
                color: 'white',
                action: {
                    text: 'got it',
                },
            });

            return;
        }

        let selectedNodes: any;
        selectedNodes = this.FamilleAgGrid.api.getSelectedRows();
        let code = selectedNodes[0].label;

        this.applicabilityService.getLcdvCode(code, this.selectedVehicle).subscribe(data => {
                this.CharacteristicrowData = data;
            },
            error => {
                this.CharacteristicrowData = [];
            }
        );

    }

    addVehicle() {

        let selectedNodes: any;
        selectedNodes = this.vehicleAgGrid.api.getSelectedRows();
        this.selectedVehicle = selectedNodes[0].value;
        this.selectedVehicleLabel = selectedNodes[0].label;
        this.vehicleAgGrid.api.clearFocusedCell();
        this.vehicleAgGrid.gridOptions.api.deselectAll();

        this.FamilleAgGrid.api.clearFocusedCell();
        this.FamilleAgGrid.gridOptions.api.deselectAll();

        this.CharacteristicAgGrid.api.clearFocusedCell();
        this.CharacteristicAgGrid.gridOptions.api.deselectAll();

        this.CharacteristicrowData = [];

    }



    validateClose() {

        if (this.complex_app) {
            this.closePopup();
            return;
        } else {
            for (let i = 0; i < this.simpleApplicabilityBackup.length; i++) {
                this.parameters[i] = this.simpleApplicabilityBackup[i];
            }
            this.closePopup();
        }
    }

    closePopup() {
        this.display = false;
        this.resetAllSelection();
    }

    checkUniqueChar(value) {
        if (this.characteristicsChips.length > 0) {
            return this.characteristicsChips.includes(value);

        } else {
            return false;
        }

    }

    isInValid(str) {
        return (!str || str.length === 0 || /^\s*$/.test(str))
    }

    resetAllSelection() {
        this.characteristic_Input = '';
        this.selectedVehicle = '';
        this.selectedVehicleLabel = '';
        this.characteristicsChips.splice(0, this.characteristicsChips.length);
        this.characteristicsObject.splice(0, this.characteristicsObject.length);
        this.CharacteristicrowData = [];

        this.vehicleAgGrid.api.clearFocusedCell();
        this.vehicleAgGrid.gridOptions.api.setFilterModel(null);
        this.vehicleAgGrid.gridOptions.api.deselectAll();

        this.FamilleAgGrid.api.clearFocusedCell();
        this.FamilleAgGrid.gridOptions.api.setFilterModel(null);
        this.FamilleAgGrid.gridOptions.api.deselectAll();

        this.CharacteristicAgGrid.api.clearFocusedCell();
        this.CharacteristicAgGrid.gridOptions.api.setFilterModel(null);
        this.CharacteristicAgGrid.gridOptions.api.deselectAll();

        this.vehicleAgGrid.api.setSortModel(null);
        this.FamilleAgGrid.api.setSortModel(null);
        this.CharacteristicAgGrid.api.setSortModel(null);
    }


    clearData() {
        if (this.characteristicsChips.length > 0 && this.isInValid(this.selectedVehicle) === false) {
            this.characteristicsChips.splice(0, this.characteristicsChips.length);
            this.selectedVehicle = '';
            this.selectedVehicleLabel = '';
        }
        this.selectedVehicle = '';
        this.selectedVehicleLabel = '';
    }


    uniqueCharacteristic() {

        let result;

        for (let i = 0; i < this.parameters.length; i++) {

            let lcdv = [];

            for (let j = 0; j < this.parameters[i].lcdvcharacterstics.length; j++) {
                lcdv.push(this.parameters[i].lcdvcharacterstics[j].lcdvCode);
            }

            let chips = this.characteristicsChips;

            if (this.parameters[i].value == this.selectedVehicle) {
                if (
                    lcdv.length === chips.length &&
                    lcdv.sort().every(function (value, index) {
                        return value === chips.sort()[index]
                    })
                ) {
                    result = false;
                    break;
                } else {
                    result = true;
                }
            } else {
                result = true;
            }


        }

        return result;
    }

    uniqueVehicule() {
        let uniquelcdv;
        let uniqueVehicule = true;
        let results;

        for (let i = 0; i < this.parameters.length; i++) {
            if (this.parameters[i].value == this.selectedVehicle) {
                uniqueVehicule = false;
                uniquelcdv = this.uniqueCharacteristic();
            }
        }

        if (uniqueVehicule || uniquelcdv) {
            results = true;
        } else if (this.parameters.length == 0) {
            results = true;
        } else {
            results = false;
        }


        return results;
    }
    validateComplexApplicability() {
        if (!this.isInValid(this.selectedVehicle) && this.uniqueVehicule()) {

            this.prepareApplicabilityJson();
            this.resetAllSelection();
            this.clearData();
            this.complex_app = true;

        } else if (!this.uniqueVehicule()) {
            this.snackbarService.add({
                msg: 'une applicabilité similaire est déjà ajoutée',
                timeout: 2000,
                background: '#004770',
                color: 'white',
                action: {
                    text: 'got it',
                },
            });

        } else {
            this.snackbarService.add({
                msg: " S'il vous plaît sélectionner un véhicule",
                timeout: 2000,
                background: '#004770',
                color: 'white',
                action: {
                    text: 'got it',
                },
            });
        }
    }

    prepareApplicabilityJson() {

        if (this.form == undefined || this.form == null || JSON.stringify(this.form.value) == '{}') {
            this.prepareInformation(true);
        }

        let informations = this.form.get('informations') as FormArray;

        if (informations == undefined || informations == null) {
            this.prepareInformation(false, true);
        }
        let applicability = ( < FormGroup > informations.at(0).get('applicability'));

        if (applicability == undefined || applicability == null) {
            this.prepareInformation(false, false, true);
        }

        applicability.get('type').patchValue('C');
        this.createApplicability();

    }

    createApplicability() {

        let informations = this.form.get('informations') as FormArray;
        let applicability = ( < FormGroup > informations.at(0).get('applicability'));
        let criterias = applicability.get('criterias') as FormArray;


        if (this.editComplexApp) {

            criterias.at(this.editCounter).get('label').patchValue(this.selectedVehicleLabel);
            criterias.at(this.editCounter).get('value').patchValue(this.selectedVehicle);
            criterias.at(this.editCounter).get('selected').patchValue(true);
            this.ref.detectChanges();

            let lcdvArray = criterias.at(this.editCounter).get('lcdvcharacterstics') as FormArray;

            while (lcdvArray.length) {
                lcdvArray.removeAt(0)
            }

            for (let i = 0; i < this.characteristicsObject.length; i++) {
                lcdvArray.push(new FormGroup({
                    lcdvLabel: new FormControl(this.characteristicsObject[i].lcdvLabel),
                    lcdvCode: new FormControl(this.characteristicsObject[i].lcdvCode)
                }))
            }

            this.parameters.splice(this.editCounter, 1);

            this.parameters.splice(this.editCounter, 0, {
                'label': this.selectedVehicleLabel,
                'value': this.selectedVehicle,
                'selected': true,
                'type': 'C',
                'lcdvcharacterstics': [...this.characteristicsObject]
            });

            this.display = false;

        } else {

            criterias.push(new FormGroup({
                label: new FormControl(this.selectedVehicleLabel),
                value: new FormControl(this.selectedVehicle),
                selected: new FormControl(true),
                lcdvcharacterstics: new FormArray([])
            }));

            let lcdvcharacterstics = criterias.at(criterias.length - 1).get('lcdvcharacterstics') as FormArray;

            for (let i = 0; i < this.characteristicsObject.length; i++) {
                lcdvcharacterstics.push(new FormGroup({
                    lcdvLabel: new FormControl(this.characteristicsObject[i].lcdvLabel),
                    lcdvCode: new FormControl(this.characteristicsObject[i].lcdvCode),
                }));
            }

            this.parameters.push({
                'label': this.selectedVehicleLabel,
                'value': this.selectedVehicle,
                'selected': true,
                'type': 'C',
                'lcdvcharacterstics': [...this.characteristicsObject]
            });

        }
    }

    prepareInformation(form ? : boolean, information ? : boolean, app ? : boolean) {
        if (form) {
            this.form.addControl('id', new FormControl(this.topicid));
            this.form.addControl('informations', new FormArray([
                new FormGroup({
                    id: new FormControl(''),
                    title: new FormControl(''),
                    areas: new FormArray([]),
                    applicability: new FormGroup({
                        type: new FormControl('C'),
                        criterias: new FormArray([])
                    })
                })
            ]));
        } else if (information) {
            this.form.addControl('informations', new FormArray([
                new FormGroup({
                    id: new FormControl(''),
                    title: new FormControl(''),
                    areas: new FormArray([]),
                    applicability: new FormGroup({
                        type: new FormControl('C'),
                        criterias: new FormArray([])
                    })
                })
            ]));
        } else if (app) {
            let informations = this.form.get('informations') as FormArray;
            ( < FormGroup > informations.at(0)).addControl('applicability', new FormGroup({
                type: new FormControl('C'),
                criterias: new FormArray([])
            }));
        }

    }

    resetApplicability() {
        this.simpleApplicabilityBackup = this.vehicle;
    }

    compare(a,b) {
        if (a.value < b.value)
          return -1;
        if (a.value > b.value)
          return 1;
        return 0;
      }
}

interface lcdvObject {
    lcdvCode: string;
    lcdvLabel: string;
}