import { AuthService } from './../auth/auth.service';
import { Component, OnInit } from '@angular/core';
import { TopicService } from '../service/topic/topic.service';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-topmenu',
  templateUrl: './topmenu.component.html',
  styleUrls: ['./topmenu.component.css']
})
export class TopmenuComponent implements OnInit {


  public isAdmin:boolean ; 
  public isExtract:boolean ;

  constructor(private svc: TopicService,
    private translate: TranslateService,
    private router: Router,
    public authService : AuthService) {

  }

  ngOnInit() {

    if(this.router.url.includes('saisie')){

      this.authService.isSaise.next(true);

    }else if(this.router.url.includes('administration')){
      this.isAdmin = true;
    }else if(this.router.url.includes('extraction')){
      this.isExtract = true;
    }
  }
  
  switchLanguage(language: string) {
    this.translate.use(language);
  }

  activate(event){
    
    switch(event){
      case 'Saisie':
      this.authService.isSaise.next(true);
      this.isAdmin = false;
      this.isExtract = false;
      break;
      case 'Administration':
      this.authService.isSaise.next(false);
      this.isAdmin = true;
      this.isExtract = false;
      break;
      case 'Extraction':
      this.authService.isSaise.next(false);
      this.isAdmin = false;
      this.isExtract = true;
      break;
    }
  }
} 