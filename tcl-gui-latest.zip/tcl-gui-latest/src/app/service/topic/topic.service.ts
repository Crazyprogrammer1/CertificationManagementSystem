import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import { AppConfig } from '../../app.config';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TopicService {
  topiCollection: Object;
  constructor(private http: HttpClient, private location: Location) { }

  getTopicById(topicId: string) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/topics/' + topicId;
    return this.http.get(url);
  }

  getDisplayModes():Observable<any> {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/topics/displaymodes';
    return this.http.get(url);
  }

  getTopicByCollectionId() {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/topics?collectionId=1';
    return this.http.get(url);
  }

  persistInformation(data) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/topics';
    const options = {headers: {'Content-Type': 'application/json'}};
    return this.http.post(url, data, options );
  }
   
  saveTopic(topic):Observable<any> {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/topics/savebasetopics';
    const options = {headers: {'Content-Type': 'application/json'}};
    return this.http.post(url, topic, options );
  }
}
