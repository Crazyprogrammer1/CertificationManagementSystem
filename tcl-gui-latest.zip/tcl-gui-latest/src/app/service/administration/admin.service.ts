import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { AppConfig } from '../../app.config';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AdminService {
  

  constructor(private http: HttpClient, private location: Location) { }


  getDefaultTopics(){
   let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
   let url = domain + '/topics/basetopics';
   return this.http.get(url).toPromise();
  }

  getBaseDataCollection(){
   let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
   let url = domain + '/topics/basedatacollection';
   return this.http.get(url).toPromise();
  }

  getEditableTopic(topicId){
   let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
   let url = domain + '/topics/topicdetails/'+ topicId;
   return this.http.get(url);
  }

  populateParameters() {
   let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
   let url = domain + '/parameters/distincttype';
   return this.http.get(url);
  }

  populateDataCollection():Observable<any>{
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/datacollection/distinctdatacollection';
    return this.http.get(url);
  }

    deleteParameterType(type: string) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + `/parameters/${type}`;
    return this.http.delete(url);
  }

    deleteDataCollection(id) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + `/datacollection/${id}`;
    return this.http.delete(url);
  }

    getParameterByType(type: string) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + `/parameters/details/${type}`;
    return this.http.get(url);
  }

  getTopicByCollectionId(id) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/topics?collectionId='+id;
    return this.http.get(url);
  }

  editParameter(parameter):Observable<any> {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/parameters';
    return this.http.post(url, parameter);
  }

  editOrSaveDataCollection(dataCollection):Observable<any> {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/datacollection';
    return this.http.post(url, dataCollection);
  }

  deleteParameterById(id) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + `/parameters/deleteById/${id}`;
    return this.http.delete(url);
  }
  
}
