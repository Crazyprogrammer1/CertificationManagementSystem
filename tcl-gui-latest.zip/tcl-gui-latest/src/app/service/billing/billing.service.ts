import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import 'rxjs/add/operator/map';
import { AppConfig } from '../../app.config';

@Injectable({
  providedIn: 'root'
})
export class BillingService {

  constructor(private http: HttpClient, private location: Location) { 

  }
  extractBillingData(fromDate:any,toDate:any) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + `/billing?fromDate=${fromDate}&toDate=${toDate}`;
    return this.http.get(url);
  }
}
