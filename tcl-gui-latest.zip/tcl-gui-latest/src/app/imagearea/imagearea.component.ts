import { ImageService } from './../image-upload/image.service';
import { ImageUploadComponent } from './../image-upload/image-upload.component';

import { TopicComponent } from './../topic/topic.component';
import { Component, OnInit, Input, OnChanges, forwardRef  ,Inject, OnDestroy} from '@angular/core';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { AfterViewInit, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { MessageService } from 'primeng/api';
import { FormBuilder, FormGroup, FormArray, FormControl, FormControlName } from '@angular/forms';
import { InformationService } from '../service/information/information.service';
import { ComponentRef, ComponentFactoryResolver, ViewContainerRef} from "@angular/core";
import { InformationImageService } from '../service/Image/image.service';

@Component({
  selector: 'app-imagearea',
  templateUrl: './imagearea.component.html',
  styleUrls: ['./imagearea.component.css']
})
export class ImageareaComponent implements OnInit  {
  compInteraction : any;
  _ref : any;
  parts: FormArray;

  @Input('ImageBinaryData') ImageBinaryData;
  @Input('ImagesToBedeleted') ImagesToBedeleted;

  componentLevelBinaryData:any[] = [];
  componentLevelImages:any[] =[];

  @ViewChild(ImageUploadComponent) img_upload_comp;

  @Input('fileCounter')fileCounter;

  @Input('disableCaption') disableCaption: boolean;
  @Input('image_index') image_index;
  @Input('form') form : FormGroup;
  @ViewChild(ImageUploadComponent) image_upload_component;

  @Input('first_image_names_from_rest_call') first_image_names_from_rest_call;
  @Input('second_image_names_from_rest_call') second_image_names_from_rest_call;
  @Input('third_image_names_from_rest_call') third_image_names_from_rest_call;
  @Input('fourth_image_names_from_rest_call') fourth_image_names_from_rest_call;
  @Input('fifth_image_names_from_rest_call') fifth_image_names_from_rest_call;
  @Input('sixth_image_names_from_rest_call') sixth_image_names_from_rest_call;
  @Input('seven_image_names_from_rest_call') seven_image_names_from_rest_call;
  @Input('eight_image_names_from_rest_call') eight_image_names_from_rest_call;
  @Input('nine_image_names_from_rest_call') nine_image_names_from_rest_call;
  @Input('ten_image_names_from_rest_call') ten_image_names_from_rest_call;
  @Input('eleven_image_names_from_rest_call') eleven_image_names_from_rest_call;
  @Input('twelve_image_names_from_rest_call') twelve_image_names_from_rest_call;
  @Input('thirteen_image_names_from_rest_call') thirteen_image_names_from_rest_call;
  @Input('fourteen_image_names_from_rest_call') fourteen_image_names_from_rest_call;
  @Input('fifteen_image_names_from_rest_call') fifteen_image_names_from_rest_call;
  @Input('sixteen_image_names_from_rest_call') sixteen_image_names_from_rest_call;
  @Input('seventeen_image_names_from_rest_call') seventeen_image_names_from_rest_call;
  @Input('eighteen_image_names_from_rest_call') eighteen_image_names_from_rest_call;
  @Input('nineteen_image_names_from_rest_call') nineteen_image_names_from_rest_call;
  @Input('twenty_image_names_from_rest_call') twenty_image_names_from_rest_call;
  @Input('twenty_one_image_names_from_rest_call') twenty_one_image_names_from_rest_call;
  @Input('twenty_two_image_names_from_rest_call') twenty_two_image_names_from_rest_call;
  @Input('twenty_three_image_names_from_rest_call') twenty_three_image_names_from_rest_call;
  @Input('twenty_four_image_names_from_rest_call') twenty_four_image_names_from_rest_call;
  @Input('twenty_five_image_names_from_rest_call') twenty_five_image_names_from_rest_call;

  
  @Input('imageToShow1') imageToShow1: any[];
  @Input('imageToShow2') imageToShow2: any[];
  @Input('imageToShow3') imageToShow3: any[];
  @Input('imageToShow4') imageToShow4: any[];
  @Input('imageToShow5') imageToShow5: any[];
  @Input('imageToShow6') imageToShow6: any[];
  @Input('imageToShow7') imageToShow7: any[];
  @Input('imageToShow8') imageToShow8: any[];
  @Input('imageToShow9') imageToShow9: any[];
  @Input('imageToShow10') imageToShow10: any[];
  @Input('imageToShow11') imageToShow11: any[];
  @Input('imageToShow12') imageToShow12: any[];
  @Input('imageToShow13') imageToShow13: any[];
  @Input('imageToShow14') imageToShow14: any[];
  @Input('imageToShow15') imageToShow15: any[];
  @Input('imageToShow16') imageToShow16: any[];
  @Input('imageToShow17') imageToShow17: any[];
  @Input('imageToShow18') imageToShow18: any[];
  @Input('imageToShow19') imageToShow19: any[];
  @Input('imageToShow20') imageToShow20: any[];
  @Input('imageToShow21') imageToShow21: any[];
  @Input('imageToShow22') imageToShow22: any[]; 
  @Input('imageToShow23') imageToShow23: any[];
  @Input('imageToShow24') imageToShow24: any[];
  @Input('imageToShow25') imageToShow25: any[];



  @Input('image_name_array') image_name_array;
  @Input('imageNameArray1') imageNameArray1;
  @Input('imageNameArray2') imageNameArray2;
  @Input('imageNameArray3') imageNameArray3;
  @Input('imageNameArray4') imageNameArray4;
  @Input('imageNameArray5') imageNameArray5;
  @Input('imageNameArray6') imageNameArray6;
  @Input('imageNameArray7') imageNameArray7;
  @Input('imageNameArray8') imageNameArray8;
  @Input('imageNameArray9') imageNameArray9;
  @Input('imageNameArray10') imageNameArray10;
  @Input('imageNameArray11') imageNameArray11;
  @Input('imageNameArray12') imageNameArray12;
  @Input('imageNameArray13') imageNameArray13;
  @Input('imageNameArray14') imageNameArray14;
  @Input('imageNameArray15') imageNameArray15;
  @Input('imageNameArray16') imageNameArray16;
  @Input('imageNameArray17') imageNameArray17;
  @Input('imageNameArray18') imageNameArray18;
  @Input('imageNameArray19') imageNameArray19;
  @Input('imageNameArray20') imageNameArray20;
  @Input('imageNameArray21') imageNameArray21;
  @Input('imageNameArray22') imageNameArray22;
  @Input('imageNameArray23') imageNameArray23;
  @Input('imageNameArray24') imageNameArray24;
  @Input('imageNameArray25') imageNameArray25;



  image_name_counter: number = 0;
  
  @Input('image_names1')  image_names1: string[] = [];
  @Input('image_names2')  image_names2: string[] = [];
  @Input('image_names3')  image_names3: string[] = [];
  @Input('image_names4')  image_names4: string[] = [];
  @Input('image_names5')  image_names5: string[] = [];
  @Input('image_names6')  image_names6: string[] = [];
  @Input('image_names7')  image_names7: string[] = [];
  @Input('image_names8')  image_names8: string[] = [];
  @Input('image_names9')  image_names9: string[] = [];
  @Input('image_names10') image_names10: string[] = [];
  @Input('image_names11') image_names11: string[] = [];
  @Input('image_names12') image_names12: string[] = [];
  @Input('image_names13') image_names13: string[] = [];
  @Input('image_names14') image_names14: string[] = [];
  @Input('image_names15') image_names15: string[] = [];
  @Input('image_names16') image_names16: string[] = [];
  @Input('image_names17') image_names17: string[] = [];
  @Input('image_names18') image_names18: string[] = [];
  @Input('image_names19') image_names19: string[] = [];
  @Input('image_names20') image_names20: string[] = [];
  @Input('image_names21') image_names21: string[] = [];
  @Input('image_names22') image_names22: string[] = [];
  @Input('image_names23') image_names23: string[] = [];
  @Input('image_names24') image_names24: string[] = [];
  @Input('image_names25') image_names25: string[] = [];
  

  parts_array1: any[] = [];
  parts_array2: any[] = [];

  fileUploaded: boolean;

  showCloseButton1: boolean = false;
  showCloseButton2: boolean = false;
  showCloseButton3: boolean = false;
  showCloseButton4: boolean = false;
  showCloseButton5: boolean = false;
  showCloseButton6: boolean = false;
  showCloseButton7: boolean = false;
  showCloseButton8: boolean = false;
  showCloseButton9: boolean = false;
  showCloseButton10: boolean = false;
  showCloseButton11: boolean = false;
  showCloseButton12: boolean = false;
  showCloseButton13: boolean = false;
  showCloseButton14: boolean = false;
  showCloseButton15: boolean = false;
  showCloseButton16: boolean = false;
  showCloseButton17: boolean = false;
  showCloseButton18: boolean = false;
  showCloseButton19: boolean = false;
  showCloseButton20: boolean = false;
  showCloseButton21: boolean = false;
  showCloseButton22: boolean = false;
  showCloseButton23: boolean = false;
  showCloseButton24: boolean = false;
  showCloseButton25: boolean = false;

  @Input('is_image_editable1') is_image_editable1: boolean;
  @Input('is_image_editable2') is_image_editable2: boolean;
  @Input('is_image_editable3') is_image_editable3: boolean;
  @Input('is_image_editable4') is_image_editable4: boolean;
  @Input('is_image_editable5') is_image_editable5: boolean;
  @Input('is_image_editable6') is_image_editable6: boolean;
  @Input('is_image_editable7') is_image_editable7: boolean;
  @Input('is_image_editable8') is_image_editable8: boolean;
  @Input('is_image_editable9') is_image_editable9: boolean;
  @Input('is_image_editable10') is_image_editable10: boolean;
  @Input('is_image_editable11') is_image_editable11: boolean;
  @Input('is_image_editable12') is_image_editable12: boolean;
  @Input('is_image_editable13') is_image_editable13: boolean;
  @Input('is_image_editable14') is_image_editable14: boolean;
  @Input('is_image_editable15') is_image_editable15: boolean;
  @Input('is_image_editable16') is_image_editable16: boolean;
  @Input('is_image_editable17') is_image_editable17: boolean;
  @Input('is_image_editable18') is_image_editable18: boolean;
  @Input('is_image_editable19') is_image_editable19: boolean;
  @Input('is_image_editable20') is_image_editable20: boolean;
  @Input('is_image_editable21') is_image_editable21: boolean;
  @Input('is_image_editable22') is_image_editable22: boolean;
  @Input('is_image_editable23') is_image_editable23: boolean;
  @Input('is_image_editable24') is_image_editable24: boolean;
  @Input('is_image_editable25') is_image_editable25: boolean;

  @Input('image_area_1_disabled') image_area_1_disabled: boolean;
  @Input('image_area_2_disabled') image_area_2_disabled: boolean;
  @Input('image_area_3_disabled') image_area_3_disabled: boolean;
  @Input('image_area_4_disabled') image_area_4_disabled: boolean;
  @Input('image_area_5_disabled') image_area_5_disabled: boolean;
  @Input('image_area_6_disabled') image_area_6_disabled: boolean;
  @Input('image_area_7_disabled') image_area_7_disabled: boolean;
  @Input('image_area_8_disabled') image_area_8_disabled: boolean;
  @Input('image_area_9_disabled') image_area_9_disabled: boolean;
  @Input('image_area_10_disabled') image_area_10_disabled: boolean;
  @Input('image_area_11_disabled') image_area_11_disabled: boolean;
  @Input('image_area_12_disabled') image_area_12_disabled: boolean;
  @Input('image_area_13_disabled') image_area_13_disabled: boolean;
  @Input('image_area_14_disabled') image_area_14_disabled: boolean;
  @Input('image_area_15_disabled') image_area_15_disabled: boolean;
  @Input('image_area_16_disabled') image_area_16_disabled: boolean;
  @Input('image_area_17_disabled') image_area_17_disabled: boolean;
  @Input('image_area_18_disabled') image_area_18_disabled: boolean;
  @Input('image_area_19_disabled') image_area_19_disabled: boolean;
  @Input('image_area_20_disabled') image_area_20_disabled: boolean;
  @Input('image_area_21_disabled') image_area_21_disabled: boolean;
  @Input('image_area_22_disabled') image_area_22_disabled: boolean;
  @Input('image_area_23_disabled') image_area_23_disabled: boolean;
  @Input('image_area_24_disabled') image_area_24_disabled: boolean;
  @Input('image_area_25_disabled') image_area_25_disabled: boolean;
  

 

constructor(

  private CFR: ComponentFactoryResolver,
  @Inject(ElementRef) elementRef: ElementRef,
  private formBuilder: FormBuilder,
  private messageService: MessageService,
  private renderer2: Renderer2,
  private imageservice: ImageService,
  private infoSvc: InformationService,
  private imageService: InformationImageService
) {
  this.fileUploaded = this.imageservice.getFileUploaded();
}

ngOnInit(){
}

get imageCloseButton() {
  switch(this.image_index) {

    case 1:
    return this.showCloseButton1;
   
    case 2:
    return this.showCloseButton2;

    case 3:
    return this.showCloseButton3;

    case 4:
    return this.showCloseButton4;

    case 5:
    return this.showCloseButton5;

    case 6:
    return this.showCloseButton6;

    case 7:
    return this.showCloseButton7;

    case 8:
    return this.showCloseButton8;

    case 9:
    return this.showCloseButton9;

    case 10:
    return this.showCloseButton10;

    case 11:
    return this.showCloseButton11;

    
    case 12:
    return this.showCloseButton12;
  
    case 13:
    return this.showCloseButton13;

    case 14:
    return this.showCloseButton14;

    case 15:
    return this.showCloseButton15;

    case 16:
    return this.showCloseButton16;

    case 17:
    return this.showCloseButton17;

    case 18:
    return this.showCloseButton18;

    case 19:
    return this.showCloseButton19;

    case 20:
    return this.showCloseButton20;

    case 21:
    return this.showCloseButton21;

    case 22:
    return this.showCloseButton22;

    case 23:
    return this.showCloseButton23;

    case 24:
    return this.showCloseButton24;

    case 25:
    return this.showCloseButton25;

  }

}



  getImageAreaDisabled() {

    switch(this.image_index) {

      case 1:
      return this.image_area_1_disabled;
     
      case 2:
      return this.image_area_2_disabled;
  
      case 3:
      return this.image_area_3_disabled;

      case 4:
      return this.image_area_4_disabled;

      case 5:
      return this.image_area_5_disabled;

      case 6:
      return this.image_area_6_disabled;

      case 7:
      return this.image_area_7_disabled;

    case 8:
    return this.image_area_8_disabled;

    case 9:
    return this.image_area_9_disabled;

    case 10:
    return this.image_area_10_disabled;

    case 11:
    return this.image_area_11_disabled;

    
    case 12:
    return this.image_area_12_disabled;
  
    case 13:
    return this.image_area_13_disabled;

    case 14:
    return this.image_area_14_disabled;

    case 15:
    return this.image_area_15_disabled;

    case 16:
    return this.image_area_16_disabled;

    case 17:
    return this.image_area_17_disabled;

    case 18:
    return this.image_area_18_disabled;

    case 19:
    return this.image_area_19_disabled;

    case 20:
    return this.image_area_20_disabled;

    case 21:
    return this.image_area_21_disabled;

    case 22:
    return this.image_area_22_disabled;

    case 23:
    return this.image_area_23_disabled;

    case 24:
    return this.image_area_24_disabled;

    case 25:
    return this.image_area_25_disabled;
    }
  
  }
get isImageEditable() {
  switch(this.image_index) {

    case 1:
    return this.is_image_editable1;
   
    case 2:
    return this.is_image_editable2;

    case 3:
    return this.is_image_editable3;

    case 4:
    return this.is_image_editable4;

    case 5:
    return this.is_image_editable5;

    case 6:
    return this.is_image_editable6;

    case 7:
    return this.is_image_editable7;

    case 8:
    return this.is_image_editable8;

    case 9:
    return this.is_image_editable9;

    case 10:
    return this.is_image_editable10;

    case 11:
    return this.is_image_editable11;

    
    case 12:
    return this.is_image_editable12;
  
    case 13:
    return this.is_image_editable13;

    case 14:
    return this.is_image_editable14;

    case 15:
    return this.is_image_editable15;

    case 16:
    return this.is_image_editable16;

    case 17:
    return this.is_image_editable17;

    case 18:
    return this.is_image_editable18;

    case 19:
    return this.is_image_editable19;

    case 20:
    return this.is_image_editable20;

    case 21:
    return this.is_image_editable21;

    case 22:
    return this.is_image_editable22;

    case 23:
    return this.is_image_editable23;

    case 24:
    return this.is_image_editable24;

    case 25:
    return this.is_image_editable25;
  }
}

get imageAreaName(){
  return 'image_area_'+this.image_index;
}
  editImageArea(target) {
   this.disableCaption = false;
    switch (target) {
      case 'image_area_1':
        this.image_area_1_disabled = false;
        this.is_image_editable1 = true;
        this.showCloseButton1 = true;
        break;
      case 'image_area_2':
        this.image_area_2_disabled = false;
        this.is_image_editable2 = true;
        this.showCloseButton2 = true;
        break;
      case 'image_area_3':
        this.image_area_3_disabled = false;
        this.is_image_editable3 = true;
        this.showCloseButton3 = true;
        break;
      case 'image_area_4':
        this.image_area_4_disabled = false;
        this.is_image_editable4 = true;
        this.showCloseButton4 = true;
        break;
      case 'image_area_5':
        this.image_area_5_disabled = false;
        this.is_image_editable5 = true;
        this.showCloseButton5 = true;
        break;
      case 'image_area_6':
        this.image_area_6_disabled = false;
        this.is_image_editable6 = true;
        this.showCloseButton6 = true;
        break;
      case 'image_area_7':
        this.image_area_7_disabled = false;
        this.is_image_editable7 = true;
        this.showCloseButton7 = true;
        break;
      case 'image_area_8':
        this.image_area_8_disabled = false;
        this.is_image_editable8 = true;
        this.showCloseButton8 = true;
        break;
      case 'image_area_9':
        this.image_area_9_disabled = false;
        this.is_image_editable9 = true;
        this.showCloseButton9 = true;
        break;
      case 'image_area_10':
        this.image_area_10_disabled = false;
        this.is_image_editable10 = true;
        this.showCloseButton10 = true;
        break;
      case 'image_area_11':
        this.image_area_11_disabled = false;
        this.is_image_editable11 = true;
        this.showCloseButton11 = true;
        break;
      case 'image_area_12':
        this.image_area_12_disabled = false;
        this.is_image_editable12 = true;
        this.showCloseButton12 = true;
        break;
      case 'image_area_13':
        this.image_area_13_disabled = false;
        this.is_image_editable13 = true;
        this.showCloseButton13 = true;
        break;
      case 'image_area_14':
        this.image_area_14_disabled = false;
        this.is_image_editable14 = true;
        this.showCloseButton14 = true;
        break;
      case 'image_area_15':
        this.image_area_15_disabled = false;
        this.is_image_editable15 = true;
        this.showCloseButton15 = true;
        break;
      case 'image_area_16':
        this.image_area_16_disabled = false;
        this.is_image_editable16 = true;
        this.showCloseButton16 = true;
        break;
      case 'image_area_17':
        this.image_area_17_disabled = false;
        this.is_image_editable17 = true;
        this.showCloseButton17 = true;
        break;
      case 'image_area_18':
        this.image_area_18_disabled = false;
        this.is_image_editable18 = true;
        this.showCloseButton18 = true;
      case 'image_area_19':
        this.image_area_19_disabled = false;
        this.is_image_editable19 = true;
        this.showCloseButton19 = true;
        break;
      case 'image_area_20':
        this.image_area_20_disabled = false;
        this.is_image_editable20 = true;
        this.showCloseButton20 = true;
      case 'image_area_21':
        this.image_area_21_disabled = false;
        this.is_image_editable21 = true;
        this.showCloseButton21 = true;
      case 'image_area_22':
        this.image_area_22_disabled = false;
        this.is_image_editable22 = true;
        this.showCloseButton22 = true;
      case 'image_area_23':
        this.image_area_23_disabled = false;
        this.is_image_editable23 = true;
        this.showCloseButton23 = true;
      case 'image_area_24':
        this.image_area_24_disabled = false;
        this.is_image_editable24 = true;
        this.showCloseButton24 = true;
        case 'image_area_25':
        this.image_area_25_disabled = false;
        this.is_image_editable25 = true;
        this.showCloseButton25 = true;
    }

  }

  disableImageEdit(target) {
    switch (target) {
      case 'image_area_1':
        this.image_area_1_disabled = true;
        this.is_image_editable1 = false;
        this.showCloseButton1 = false;
        break;
      case 'image_area_2':
        this.image_area_2_disabled = true;
        this.is_image_editable2 = false;
        this.showCloseButton2 = false;
        break;
      case 'image_area_3':
        this.image_area_3_disabled = true;
        this.is_image_editable3 = false;
        this.showCloseButton3 = false;
        break;
      case 'image_area_4':
        this.image_area_4_disabled = true;
        this.is_image_editable4 = false;
        this.showCloseButton4 = false;
        break;
      case 'image_area_5':
        this.image_area_5_disabled = true;
        this.is_image_editable5 = false;
        this.showCloseButton5 = false;
        break;
      case 'image_area_6':
        this.image_area_6_disabled = true;
        this.is_image_editable6 = false;
        this.showCloseButton6 = false;
        break;
        case 'image_area_7':
        this.image_area_7_disabled = true;
        this.is_image_editable7 = false;
        this.showCloseButton7 = false;
        break;
      case 'image_area_8':
        this.image_area_8_disabled = true;
        this.is_image_editable8 = false;
        this.showCloseButton8 = false;
        break;
      case 'image_area_9':
        this.image_area_9_disabled = true;
        this.is_image_editable9 = false;
        this.showCloseButton9 = false;
        break;
      case 'image_area_10':
        this.image_area_10_disabled = true;
        this.is_image_editable10 = false;
        this.showCloseButton10 = false;
        break;
      case 'image_area_11':
        this.image_area_11_disabled = true;
        this.is_image_editable11 = false;
        this.showCloseButton11 = false;
        break;
      case 'image_area_12':
        this.image_area_12_disabled = true;
        this.is_image_editable12 = false;
        this.showCloseButton12 = false;
        break;
      case 'image_area_13':
        this.image_area_13_disabled = true;
        this.is_image_editable13 = false;
        this.showCloseButton13 = false;
        break;
      case 'image_area_14':
        this.image_area_14_disabled = true;
        this.is_image_editable14 = false;
        this.showCloseButton14 = false;
        break;
      case 'image_area_15':
        this.image_area_15_disabled = true;
        this.is_image_editable15 = false;
        this.showCloseButton15 = false;
        break;
      case 'image_area_16':
        this.image_area_16_disabled = true;
        this.is_image_editable16 = false;
        this.showCloseButton16 = false;
        break;
      case 'image_area_17':
        this.image_area_17_disabled = true;
        this.is_image_editable17 = false;
        this.showCloseButton17 = false;
        break;
      case 'image_area_18':
        this.image_area_18_disabled = true;
        this.is_image_editable18 = false;
        this.showCloseButton18 = false;
      case 'image_area_19':
        this.image_area_19_disabled = true;
        this.is_image_editable19 = false;
        this.showCloseButton19 = false;
        break;
      case 'image_area_20':
        this.image_area_20_disabled = true;
        this.is_image_editable20 = false;
        this.showCloseButton20 = false;
      case 'image_area_21':
        this.image_area_21_disabled = true;
        this.is_image_editable21 = false;
        this.showCloseButton21 = false;
      case 'image_area_22':
        this.image_area_22_disabled = true;
        this.is_image_editable22 = false;
        this.showCloseButton22 = false;
      case 'image_area_23':
        this.image_area_23_disabled = true;
        this.is_image_editable23 = false;
        this.showCloseButton23 = false;
      case 'image_area_24':
        this.image_area_24_disabled = true;
        this.is_image_editable24 = false;
        this.showCloseButton24 = false;
        case 'image_area_25':
        this.image_area_25_disabled = true;
        this.is_image_editable25 = false;
        this.showCloseButton25 = false;
    }

  }

  get imageIndexAsString() {
    return this.image_index.toString();
  }

  get imageToShowVariable() {

    switch(this.image_index) {

      case 1:
      return this.imageToShow1;
     
      case 2:
      return this.imageToShow2;
  
      case 3:
      return this.imageToShow3;

      case 4:
      return this.imageToShow4;

      case 5:
      return this.imageToShow5;

      case 6:
      return this.imageToShow6;

      case 7:
      return this.imageToShow7;

      case 8:
      return this.imageToShow8;

      case 9:
      return this.imageToShow9;

      case 10:
      return this.imageToShow10;

      case 11:
      return this.imageToShow11;

      case 12:
      return this.imageToShow12;

      case 13:
      return this.imageToShow13;

      case 14:
      return this.imageToShow14;

      case 15:
      return this.imageToShow15;

      case 16:
      return this.imageToShow16;

      case 17:
      return this.imageToShow17;

      case 18:
      return this.imageToShow18;

      case 19:
      return this.imageToShow19;

      case 20:
      return this.imageToShow20;

      case 21:
      return this.imageToShow21;

      case 22:
      return this.imageToShow22;

      case 23:
      return this.imageToShow23;
      
      case 24:
      return this.imageToShow24;

      case 25:
      return this.imageToShow25;
    }
  }

  deleteImage(fileName: String, imagearea: String) {
    let informations = (<FormArray>this.form.controls['informations']);
    this.img_upload_comp.fileCounter--;

    let areas = informations.at(0).get('areas') as FormArray;
    if (imagearea == "1") {
      this.processDeletionOfImages(fileName,this.first_image_names_from_rest_call,  this.imageToShow1);
    } else if (imagearea == "2"){
      this.processDeletionOfImages(fileName,this.second_image_names_from_rest_call,  this.imageToShow2);
    } else if (imagearea == "3"){
      this.processDeletionOfImages(fileName,this.third_image_names_from_rest_call,  this.imageToShow3);
    } else if (imagearea == "4"){
      this.processDeletionOfImages(fileName,this.fourth_image_names_from_rest_call,  this.imageToShow4);
    } else if (imagearea == "5"){
      this.processDeletionOfImages(fileName,this.fifth_image_names_from_rest_call,  this.imageToShow5);
    } else if (imagearea == "6"){
      this.processDeletionOfImages(fileName,this.sixth_image_names_from_rest_call,  this.imageToShow6);
    }
    else if (imagearea == "7"){
      this.processDeletionOfImages(fileName,this.seven_image_names_from_rest_call,  this.imageToShow7);
    }
    else if (imagearea == "8"){
      this.processDeletionOfImages(fileName,this.eight_image_names_from_rest_call,  this.imageToShow8);
    }
    else if (imagearea == "9"){
      this.processDeletionOfImages(fileName,this.nine_image_names_from_rest_call,  this.imageToShow9);
    }
    else if (imagearea == "10"){
      this.processDeletionOfImages(fileName,this.ten_image_names_from_rest_call,  this.imageToShow10);
    }
    else if (imagearea == "11"){
      this.processDeletionOfImages(fileName,this.eleven_image_names_from_rest_call,  this.imageToShow11);
    }
    else if (imagearea == "12"){
      this.processDeletionOfImages(fileName,this.twelve_image_names_from_rest_call,  this.imageToShow12);
    }
    else if (imagearea == "13"){
      this.processDeletionOfImages(fileName,this.thirteen_image_names_from_rest_call,  this.imageToShow13);
    }
    else if (imagearea == "14"){
      this.processDeletionOfImages(fileName,this.fourteen_image_names_from_rest_call,  this.imageToShow14);
    }
    else if (imagearea == "15"){
      this.processDeletionOfImages(fileName,this.fifteen_image_names_from_rest_call,  this.imageToShow15);
    }
    else if (imagearea == "16"){
      this.processDeletionOfImages(fileName,this.sixteen_image_names_from_rest_call,  this.imageToShow16);
    }
    else if (imagearea == "17"){
      this.processDeletionOfImages(fileName,this.seventeen_image_names_from_rest_call,  this.imageToShow17);
    }
    else if (imagearea == "18"){
      this.processDeletionOfImages(fileName,this.eighteen_image_names_from_rest_call,  this.imageToShow18);
    }
    else if (imagearea == "19"){
      this.processDeletionOfImages(fileName,this.nineteen_image_names_from_rest_call,  this.imageToShow19);
    }
    else if (imagearea == "20"){
      this.processDeletionOfImages(fileName,this.twenty_image_names_from_rest_call,  this.imageToShow20);
    }
    else if (imagearea == "21"){
      this.processDeletionOfImages(fileName,this.twenty_one_image_names_from_rest_call,  this.imageToShow21);
    }
    else if (imagearea == "22"){
      this.processDeletionOfImages(fileName,this.twenty_two_image_names_from_rest_call,  this.imageToShow22);
    }
    else if (imagearea == "23"){
      this.processDeletionOfImages(fileName,this.twenty_three_image_names_from_rest_call,  this.imageToShow23);
    }
    else if (imagearea == "24"){
      this.processDeletionOfImages(fileName,this.twenty_four_image_names_from_rest_call,  this.imageToShow24);
    }
    else if (imagearea == "25"){
      this.processDeletionOfImages(fileName,this.twenty_five_image_names_from_rest_call,  this.imageToShow25);
    }
    for(let i = 0 ; i < areas.length ; i++) {
      if(areas.at(i).get('imagearea_no').value == imagearea) {
        let parts = areas.at(i).get('parts') as FormArray;
        for(let j = 0 ; j <parts.length ; j++) {
          if(parts.at(j).value.value == fileName)
                parts.removeAt(j);
                
          }

      }
    }

    console.log(JSON.stringify(this.form.value))
  }
  
processDeletionOfImages(fileName ,imagenames, imagetoshow ) {

  for(let n=0;n<imagenames.length;n++){
    if(fileName == imagenames[n]){
      imagenames.splice(n,1);
      break;
    }
  }

  for(let i = 0 ; i < imagetoshow.length;i++) {
    if(fileName == imagetoshow[i][1]){
      imagetoshow.splice(i,1);
      break;
    }
  }

  this.componentLevelImages.push(
    {
      fileName : fileName
    }
  );
}

imageValues : any[] = [];

addnewImagePart(target) {
  let informations = ( < FormArray > this.form.controls['informations']);
  let areas = informations.at(0).get('areas') as FormArray;
  let type = 'image';
  let newParts  = new FormArray([]);
  this.imageValues = [];
  let positionCounter = 1;

  this.ImagesToBedeleted.push(...this.componentLevelImages);
  this.ImageBinaryData.push(...this.componentLevelBinaryData)

  for (let  i  =  0 ;  i  <  areas.length ;  i ++) {
   if (areas.at(i).get('imagearea_no').value  ==  this.image_index) {
    this.parts  =  areas.at(i).get('parts')  as  FormArray;
   }
  }

  switch (target) {
   case 'image_area_1':

    this.imageValues = this.image_names1;
    this.hideCaption(this.image_names1, this.imageToShow1);

    break;
   case 'image_area_2':

    this.imageValues = this.image_names2;
    this.hideCaption(this.image_names2, this.imageToShow2);

    break;
   case 'image_area_3':

    this.imageValues = this.image_names3;
    this.hideCaption(this.image_names3, this.imageToShow3);
    break;
   case 'image_area_4':

    this.imageValues = this.image_names4;
    this.hideCaption(this.image_names4, this.imageToShow4);
    break;
   case 'image_area_5':

    this.imageValues = this.image_names5;
    this.hideCaption(this.image_names5, this.imageToShow5);
    break;
   case 'image_area_6':

    this.imageValues = this.image_names6;
    this.hideCaption(this.image_names6, this.imageToShow6);

    break;
   case 'image_area_7':

    this.imageValues = this.image_names7;
    this.hideCaption(this.image_names7, this.imageToShow7);

    break;
   case 'image_area_8':

    this.imageValues = this.image_names8;
    this.hideCaption(this.image_names8, this.imageToShow8);
    break;
   case 'image_area_9':

    this.imageValues = this.image_names9;
    this.hideCaption(this.image_names9, this.imageToShow9);

    break;
   case 'image_area_10':

    this.imageValues = this.image_names10;
    this.hideCaption(this.image_names10, this.imageToShow10);

    break;
   case 'image_area_11':

    this.imageValues = this.image_names11;
    this.hideCaption(this.image_names11, this.imageToShow11);

    break;
   case 'image_area_12':

    this.imageValues = this.image_names12;
    this.hideCaption(this.image_names12, this.imageToShow12);

    break;
   case 'image_area_13':

    this.imageValues = this.image_names13;
    this.hideCaption(this.image_names13, this.imageToShow13);

    break;
   case 'image_area_14':

    this.imageValues = this.image_names14;
    this.hideCaption(this.image_names14, this.imageToShow14);
    break;
   case 'image_area_15':

    this.imageValues = this.image_names15;
    this.hideCaption(this.image_names15, this.imageToShow15);
    break;
   case 'image_area_16':

    this.imageValues = this.image_names16;
    this.hideCaption(this.image_names16, this.imageToShow16);
    break;
   case 'image_area_17':

 
    this.imageValues = this.image_names17;
    this.hideCaption(this.image_names17, this.imageToShow17);
    break;
   case 'image_area_18':

 
    this.imageValues = this.image_names18;
    this.hideCaption(this.image_names18, this.imageToShow18);
    break;
   case 'image_area_19':

 
    this.imageValues = this.image_names19;
    this.hideCaption(this.image_names19, this.imageToShow19);
    break;
   case 'image_area_20':

    this.imageValues = this.image_names20;
    this.hideCaption(this.image_names20, this.imageToShow20);

    break;
   case 'image_area_21':

    this.imageValues = this.image_names21;
    this.hideCaption(this.image_names21, this.imageToShow21);
    break;
   case 'image_area_22':

    this.imageValues = this.image_names22;
    this.hideCaption(this.image_names22, this.imageToShow22);

    break;
   case 'image_area_23':

    this.imageValues = this.image_names23;
    this.hideCaption(this.image_names23, this.imageToShow23);
    break;
   case 'image_area_24':

    this.imageValues = this.image_names24;
    this.hideCaption(this.image_names24, this.imageToShow24);
    break;
   case 'image_area_25':

    this.imageValues = this.image_names25;
    this.hideCaption(this.image_names25, this.imageToShow25);

    break;
  }

let imageValue;

if(this.imageValues.length > 0) {
  this.parts.controls = [];
}

for(let k = 0; k < this.imageValues.length; k++) {
  imageValue = this.imageValues[k]

  if (this.parts.length > 0) {
    for (let k = 0; k < this.parts.length; k++) {

      let partValue = this.parts.at(k) ? this.parts.at(k).value.value.toString().trim() : null;
      let enteredValue = imageValue.toString().trim();
  
         if (partValue === enteredValue) {
          this.parts.at(k).get('position').setValue(positionCounter);
          newParts.push(this.parts.at(k));
          this.parts.removeAt(k);
          positionCounter++;
          break;
  
        } else if (partValue !== enteredValue && k == Number(this.parts.length - 1)) {
  
          newParts.push(this.createImageParts(enteredValue, positionCounter, type, null));
          positionCounter++;
          break;
        }
  
    }
  } else {
      newParts.push(this.createImageParts(imageValue, positionCounter, type, null));
      positionCounter++;
  }

}

if(this.imageValues.length > 0) { 
  while (this.parts.length) {
    this.parts.removeAt(0);
  }
  for (let part = 0; part < newParts.length; part++) {
    this.parts.push(newParts.at(part))
  }
}

}
createImageParts(value, position, type, partId): FormGroup {
  return new FormGroup({
    partId: new FormControl(partId),
    type: new FormControl(type),
    position: new FormControl(position),
    phraseId: new FormControl(''),
    value: new FormControl(value)
  })
}
unqiueNameForImage() {
  return "ss-s-s-ss".replace(/s/g, this.generateImageHash);
}
  
generateImageHash() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
}

  @Input('isImageUploaded') isImageUploaded: boolean;
onUploadFinished($event, id: string) {
 
   this.isImageUploaded = true;
 
  const files = $event.file;
  
  const fileName1 = this.unqiueNameForImage()+'_'+files.name.replace(/\s+/g,"");
  
  const fileName = fileName1.replace(" ", "");
  if (id == "1") {
    
    this.imageNameArray1 = this.first_image_names_from_rest_call;
    if(this.imageNameArray1.length > 5) {
      return;
    }
   
    this.imageNameArray1.push(fileName);
    this.image_names1=this.imageNameArray1;

  }
  else if (id == "2") {
    this.imageNameArray2 = this.second_image_names_from_rest_call;
    if(this.imageNameArray2.length > 5) {
      return;
    }
    this.imageNameArray2.push(fileName);
    this.image_names2=this.imageNameArray2;
  }
  else if (id == "3") {
    this.imageNameArray3 = this.third_image_names_from_rest_call;
    if(this.imageNameArray3.length > 5) {
      return;
    }
    this.imageNameArray3.push(fileName);
    this.image_names3=this.imageNameArray3;
  }
  else if (id == "4") {
    this.imageNameArray4 = this.fourth_image_names_from_rest_call;
    if(this.imageNameArray4.length > 5) {
      return;
    }
    this.imageNameArray4.push(fileName);
    this.image_names4=this.imageNameArray4;
  }
  else if (id == "5") {
    this.imageNameArray5 = this.fifth_image_names_from_rest_call;
    if(this.imageNameArray5.length > 5) {
      return;
    }
    this.imageNameArray5.push(fileName);
    this.image_names5=this.imageNameArray5;
  }
  else if (id == "6") {
    this.imageNameArray6 = this.sixth_image_names_from_rest_call;
    if(this.imageNameArray6.length > 5) {
      return;
    }
    this.imageNameArray6.push(fileName);
    this.image_names6=this.imageNameArray6;
  }
  else if (id == "7") {
    this.imageNameArray7 = this.seven_image_names_from_rest_call;
    if(this.imageNameArray7.length > 5) {
      return;
    }
    this.imageNameArray7.push(fileName);
    this.image_names7=this.imageNameArray7;
  }
  else if (id == "8") {
    this.imageNameArray8 = this.eight_image_names_from_rest_call;
    if(this.imageNameArray8.length > 5) {
      return;
    }
    this.imageNameArray8.push(fileName);
    this.image_names8=this.imageNameArray8;
  }
  else if (id == "9") {
    this.imageNameArray9 = this.nine_image_names_from_rest_call;
    if(this.imageNameArray9.length > 5) {
      return;
    }
    this.imageNameArray9.push(fileName);
    this.image_names9=this.imageNameArray9;
  }
  else if (id == "10") {
    this.imageNameArray10 = this.ten_image_names_from_rest_call;
    if(this.imageNameArray10.length > 5) {
      return;
    }
    this.imageNameArray10.push(fileName);
    this.image_names10=this.imageNameArray10;
  }
  else if (id == "11") {
    this.imageNameArray11 = this.eleven_image_names_from_rest_call;
    if(this.imageNameArray11.length > 5) {
      return;
    }
    this.imageNameArray11.push(fileName);
    this.image_names11=this.imageNameArray11;
  }
  else if (id == "12") {
    this.imageNameArray12 = this.twelve_image_names_from_rest_call;
    if(this.imageNameArray12.length > 5) {
      return;
    }
    this.imageNameArray12.push(fileName);
    this.image_names12=this.imageNameArray12;
  }
  else if (id == "13") {
    this.imageNameArray13 = this.thirteen_image_names_from_rest_call;
    if(this.imageNameArray13.length > 5) {
      return;
    }
    this.imageNameArray13.push(fileName);
    this.image_names13=this.imageNameArray13;
  }
  else if (id == "14") {
    this.imageNameArray14 = this.fourteen_image_names_from_rest_call;
    if(this.imageNameArray14.length > 5) {
      return;
    }
    this.imageNameArray14.push(fileName);
    this.image_names14=this.imageNameArray14;
  }
  else if (id == "15") {
    this.imageNameArray15 = this.fifteen_image_names_from_rest_call;
    if(this.imageNameArray15.length > 5) {
      return;
    }
    this.imageNameArray15.push(fileName);
    this.image_names15=this.imageNameArray15;
  }
  else if (id == "16") {
    this.imageNameArray16= this.sixteen_image_names_from_rest_call;
    if(this.imageNameArray16.length > 5) {
      return;
    }
    this.imageNameArray16.push(fileName);
    this.image_names16=this.imageNameArray16;
  }
  else if (id == "17") {
    this.imageNameArray17 = this.seventeen_image_names_from_rest_call;
    if(this.imageNameArray17.length > 5) {
      return;
    }
    this.imageNameArray17.push(fileName);
    this.image_names17=this.imageNameArray17;
  }
  else if (id == "18") {
    this.imageNameArray18 = this.eighteen_image_names_from_rest_call;
    if(this.imageNameArray18.length > 5) {
      return;
    }
    this.imageNameArray18.push(fileName);
    this.image_names18=this.imageNameArray18;
  }
  else if (id == "19") {
    this.imageNameArray19 = this.nineteen_image_names_from_rest_call;
    if(this.imageNameArray19.length > 5) {
      return;
    }
    this.imageNameArray19.push(fileName);
    this.image_names19=this.imageNameArray19;
  }
  else if (id == "20") {
    this.imageNameArray20 = this.twenty_image_names_from_rest_call;
    if(this.imageNameArray20.length > 5) {
      return;
    }
    this.imageNameArray20.push(fileName);
    this.image_names20=this.imageNameArray20;
  }
  else if (id == "21") {
    this.imageNameArray21 = this.twenty_one_image_names_from_rest_call;
    if(this.imageNameArray21.length > 5) {
      return;
    }
    this.imageNameArray21.push(fileName);
    this.image_names21=this.imageNameArray21;
  }
  else if (id == "22") {
    this.imageNameArray22 = this.twenty_two_image_names_from_rest_call;
    if(this.imageNameArray22.length > 5) {
      return;
    }
    this.imageNameArray22.push(fileName);
    this.image_names22=this.imageNameArray22;
  }
  else if (id == "23") {
    this.imageNameArray23 = this.twenty_three_image_names_from_rest_call;
    if(this.imageNameArray23.length > 5) {
      return;
    }
    this.imageNameArray23.push(fileName);
    this.image_names23=this.imageNameArray23;
  }
  else if (id == "24") {
    this.imageNameArray24 = this.twenty_four_image_names_from_rest_call;
    if(this.imageNameArray24.length > 5) {
      return;
    }
    this.imageNameArray24.push(fileName);
    this.image_names24=this.imageNameArray24;
  }
  else if (id == "25") {
    this.imageNameArray25 = this.twenty_five_image_names_from_rest_call;
    if(this.imageNameArray25.length > 5) {
      return;
    }
    this.imageNameArray25.push(fileName);
    this.image_names25=this.imageNameArray25;
  }
  this.image_name_counter = this.image_name_counter + 1;

      this.componentLevelBinaryData.push({
        file : files,
        id  : id,
        fileName: fileName
      });
 
//  this.infoSvc.persistImages(files, id,fileName).subscribe((data => {
//     this.image_name_counter = 0;
//   }));
}

closeImageArea(textarea) {
  let informations = (<FormArray>this.form.controls['informations']);
  let areas = informations.at(0).get('areas') as FormArray;

      for(let i = 0 ; i < areas.length ; i ++) {
        if(areas.at(i).get('imagearea_no').value == this.image_index) {
          areas.removeAt(i);
        }
      }
    
this.compInteraction.removeImageComponent(this.image_index);   
  
}


onRemoved($event, id: string) {
  const files = $event.file;
  const fileName1 = files.name.replace(" ","");
  const fileName = fileName1.replace(" ","");
  switch(id) {
    case '1':
    for(let n=0;n<this.imageNameArray1.length;n++){
      if(fileName == this.imageNameArray1[n].split('_')[1]){
        this.imageNameArray1.splice(n,1);
        break;
      }
    }

    break;
    case '2':
    for(let n=0;n<this.imageNameArray2.length;n++){
      if(fileName == this.imageNameArray2[n].split('_')[1]){
        this.imageNameArray2.splice(n,1);
        break;
      }
    }

    break;
    case '3':
    for(let n=0;n<this.imageNameArray3.length;n++){
      if(fileName == this.imageNameArray3[n].split('_')[1]){
        this.imageNameArray3.splice(n,1);
        break;
      }
    }

    break;
    case '4':
    for(let n=0;n<this.imageNameArray4.length;n++){
      if(fileName == this.imageNameArray4[n].split('_')[1]){
        this.imageNameArray4.splice(n,1);
        break;
      }
    }

    break;
    case '5':
    for(let n=0;n<this.imageNameArray5.length;n++){
      if(fileName == this.imageNameArray5[n].split('_')[1]){
        this.imageNameArray5.splice(n,1);
        break;
      }
    }

    break;
    case '6':
    for(let n=0;n<this.imageNameArray6.length;n++){
      if(fileName == this.imageNameArray6[n].split('_')[1]){
        this.imageNameArray6.splice(n,1);
        break;
      }
    }

    break;
    case '7':
    for(let n=0;n<this.imageNameArray7.length;n++){
      if(fileName == this.imageNameArray7[n].split('_')[1]){
        this.imageNameArray7.splice(n,1);
        break;
      }
    }

    break;
    case '8':
    for(let n=0;n<this.imageNameArray8.length;n++){
      if(fileName == this.imageNameArray8[n].split('_')[1]){
        this.imageNameArray8.splice(n,1);
        break;
      }
    }

    break;
    case '9':
    for(let n=0;n<this.imageNameArray9.length;n++){
      if(fileName == this.imageNameArray9[n].split('_')[1]){
        this.imageNameArray9.splice(n,1);
        break;
      }
    }

    break;
    case '10':
    for(let n=0;n<this.imageNameArray10.length;n++){
      if(fileName == this.imageNameArray10[n].split('_')[1]){
        this.imageNameArray10.splice(n,1);
        break;
      }
    }

    break;
    case '11':
    for(let n=0;n<this.imageNameArray11.length;n++){
      if(fileName == this.imageNameArray11[n].split('_')[1]){
        this.imageNameArray11.splice(n,1);
        break;
      }
    }

    break;
    case '12':
    for(let n=0;n<this.imageNameArray12.length;n++){
      if(fileName == this.imageNameArray12[n].split('_')[1]){
        this.imageNameArray12.splice(n,1);
        break;
      }
    }

    break;
    case '13':
    for(let n=0;n<this.imageNameArray13.length;n++){
      if(fileName == this.imageNameArray13[n].split('_')[1]){
        this.imageNameArray13.splice(n,1);
        break;
      }
    }

    break;
    case '14':
    for(let n=0;n<this.imageNameArray14.length;n++){
      if(fileName == this.imageNameArray14[n].split('_')[1]){
        this.imageNameArray14.splice(n,1);
        break;
      }
    }

    break;
    case '15':
    for(let n=0;n<this.imageNameArray15.length;n++){
      if(fileName == this.imageNameArray15[n].split('_')[1]){
        this.imageNameArray15.splice(n,1);
        break;
      }
    }

    break;
    case '16':
    for(let n=0;n<this.imageNameArray16.length;n++){
      if(fileName == this.imageNameArray16[n].split('_')[1]){
        this.imageNameArray16.splice(n,1);
        break;
      }
    }

    break;
    case '17':
    for(let n=0;n<this.imageNameArray17.length;n++){
      if(fileName == this.imageNameArray17[n].split('_')[1]){
        this.imageNameArray17.splice(n,1);
        break;
      }
    }

    break;
    case '18':
    for(let n=0;n<this.imageNameArray18.length;n++){
      if(fileName == this.imageNameArray18[n].split('_')[1]){
        this.imageNameArray18.splice(n,1);
        break;
      }
    }

    break;
    case '19':
    for(let n=0;n<this.imageNameArray19.length;n++){
      if(fileName == this.imageNameArray19[n].split('_')[1]){
        this.imageNameArray19.splice(n,1);
        break;
      }
    }

    break;
    case '20':
    for(let n=0;n<this.imageNameArray20.length;n++){
      if(fileName == this.imageNameArray20[n].split('_')[1]){
        this.imageNameArray20.splice(n,1);
        break;
      }
    }

    break;
    case '21':
    for(let n=0;n<this.imageNameArray21.length;n++){
      if(fileName == this.imageNameArray21[n].split('_')[1]){
        this.imageNameArray21.splice(n,1);
        break;
      }
    }

    break;
    case '22':
    for(let n=0;n<this.imageNameArray22.length;n++){
      if(fileName == this.imageNameArray22[n].split('_')[1]){
        this.imageNameArray22.splice(n,1);
        break;
      }
    }

    break;
    case '23':
    for(let n=0;n<this.imageNameArray23.length;n++){
      if(fileName == this.imageNameArray23[n].split('_')[1]){
        this.imageNameArray23.splice(n,1);
        break;
      }
    }

    break;
    case '24':
    for(let n=0;n<this.imageNameArray24.length;n++){
      if(fileName == this.imageNameArray24[n].split('_')[1]){
        this.imageNameArray24.splice(n,1);
        break;
      }
    }

    break;
    case '25':
    for(let n=0;n<this.imageNameArray25.length;n++){
      if(fileName == this.imageNameArray25[n].split('_')[1]){
        this.imageNameArray25.splice(n,1);
        break;
      }
    }

    break;
  }
 
  
}
  hideCaption(fromAngular, fromRest) {
   if (fromAngular.length == 0 && fromRest.length == 0) {
    this.disableCaption = false;
   } else {
    this.disableCaption = true;
   }
  }

  moveImageArea(index) {

    this.compInteraction.moveInformationBlocks(index,this._ref);

  }
 
  
 }