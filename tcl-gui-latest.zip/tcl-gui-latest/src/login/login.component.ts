import {Component, OnInit, OnDestroy, ViewChild, ElementRef} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import {Validators, FormControl, FormGroup, FormBuilder} from '@angular/forms';
import {LoginService} from './login.service';
import {LoginAuth} from './loginAuth';
import { map } from 'rxjs/operators';
import {Message} from 'primeng/components/common/api';
import {MessageService} from 'primeng/components/common/messageservice';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  providers: [ LoginService ,MessageService],
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    msgs: Message[] = [];
    loginform: FormGroup;
    authStr: string;
    arr : Array<string> = [];
    invalidUserDetails: boolean;
    invalidUserRoles: boolean;
    return: string = '';

    @ViewChild("Cancel", {read: ElementRef}) closeButton: ElementRef;
    
    @ViewChild("Login", {read: ElementRef}) loginButton: ElementRef;
    
    @ViewChild("login_Input", {read: ElementRef}) login_Input: ElementRef;

    constructor(private translate: TranslateService, private router: Router, private fb: FormBuilder,
    private loginService: LoginService, private route: ActivatedRoute,
    private messageService: MessageService) { }

    ngOnInit() {
        this.loginform = new FormGroup({
            'userName': new FormControl('', Validators.required),
            'password': new FormControl('', Validators.compose([Validators.required, Validators.minLength(6)]))
        })
        this.route.queryParams
      .subscribe(params => this.return = params['return'] || '/tcl');
          this.login_Input.nativeElement.focus();
    }

    onSubmit(userName, password) {
       this.validateAndGetUserLocale(userName, password);
    }

    validateFields(userName,password){
        if(userName && password){
            if(userName.length == 0 || password.length == 0){
                this.msgs = [];
                this.msgs.push({severity:'warn', summary:"nom d'utilisateur et mot de passe sont obligatoires"});
                this.closeButton.nativeElement.blur();
                this.loginButton.nativeElement.blur();
                this.login_Input.nativeElement.focus();
            }else{
                this.authenticateUsingGet(userName,password)
            }
        }else{
            this.msgs = [];
            this.msgs.push({severity:'warn', summary:"nom d'utilisateur et mot de passe sont obligatoires"});
            this.closeButton.nativeElement.blur();
            this.loginButton.nativeElement.blur();
            this.login_Input.nativeElement.focus();
        }
       

    }

    validateAndGetUserLocale(userName, password) {
        try {
            this.loginService.validateAndGetUserLocale(userName, password).toPromise().then(authStr => {
                this.authStr = authStr;
                if("invalid" === this.authStr){
                    this.loginform.reset();
                    console.log("invalid login");
                } else {
                    //this.translate.use(this.authStr);
                    this.router.navigateByUrl(this.return);
                    //this.router.navigate(['welcome']);
                    console.log("Successful call");
                }
            });
        } catch (e) {
            console.log(e);
        }
    }

   authenticateUsingGet(userName, password) {
        try {
            this.loginService.authenticateUsingGet(userName, password).subscribe(authStr => {
                this.authStr = authStr;
                this.arr = this.authStr.split("##");
                if("invalidUserDetails" == this.arr[1]) {
                    this.invalidUserDetails=true;
                    this.invalidUserRoles=false;
                    this.loginform.reset();
                    this.msgs = [];
                    this.msgs.push({severity:'warn', summary:"Le nom d'utilisateur ou le mot de passe sont invalides"});
                    this.closeButton.nativeElement.blur();
                    this.loginButton.nativeElement.blur();
                    this.login_Input.nativeElement.focus();
                    console.log("invalidUserDetails login");
                } else if("invalidUserRoles" == this.arr[1]){
                    this.invalidUserRoles=true;
                    this.invalidUserDetails=false;
                    this.loginform.reset();
                    this.msgs = [];
                    this.msgs.push({severity:'warn', summary:"Le nom d'utilisateur ou le mot de passe sont invalides"});
                    this.closeButton.nativeElement.blur();
                    this.loginButton.nativeElement.blur();
                    this.login_Input.nativeElement.focus();
                    console.log("invalidUserRoles login");
                } else {
                    if(this.arr[0]!= "null")
                        this.translate.use(this.arr[0].toLowerCase());
                    this.router.navigate(['tcl']);
                    console.log("Successful call");
                }
            });
        } catch (e) {
            console.log(e);
        }
    } 
  

    cancel() {
        this.msgs = [];
        this.loginform.reset();
        this.closeButton.nativeElement.blur();
        this.loginButton.nativeElement.blur();
        this.login_Input.nativeElement.focus();
    }

  
      
}
