import { HomePageAuthService } from './services/route-guard/home-page-auth.service';
import { HomePageComponent } from './home-page/home-page.component';
import { AppComponent } from './app.component';
import { Routes } from '@angular/router';
import { SessionTimeoutComponent } from './session-timeout/session-timeout.component';
import { NotfoundComponent } from './notfound/notfound.component';



export const appRoutes: Routes = [
   
     {path: '',  component:HomePageComponent, canActivate:[HomePageAuthService]},
     {path: 'home', component: HomePageComponent, canActivate:[HomePageAuthService]},
     {path: 'logout', component:SessionTimeoutComponent},
     {path: 'notFound', component:NotfoundComponent},
     {path: '**',  redirectTo: '/home', pathMatch: 'full' },
];
