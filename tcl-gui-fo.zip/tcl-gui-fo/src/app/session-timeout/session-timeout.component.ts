import { Component, OnInit } from '@angular/core';
import {MessageService} from 'primeng/api';


@Component({
  selector: 'app-session-timeout',
  templateUrl: './session-timeout.component.html',
  styleUrls: ['./session-timeout.component.scss']
})
export class SessionTimeoutComponent implements OnInit {

  constructor(private messageService: MessageService) {
    
   }

  ngOnInit() {
    this.messageService.clear();
        this.messageService.add(
          {key: 'c', sticky: true, severity:'warn', summary:'La session a expiré !', detail:"Vous êtes déconnecté de l'application"});
  }
  
}
