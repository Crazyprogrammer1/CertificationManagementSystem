export interface IAppConfig {
    apiUrl: string
}