import { HashLocationStrategy } from '@angular/common';
import { element } from 'protractor';
import { HeadersComponent } from './../headers/headers.component';
import { VinService } from './../services/vin/vin.service';
import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { Shared } from '../services/shared-resources/shared';
import { Observer, BehaviorSubject } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
  selector: 'vin-search',
  templateUrl: './vin-search.component.html',
  styleUrls: ['./vin-search.component.scss']
})
export class VinSearchComponent {
 

  vin_result:any = [];
  level1: Level[] = [];
  isError:boolean;
  selectedCountry:string=null;
  invalidVin: boolean;
  corvetDateDebutGarantieError: boolean;
  vehicleName: string;
  nre: string;
  isEmptyVin:boolean;
  @ViewChild('vin') vin;
  @ViewChild("country") dorpDown;
  constructor(
    private vin_service: VinService,
    public shared: Shared,
    private toastr: ToastrService,
    private elementRef: ElementRef,
    private spinner: NgxSpinnerService
  ){ 

  }

  searchVin(vin){

    if(!this.shared.selectedCountry.value){
      this.isError = true;
      this.toastr.info('Veuillez sélectionner un pays pour continuer !');
      this.dorpDown.applyFocus();
      
      return;
    }else if(vin.length == 0){
     this.isEmptyVin = true;
     this.toastr.info('vin est requis!');
     let element = this.vin.nativeElement;
     this.focusElement(element);

     return;
    }

    this.vin_result = [];
    this.shared.header_content.next([]);
    this.vehicleName = '';
    this.nre = '';
    this.shared.noInformationFound.next(false);
    this.shared.noTopicsFound.next(false);
    this.shared.accordion_Level1.next([]);
    this.invalidVin = false;
    this.corvetDateDebutGarantieError = false;
    this.spinner.show();

       this.vin_service.serarchVin(vin.trim(),this.shared.selectedCountry.value).subscribe(result => {
       this.invalidVin = false;
       this.corvetDateDebutGarantieError = false;
       this.shared.vin_Number.next(vin.trim());
       this.vin_result = result;

       if(this.tryParseJSON(this.vin_result)){
         return;
       }


     
       this.vin_service.getTopics(this.shared.selectedCountry.value.code).subscribe(topics => {
        for(let i =0; i < topics.length;i++){
              this.shared.CurrentHeaderContent({
                name:topics[i].topicNumber + " " + topics[i].title ,
                value: topics[i].id
              })
            }

            this.vehicleName = this.vin_result.vehicleName;
            this.nre = this.vin_result.nre;

            setTimeout(() => {
              /** spinner ends after 5 seconds */
              this.spinner.hide();
          }, 1);
          
       });
    },
    error => {
      setTimeout(() => {
        /** spinner ends after 5 seconds */
        this.spinner.hide();
    }, 1);

      this.shared.header_content.next([]);
      this.shared.accordion_Level1.next([]);
      if(error.error == 'VIN non concerné par le Contrôle Technique Périodique'){
        this.corvetDateDebutGarantieError = true;
        this.invalidVin = false;
      }else{
        this.invalidVin = true;
      }
      this.shared.vin_Number.next('');
      this.vehicleName = '';
      this.nre = '';
      let element = this.vin.nativeElement;
     this.focusElement(element);
    },
    () => {

    }
  );
    
   
  }

  changingVin(){
    this.invalidVin = false;
    this.corvetDateDebutGarantieError = false;
    this.isEmptyVin = false;
    this.toastr.clear();
  }
  selectCountry(){
    this.shared.selectedCountry.next(this.selectedCountry);
    this.isError = false;
    this.toastr.clear();
  }


  focusElement(element) {
    if (element && /INPUT|TEXTAREA/i.test(element.tagName)) {
      if ('selectionStart' in element) {
        element.selectionEnd = element.selectionStart;
      }
      element.blur();
    }

    if (window.getSelection) { // All browsers, except IE <=8
      window.getSelection().removeAllRanges();
    } else if (element.selection) { // IE <=8
      element.selection.empty();
    }
    element.focus();
  }

  tryParseJSON (jsonString){
    try {
        var o = JSON.parse(jsonString);
  
        if (o && typeof o === "object") {
            return o;
        }
    }
    catch (e) { }
  
    return false;
  }
  
}

interface Country {
  name: string;
  code: string;
}

interface Level {
  name: string;
  value: number;
}
