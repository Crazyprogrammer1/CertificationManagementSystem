import {ProgressSpinnerModule} from 'primeng/progressspinner';
import {
  Component,
  OnInit,
  ChangeDetectorRef,
  AfterViewInit,
  ViewChild,
  ElementRef,
  Renderer2
} from '@angular/core';
import {
  Shared
} from '../services/shared-resources/shared';
import {
  TopicService
} from '../services/topics/topic.service';
import {
  mergeMap,
  map,
  subscribeOn
} from 'rxjs/operators';
import {
  waitForMap
} from '@angular/router/src/utils/collection';
import {
  Accordion
} from 'primeng/accordion';
import {
  DomSanitizer,
  SafeUrl
} from '@angular/platform-browser';
import {
  ToastrService
} from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
  selector: 'informations',
  templateUrl: './informations.component.html',
  styleUrls: ['./informations.component.scss']
})
export class InformationsComponent {
  countries: Country[];
  selectedCountry: Country;
  offset = 100;
  level1: any[];
  selectedLevel1: Level;

  level3: Level[];
  selectedLevel3;
  informationLoading:boolean;
  foInformation: string = '';

  informationSummary: any[] = [];
  jsonObject: any = []
  index: number = 0;
  indices: number[] = [1, 2];
  blankSpace: string;
  @ViewChild('accordion') accordion: Accordion;
  breadcrumb: any = [];

  constructor(
    private chage_ref: ChangeDetectorRef,
    public shared: Shared,
    private topicService: TopicService,
    private cdRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService,
    private sanitizer: DomSanitizer
  ) {
    this.countries = [{
      name: 'Europe',
      code: 'EUR'
    }];
    this.blankSpace = " ";

  }

  closeDetails() {
    document.querySelector('#details').classList.toggle('is-open');
    document.querySelector('#main-list').classList.toggle('is-hidden');
    this.selectedLevel3 = null;
  }


  toggleDetails(event, Info ? ) {
    this.informationLoading= true;
    this.breadcrumb = [];

    this.shared.noInformationFound.next(false);
    document.getElementById("details").addEventListener("scroll", ($event) => {
      if (document.getElementById("details").scrollTop > 300) {
        document.getElementById("goTo").style.display = "block";
      } else {
        document.getElementById("goTo").style.display = "none";
      }

    });


    document.querySelector('#details').classList.toggle('is-open');
    document.querySelector('#main-list').classList.toggle('is-hidden');
    
    this.clearFields();

    this.topicService.serarchInformation(this.selectedLevel3)
      .subscribe(
        information => {
          this.foInformation = Info.foInformation;
          this.jsonObject = information;
          this.informationSummary = [];
          for (let i = 0; i < this.jsonObject.length; i++) {
            if (!this.informationSummary[i]) {
              this.informationSummary.push([]);
            }
          }

          for (let i = 0; i < this.jsonObject.length; i++) {
            for (let j = 0; j < this.jsonObject[i].areas.length; j++) {
              if (
                this.jsonObject[i].areas[j].type == 'textarea' ||
                this.jsonObject[i].areas[j].type == 'docref'
              ) {
                for (let k = 0; k < this.jsonObject[i].areas[j].values.length; k++) {
                  this.informationSummary[i].push({
                    type: this.jsonObject[i].areas[j].type,
                    value: this.jsonObject[i].areas[j].values[k].value
                  })
                }
              } else if (this.jsonObject[i].areas[j].type == 'imagearea') {
                for (let k = 0; k < this.jsonObject[i].areas[j].values.length; k++) {
                  this.informationSummary[i].push({
                    type: this.jsonObject[i].areas[j].type,
                    value: [this.jsonObject[i].areas[j].values[k].value],
                    image: []
                  })
                }
              }
            }
          }


          if (this.accordion.tabs) {
            for (let tab of this.accordion.tabs) {

              if (tab.selected) {
                this.breadcrumb.push(tab.header);
              }
            }
            this.breadcrumb.push(event.target.innerText);
          }

       
          this.shared.noInformationFound.next(false);


          for (let i = 0; i < this.informationSummary.length; i++) {
            for (let k = 0; k < this.informationSummary[i].length; k++) {
              if (this.informationSummary[i][k].type == 'imagearea') {
                this.prepareImages(this.informationSummary[i][k].value, k, i)
              }
            }
          }

          if(information.length ==0) {
          this.shared.noInformationFound.next(true);
          this.informationLoading = false;
          this.selectedLevel3 = null;
          document.querySelector('#details').classList.toggle('is-open');
          document.querySelector('#main-list').classList.toggle('is-hidden');
          }

        },
        error => {
          this.shared.noInformationFound.next(true);
          this.informationLoading = false;
          this.selectedLevel3 = null;
          document.querySelector('#details').classList.toggle('is-open');
          document.querySelector('#main-list').classList.toggle('is-hidden');
        },

        () => {
          this.informationLoading = false;
          this.selectedLevel3 = null;
          this.shared.noInformationFound.next(false);
        }


      )


  }

  prepareImages(parts, position, summaryPosition) {
    for (let i = 0; i < parts.length; i++) {
      let imageParts = parts[i];
      let partNumbers = imageParts.split(',');

      for (let j = 0; j < partNumbers.length; j++) {

        this.topicService.serachImage(partNumbers[j]).toPromise().then(image => {
            this.createImageFromBlob(image, position, summaryPosition);
          },
          error => {
            console.log('No Image is found');
          }
        )
      }


    }
  }


  createImageFromBlob(image: Blob, position, summaryPosition) {

    let ob = window.URL || (window as any).webkitURL;
    var url = ob.createObjectURL(image);
    let SafeUrl = this.sanitizer.bypassSecurityTrustUrl(url);
    this.informationSummary[summaryPosition][position].image.push(SafeUrl)

  }

  goToTop() {
    document.querySelector('#details').scrollTop = 0;
  }


  getOptions(event, requireSpace ? : any) {
    if (!event) {
      return;
    }
    if (requireSpace == 'smallSpace') {
      let space = '        ';
      return new Array({
        label: space + event.topicNumber + ' ' + event.title + '.',
        value: event.id
      })
    }
    if (requireSpace == true) {
      let space = '        ';
      return new Array({
        label: space + event.topicNumber + ' ' + event.title + '.',
        value: event.id
      })
    }
    return new Array({
      label: event.topicNumber + ' ' + event.title + '.',
      value: event.id
    })

  }

  clearFields() {

    for (let i = 0; i < this.informationSummary.length; i++) {
      this.informationSummary[i] = [];

    }
    this.jsonObject = [];

  }
}

interface Country {
  name: string;
  code: string;
}

interface Level {
  name: string;
  value: number;
}
