import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { environment } from '../environments/environment';
import { IAppConfig } from '../app/model/app-config.model';

@Injectable()
export class AppConfig {

    static settings: IAppConfig;

    constructor(private http: Http) {}

    load(url:string) {
        return new Promise<void>((resolve, reject) => {
            this.http.get(url).toPromise().then((response : Response) => {
               AppConfig.settings = <IAppConfig>response.json();
               resolve();
            }).catch((response: any) => {
               reject(`Could not load file '${url}': ${JSON.stringify(response)}`);
            });
        });
    }

    getAppConfig():IAppConfig{
        return AppConfig.settings;
    }
}