import { MessageService } from 'primeng/api';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Location } from '@angular/common';
import { UrlDecodeService } from './services/url-decoder/url-decode.service';
import { Shared } from './services/shared-resources/shared';
import * as moment from 'moment';
import { VinService } from './services/vin/vin.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  private encrypted_data:string;

  constructor(
    private router:Router,
    private activatedRoute: ActivatedRoute,
    private _location:Location,
    private messageService:MessageService,
    private urlDecoder : UrlDecodeService,
    private shared: Shared,
    private vin_service: VinService
  ){
    localStorage.setItem('lastAction',Date.now().toString());
  }
  onReject(){}
  ngOnInit(){
  
   this.encrypted_data = decodeURIComponent(window.location.search).replace('?','');
  
   this.vin_service.getDataCollections().subscribe(dc => {
    dc.forEach(element => {
      this.shared.countries.value.push({
        name:element.title,
        code:element.id,
      })
    });
  });

   this.urlDecoder.decodeURL(this.encrypted_data).subscribe(data => {
    this.shared.decodedURL.next({
      language:data.language,
      country:data.country,
      userId:data.userId,
      loggedInDate:data.loggedInDate
    });
   },
   error => {
    localStorage.clear();
    this.router.navigate(['./notFound']);
   }
  );


  }

  onConfirm(){
    this.messageService.clear();
  }
}
