import { TestBed } from '@angular/core/testing';

import { HomePageAuthService } from './home-page-auth.service';

describe('HomePageAuthService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HomePageAuthService = TestBed.get(HomePageAuthService);
    expect(service).toBeTruthy();
  });
});
