import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

const STORE_KEY =  'lastAction';
@Injectable({
  providedIn: 'root'
})
export class HomePageAuthService implements CanActivate {

  constructor(private router:Router) { }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
 
  let  isUserAuthenticated = localStorage.getItem(STORE_KEY) ? true : false;

  if (isUserAuthenticated) {
        return true;
   } else{
    this.router.navigate(['./logout']);
    return false;
   }
     
  }
}
