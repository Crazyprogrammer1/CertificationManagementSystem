import {Injectable} from '@angular/core';
import {Observable,BehaviorSubject} from 'rxjs'; 

@Injectable()
export class Shared{

    selectedCountry = new BehaviorSubject(null);
    header_content = new BehaviorSubject([]);
    countries = new BehaviorSubject([]);


      get currentHeaderContent()
      {
          return this.header_content;
      }
        CurrentHeaderContent(val){
          this.header_content.value.push(val);
      }
   
    decodedURL =  new BehaviorSubject({
        language:'',
        country:'',
        userId:'',
        loggedInDate:''
    });

    get currentdecodedURL()
    {
        return this.decodedURL;
    }
      CurrentdecodedURL(val){
        this.decodedURL.next(val);
    }
      
    accordionHeader = new BehaviorSubject({});

    get currentaccordionHeader()
    {
        return this.accordionHeader;
    }
      CurrentAccordionHeader(val){
        this.accordionHeader.next(val);
    }

    accordion_Level1 = new BehaviorSubject([]);

    get currentaccordionLevel1()
    {
        return this.accordion_Level1;
    }
      CurrentAccordionLevel1(val){
        this.accordion_Level1.value.push(val);
    }

    vin_Number = new BehaviorSubject('');

    noInformationFound = new BehaviorSubject(false);

    noTopicsFound = new BehaviorSubject(false);
}