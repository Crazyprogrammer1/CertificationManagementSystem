
import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import { AppConfig } from '../../app.config';
import { Shared } from '../shared-resources/shared';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class TopicService {

  constructor(private http: HttpClient,private shared:Shared) { }

  serarchTopics(id: number){
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/collections/accordion?id='+id
    +'&vin='+this.shared.vin_Number.getValue()
    +'&language='+this.shared.decodedURL.getValue().language+'_'+this.shared.decodedURL.getValue().country
    +'&collectionId='+this.shared.selectedCountry.getValue().code;
     return this.http.get(url);
   
  }

  serarchInformation(id: number):Observable<any>{
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/informations?topicId='+id
    +'&vin='+this.shared.vin_Number.getValue()
    +'&language='+this.shared.decodedURL.getValue().language+'_'+this.shared.decodedURL.getValue().country
     return this.http.get(url);   
  }

  serachImage(partid : number){
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/search/image?id='+partid;
     return this.http.get(url , {responseType: 'blob' });
  }

}

