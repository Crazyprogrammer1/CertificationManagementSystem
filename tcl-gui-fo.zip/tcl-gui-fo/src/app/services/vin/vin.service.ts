import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import { AppConfig } from '../../app.config';
import { Shared } from '../shared-resources/shared';
import { mergeMap, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class VinService {

  constructor(private http: HttpClient,private shared: Shared) { }
 

  getDataCollections():Observable<any> {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/datacollection/distinctdatacollection';
    return this.http.get(url);
  }

  serarchVin(vin: string,country){
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain +
     '/vins/'+vin
      +'?language='+ this.shared.decodedURL.getValue().language+'_'+this.shared.decodedURL.getValue().country
      +'&userId='+ this.shared.decodedURL.getValue().userId
      +'&company=capgemini'
      + '&collectionId='+country.code;
     let data = {};
     return this.http.post(url,data);
  }

  getTopics(collectionId):Observable<any>{
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + `/collections/${collectionId}/topics?language=${this.shared.decodedURL.getValue().language}_${this.shared.decodedURL.getValue().country}`;
    let data = {};
    return this.http.post(url,data);
  }
}


