import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import { AppConfig } from '../../app.config';
import { from } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UrlDecodeService {

  constructor(private http: HttpClient) { }

  decodeURL(encryptedUrl: string){
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/urlDecode/'+encryptedUrl;
    return this.http.get(url).pipe(
      map((data) => new VinData(data))
    )
   }
}

  export class VinData {

    constructor(data){
      this.language = data.language;
      this.country = data.country;
      this.userId = data.userId;
      this.loggedInDate = data.loggedInDate;
    }

    language:string;
    country:string;
    userId:string;
    loggedInDate:string;
  }
