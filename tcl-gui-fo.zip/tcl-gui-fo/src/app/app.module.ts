import { isVisible } from 'ng-lazyload-image/src/scroll-preset/preset';
import { HomePageAuthService } from './services/route-guard/home-page-auth.service';
import { Shared } from './services/shared-resources/shared';
import { Http, ConnectionBackend, RequestOptions, HttpModule } from '@angular/http';
import { appRoutes } from './route';
import { RouterModule, Router } from '@angular/router';
import { environment } from './../environments/environment';
import { AppConfig } from './app.config';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import { VinService } from './services/vin/vin.service';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {GoTopButtonModule} from 'ng2-go-top-button';
import { NgModule, APP_INITIALIZER, ChangeDetectorRef } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TabViewModule } from 'primeng/tabview';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { DropdownModule } from 'primeng/dropdown';
import { AccordionModule } from 'primeng/accordion';
import { ListboxModule } from 'primeng/listbox';
import { VinSearchComponent } from './vin-search/vin-search.component';
import { HeadersComponent } from './headers/headers.component';
import { InformationsComponent } from './informations/informations.component';
import { TopMenuComponent } from './top-menu/top-menu.component';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { AutoLogoutService } from './services/auto-logout/auto-logout.service';
import { AutoLogoutComponent } from './auto-logout/auto-logout.component';
import { SessionTimeoutComponent } from './session-timeout/session-timeout.component';
import { HomePageComponent } from './home-page/home-page.component';
import {ToastModule} from 'primeng/toast';
import {MessageService, ConfirmationService} from 'primeng/api';
import {UrlSerializer} from '@angular/router';
import { CustomUrlSerializer } from './services/custom-url-serializer/custom-url-serializer';
import { TopicService } from './services/topics/topic.service';
import { UrlDecodeService } from './services/url-decoder/url-decode.service';
import { LazyLoadImageModule , intersectionObserverPreset} from 'ng-lazyload-image';
import { ToastrModule } from 'ngx-toastr';
import { NotfoundComponent } from './notfound/notfound.component';
import { SanitizePipe } from './informations/sanitize.pipe';


export function initializeApp(appConfig: AppConfig) {
  return () => appConfig.load(environment.configFile);
}

@NgModule({
  declarations: [
        AppComponent,
        VinSearchComponent,
        HeadersComponent,
        InformationsComponent,
        TopMenuComponent,
        AutoLogoutComponent,
        SessionTimeoutComponent,
        HomePageComponent,
        NotfoundComponent,
        SanitizePipe
      ],
  imports: [
    BrowserModule,
    ProgressSpinnerModule,
    BrowserAnimationsModule,
    GoTopButtonModule,
    NgxSpinnerModule,
    ToastrModule.forRoot({
      preventDuplicates: true,
      timeOut: 5000,
      positionClass: 'toast-top-left',
      closeButton: true
    }),
    FormsModule,
    ButtonModule,
    AccordionModule,
    AppRoutingModule,
    LazyLoadImageModule.forRoot({
      preset: intersectionObserverPreset
    }),
    ToastModule,
    TabViewModule,
    InputTextModule,
    DropdownModule,
    ListboxModule,
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    HttpClientModule,
    ButtonModule,
    HttpModule,
    AccordionModule,
    TabViewModule,
    InputTextModule,
    DropdownModule,
    ListboxModule,
    GoTopButtonModule
  ],
  providers: [VinService,UrlDecodeService,
    MessageService,ConfirmationService,
    HttpClient,HeadersComponent,Shared,AutoLogoutService,HomePageAuthService,TopicService, 
  { provide: UrlSerializer, useClass: CustomUrlSerializer },
  AppConfig,
  { provide: APP_INITIALIZER,
    useFactory: initializeApp,
    deps: [AppConfig], multi: true 
   }
],
  bootstrap: [AppComponent],
})
export class AppModule {
 
}


