import { Shared } from './../services/shared-resources/shared';
import { Component, OnInit } from '@angular/core';
import { TopicService } from '../services/topics/topic.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'headers',
  templateUrl: './headers.component.html',
  styleUrls: ['./headers.component.scss']
})
export class HeadersComponent {

  selectedHeader: Level;
  topics_result:any = [];
  constructor(
    public shared:Shared,
    private topicService:TopicService
  ) {
   
  }


  populateTopics(){
   this.topics_result = [];
    this.shared.noInformationFound.next(false);
   this.shared.accordion_Level1.next([]);
   

    this.topicService.serarchTopics(this.selectedHeader.value).subscribe(
      data => {
          this.topics_result = data;
            if(!this.tryParseJSON(this.topics_result) && this.topics_result.length > 0){
              this.shared.noTopicsFound.next(false);
              this.shared.accordion_Level1.next(this.topics_result);
            }else {
              this.shared.noTopicsFound.next(true);
            }
      
          },
          error => {
              this.shared.noTopicsFound.next(true);
          }

);

}

tryParseJSON (jsonString){
  try {
      var o = JSON.parse(jsonString);

      if (o && typeof o === "object") {
          return o;
      }
  }
  catch (e) { }

  return false;
}
}

interface Level {
  name: string;
  value: number;
}

