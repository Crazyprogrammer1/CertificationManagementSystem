import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImageareaComponent } from './imagearea.component';

describe('ImageareaComponent', () => {
  let component: ImageareaComponent;
  let fixture: ComponentFixture<ImageareaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImageareaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImageareaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
