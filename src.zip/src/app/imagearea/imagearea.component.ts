import { ImageService } from './../image-upload/image.service';
import { ImageUploadComponent } from './../image-upload/image-upload.component';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';
import { TopicComponent } from './../topic/topic.component';
import { Component, OnInit, Input, OnChanges, forwardRef  ,Inject, OnDestroy} from '@angular/core';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { AfterViewInit, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { MessageService } from 'primeng/api';
import { FormBuilder, FormGroup, FormArray, FormControl, FormControlName } from '@angular/forms';
import { InformationService } from '../service/information/information.service';
import { ComponentRef, ComponentFactoryResolver, ViewContainerRef} from "@angular/core";
import { InformationImageService } from '../service/Image/image.service';

@Component({
  selector: 'app-imagearea',
  templateUrl: './imagearea.component.html',
  styleUrls: ['./imagearea.component.css']
})
export class ImageareaComponent implements OnInit  {
  compInteraction : any;
  _ref : any;
  parts: FormArray;
  areaAccessIndex:number;

  @Input('ImageBinaryData') ImageBinaryData;
  @Input('ImagesToBedeleted') ImagesToBedeleted;
  @Input('isImageUploaded') isImageUploaded: boolean;
  componentLevelBinaryData:any[] = [];
  componentLevelImages:any[] =[];

  @ViewChild(ImageUploadComponent) img_upload_comp;

  @Input('fileCounter')fileCounter;

  @Input('disableCaption') disableCaption: boolean;
  @Input('image_index') image_index;
  @Input('form') form : FormGroup;
  @ViewChild(ImageUploadComponent) image_upload_component;

  @Input('imageNamesFromServer') imageNamesFromServer;

  @Input('first_image_names_from_rest_call') first_image_names_from_rest_call;
  @Input('second_image_names_from_rest_call') second_image_names_from_rest_call;
  @Input('third_image_names_from_rest_call') third_image_names_from_rest_call;
  @Input('fourth_image_names_from_rest_call') fourth_image_names_from_rest_call;
  @Input('fifth_image_names_from_rest_call') fifth_image_names_from_rest_call;
  @Input('sixth_image_names_from_rest_call') sixth_image_names_from_rest_call;
  @Input('seven_image_names_from_rest_call') seven_image_names_from_rest_call;
  @Input('eight_image_names_from_rest_call') eight_image_names_from_rest_call;
  @Input('nine_image_names_from_rest_call') nine_image_names_from_rest_call;
  @Input('ten_image_names_from_rest_call') ten_image_names_from_rest_call;
  @Input('eleven_image_names_from_rest_call') eleven_image_names_from_rest_call;
  @Input('twelve_image_names_from_rest_call') twelve_image_names_from_rest_call;
  @Input('thirteen_image_names_from_rest_call') thirteen_image_names_from_rest_call;
  @Input('fourteen_image_names_from_rest_call') fourteen_image_names_from_rest_call;
  @Input('fifteen_image_names_from_rest_call') fifteen_image_names_from_rest_call;
  @Input('sixteen_image_names_from_rest_call') sixteen_image_names_from_rest_call;
  @Input('seventeen_image_names_from_rest_call') seventeen_image_names_from_rest_call;
  @Input('eighteen_image_names_from_rest_call') eighteen_image_names_from_rest_call;
  @Input('nineteen_image_names_from_rest_call') nineteen_image_names_from_rest_call;
  @Input('twenty_image_names_from_rest_call') twenty_image_names_from_rest_call;
  @Input('twenty_one_image_names_from_rest_call') twenty_one_image_names_from_rest_call;
  @Input('twenty_two_image_names_from_rest_call') twenty_two_image_names_from_rest_call;
  @Input('twenty_three_image_names_from_rest_call') twenty_three_image_names_from_rest_call;
  @Input('twenty_four_image_names_from_rest_call') twenty_four_image_names_from_rest_call;
  @Input('twenty_five_image_names_from_rest_call') twenty_five_image_names_from_rest_call;

  @Input('imageToShow') imageToShow: any[];
  




  @Input('imageNameArray') imageNameArray;

  @Input('imageNameArray1') imageNameArray1;
  @Input('imageNameArray2') imageNameArray2;
  @Input('imageNameArray3') imageNameArray3;
  @Input('imageNameArray4') imageNameArray4;
  @Input('imageNameArray5') imageNameArray5;
  @Input('imageNameArray6') imageNameArray6;
  @Input('imageNameArray7') imageNameArray7;
  @Input('imageNameArray8') imageNameArray8;
  @Input('imageNameArray9') imageNameArray9;
  @Input('imageNameArray10') imageNameArray10;
  @Input('imageNameArray11') imageNameArray11;
  @Input('imageNameArray12') imageNameArray12;
  @Input('imageNameArray13') imageNameArray13;
  @Input('imageNameArray14') imageNameArray14;
  @Input('imageNameArray15') imageNameArray15;
  @Input('imageNameArray16') imageNameArray16;
  @Input('imageNameArray17') imageNameArray17;
  @Input('imageNameArray18') imageNameArray18;
  @Input('imageNameArray19') imageNameArray19;
  @Input('imageNameArray20') imageNameArray20;
  @Input('imageNameArray21') imageNameArray21;
  @Input('imageNameArray22') imageNameArray22;
  @Input('imageNameArray23') imageNameArray23;
  @Input('imageNameArray24') imageNameArray24;
  @Input('imageNameArray25') imageNameArray25;



  image_name_counter: number = 0;
  
  @Input('imageNames')  imageNames: any[] = [];

  @Input('image_names1')  image_names1: string[] = [];
  @Input('image_names2')  image_names2: string[] = [];
  @Input('image_names3')  image_names3: string[] = [];
  @Input('image_names4')  image_names4: string[] = [];
  @Input('image_names5')  image_names5: string[] = [];
  @Input('image_names6')  image_names6: string[] = [];
  @Input('image_names7')  image_names7: string[] = [];
  @Input('image_names8')  image_names8: string[] = [];
  @Input('image_names9')  image_names9: string[] = [];
  @Input('image_names10') image_names10: string[] = [];
  @Input('image_names11') image_names11: string[] = [];
  @Input('image_names12') image_names12: string[] = [];
  @Input('image_names13') image_names13: string[] = [];
  @Input('image_names14') image_names14: string[] = [];
  @Input('image_names15') image_names15: string[] = [];
  @Input('image_names16') image_names16: string[] = [];
  @Input('image_names17') image_names17: string[] = [];
  @Input('image_names18') image_names18: string[] = [];
  @Input('image_names19') image_names19: string[] = [];
  @Input('image_names20') image_names20: string[] = [];
  @Input('image_names21') image_names21: string[] = [];
  @Input('image_names22') image_names22: string[] = [];
  @Input('image_names23') image_names23: string[] = [];
  @Input('image_names24') image_names24: string[] = [];
  @Input('image_names25') image_names25: string[] = [];
  

  parts_array1: any[] = [];
  parts_array2: any[] = [];

  fileUploaded: boolean;
  showCloseButton: boolean = false;
  @Input('isImageAreaEditable') isImageAreaEditable: boolean;
  @Input('isImageAreaDisabled') isImageAreaDisabled: boolean;

constructor(

  private CFR: ComponentFactoryResolver,
  @Inject(ElementRef) elementRef: ElementRef,
  private formBuilder: FormBuilder,
  private messageService: MessageService,
  private renderer2: Renderer2,
  private imageservice: ImageService,
  private infoSvc: InformationService,
  private imageService: InformationImageService
) {
  this.areaAccessIndex = this.image_index - 1;
  this.fileUploaded = this.imageservice.getFileUploaded();
}

ngOnInit(){
  
  this.areaAccessIndex = this.image_index - 1;
}

get imageCloseButton() {
  return this.showCloseButton;
}

getImageAreaDisabled() {
  return this.isImageAreaDisabled;
}

get isImageEditable() {
  return this.isImageAreaEditable;
}

 editImageArea() {

   this.disableCaption = false;
   this.isImageAreaDisabled = false;
   this.isImageAreaEditable = true;
   this.showCloseButton = true;

}

drop(event: CdkDragDrop<string[]>) {
  moveItemInArray(this.imageToShow[this.image_index], event.previousIndex, event.currentIndex);
}

  disableImageEdit() {

    this.isImageAreaDisabled = true;
    this.isImageAreaEditable = false;
    this.showCloseButton = false;

}

  get imageIndexAsString() {
    return this.image_index.toString();
  }

  deleteImage(fileName: String, imagearea: String) {
    let informations = (<FormArray>this.form.controls['informations']);
    this.img_upload_comp.fileCounter--;

    let areas = informations.at(0).get('areas') as FormArray;

    this.processDeletionOfImages(fileName,this.imageNamesFromServer[this.image_index],  this.imageToShow[this.image_index]);

    for(let i = 0 ; i < areas.length ; i++) {
      if(areas.at(i).get('imagearea_no').value == imagearea) {
        let parts = areas.at(i).get('parts') as FormArray;
        for(let j = 0 ; j <parts.length ; j++) {
          if(parts.at(j).value.value == fileName)
                parts.removeAt(j);
                
          }

      }
    }
}
processDeletionOfImages(fileName ,imagenames, imagetoshow ) {

  for(let n=0;n<imagenames.length;n++){
    if(fileName == imagenames[n]){
      imagenames.splice(n,1);
      break;
    }
  }

  for(let i = 0 ; i < imagetoshow.length;i++) {
    if(fileName == imagetoshow[i][1]){
      imagetoshow.splice(i,1);
      break;
    }
  }

  this.componentLevelImages.push(
    {
      fileName : fileName
    }
  );
}

imageValues : any[] = [];

addnewImagePart() {
  this.parts_array2 = [];
  this.parts_array1 = [];
  let informations = ( < FormArray > this.form.controls['informations']);
  let areas = informations.at(0).get('areas') as FormArray;
  let type = 'image';
  let partId = 1;
  this.imageValues = [];
 
  this.ImagesToBedeleted.push(...this.componentLevelImages);
  this.ImageBinaryData.push(...this.componentLevelBinaryData)

  for (let  i  =  0 ;  i  <  areas.length ;  i ++) {
   if (areas.at(i).get('imagearea_no').value  ==  this.image_index) {
    this.parts  =  areas.at(i).get('parts')  as  FormArray;
   }
  }
  this.parts.controls = [];
  this.imageValues = this.imageNames[this.image_index];

  this.hideCaption(
    this.imageNames[this.image_index], 
    this.imageToShow[this.image_index]
   );

  for (let i = 0; i < this.imageValues.length; i++) {
   if (this.parts)
    this.parts.push(this.createImageParts(this.imageValues, i, type, partId));
  }
 
 }

createImageParts(value, index, type, partId): FormGroup {
  return new FormGroup({
    partId: new FormControl(partId),
    type: new FormControl(type),
    position: new FormControl(index == 0 ? index + 1 : index),
    phraseId: new FormControl(''),
    value: new FormControl(value[index])
  })
}

unqiueNameForImage() {
  return "ss-s-s-ss".replace(/s/g, this.generateImageHash);
}
  
generateImageHash() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
}



onUploadFinished($event, id: string) {
 
  this.isImageUploaded = true;
 
  const files = $event.file;
  
  const fileName = this.unqiueNameForImage()+'_'+files.name.replace(/\s+/g,"");
  

  this.imageNameArray[this.image_index] = this.imageNamesFromServer[this.image_index]
  if(this.imageNameArray[this.image_index].length > 5) {
    return;
  }
  this.imageNameArray[this.image_index].push(fileName);
  this.imageNames[this.image_index] = this.imageNameArray[this.image_index];

  this.image_name_counter = this.image_name_counter + 1;

      this.componentLevelBinaryData.push({
        file : files,
        id  : id,
        fileName: fileName
      });

}

closeImageArea() {
  let informations = (<FormArray>this.form.controls['informations']);
  let areas = informations.at(0).get('areas') as FormArray;

      for(let i = 0 ; i < areas.length ; i ++) {
        if(areas.at(i).get('imagearea_no').value == this.image_index) {
          areas.removeAt(i);
        }
   }
    
  this.compInteraction.removeImageComponent(this.image_index);   
  
}


onRemoved(event) {
  const files = event.file;
  const fileName = files.name.replace(/\s+/g,"");

  for(let n = 0; n < this.imageNameArray[this.image_index].length ; n++){

    if(fileName == this.imageNameArray[this.image_index][n].split('_')[1]){
      this.imageNameArray[this.image_index].splice(n,1);
      break;
    }

  }

  
}
  hideCaption(fromAngular, fromRest) {
   if (fromAngular.length == 0 && fromRest.length == 0) {
    this.disableCaption = false;
   } else {
    this.disableCaption = true;
   }
  }

  moveImageArea(index) {
    this.compInteraction.moveInformationBlocks(index,this._ref);
  }

  get imageAreaName(){
    return 'image_area_'+this.image_index;
  }
 
  
 }