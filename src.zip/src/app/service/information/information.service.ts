import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Location } from '@angular/common';
import 'rxjs/add/operator/map';
import { RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { AppConfig } from '../../app.config';

@Injectable({
  providedIn: 'root'
})
export class InformationService  {

  res : Response;
  constructor(private http: HttpClient, private location: Location) { 
  }



  getParametersByType(type: string) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/parameters/VEHICULES';
    return this.http.get(url);
  }
  getParametersBySeparator(type: string) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/parameters/separators';
    return this.http.get(url);
  }
  

  persistImages(file, id: string,fileName:string) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/informations/upload';
    let files = new FormData();

    files.append('files',file);
    files.append('partId',id);
    files.append('fileName',fileName);
    return this.http.post(url, files).map((response : Response) => {
    });
  }

  getImage(partId: string, filename: string): Observable<Blob> {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/informations/images?partId='+partId+'&filename='+filename;
    return this.http.get(url, {responseType: 'blob' });
  }

  getInformationsById(informationId: string) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/informations/' + informationId;
    return this.http.get(url);
  }

  deleteInformation(informationId: number) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/informations/' + informationId;
    return this.http.delete(url).map((response : Response) => {
    });
  }
}
