import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Location } from '@angular/common';
import 'rxjs/add/operator/map';
import { RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { AppConfig } from '../../app.config';

@Injectable({
  providedIn: 'root'
})
export class InformationImageService {

  constructor(private http: HttpClient, private location: Location) { }

  deleteImage(filename: string) {
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + `/informations/deleteImage/${filename}`;
    return this.http.delete(url);
  }
}
