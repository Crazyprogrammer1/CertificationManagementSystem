import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { AppConfig } from '../../app.config';
@Injectable({
  providedIn: 'root'
})
export class ApplicabilityService {

  constructor(private http: HttpClient, private location: Location) { }

  getData(type:string){
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/parameters/' + type;
    return this.http.get(url);
  }
  
  getLcdvCode(type:string,vehicleCode:string){
    let domain = location.protocol + '//' + AppConfig.settings.apiUrl;
    let url = domain + '/informations/lcdvCodes?lcdvnatureCode=' + type +'&vehicleCode=' + vehicleCode;
    return this.http.get(url);
  }
}
