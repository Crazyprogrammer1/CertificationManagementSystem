import { Routes } from '@angular/router';

import { LoginComponent } from './../login/login.component';
import { WelcomeComponent } from './../welcome/welcome.component';
import { SaisieComponent } from './saisie/saisie.component';
import { AdministrationComponent } from './administration/administration.component';
import { ExtractionComponent } from './extraction/extraction.component';
import { TopicComponent } from './topic/topic.component';
import { AuthGuardService } from './auth/auth-guard.service';

export const appRoutes: Routes = [
    {path: '',  redirectTo: '/login', pathMatch: 'full' },
    
    {path: 'login', component: LoginComponent},
    {
        path: 'tcl',
        component: WelcomeComponent,
        children: [
            {path: 'saisie',  component: SaisieComponent, canActivate:[AuthGuardService]},
            {path: 'administration',  component: AdministrationComponent, canActivate:[AuthGuardService]},
            {path: 'extraction',  component: ExtractionComponent, canActivate:[AuthGuardService]},
            {path: 'topic/:stringToSubmit',  component: TopicComponent, canActivate:[AuthGuardService]},
        ]
    },
    {path: '**',  redirectTo: '/login', pathMatch: 'full' },
];
