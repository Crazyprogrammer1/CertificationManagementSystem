import { Component, OnInit, Input,  Inject } from '@angular/core';
import { ElementRef } from'@angular/core'; 
import { FormGroup, FormArray, FormControl } from '@angular/forms'; 
import { NgxSmartModalService } from 'ngx-smart-modal'; 

@Component({
  selector: 'topic-textarea',
  templateUrl: './textarea.component.html',
  styleUrls: ['./textarea.component.css']
})
export class TextareaComponent implements OnInit{
  nsm;
  dialog;
  animation;
  rtl;

  elementRef: ElementRef;
  private selectedText: string;
  separators: string[] = ['.', ':', '\n', ';', '-'];
  valueAccessIndex: number;
  _ref: any;
  displayDocSoa: boolean = false;
  public compInteraction;
  public parts = new FormArray([]);
  max_text_cloning_reached: boolean;
  text_area_position_counter: number = 1;

  @Input('text_area_disabled') text_area_disabled: boolean;
  @Input('is_text_area_editable') is_text_area_editable: boolean;
  @Input('topic_id') topic_id;
  @Input('form') form: FormGroup;
  @Input('textarea_no_counter') textarea_no_counter: number;
  @Input('title_of_information') title_of_information: string;
  @Input('separator_dot') separator_dot: string;
  @Input('separator_colon') separator_colon: string;
  @Input('separator_semicolon') separator_semicolon: string;
  @Input('separator_dash') separator_dash: string;
  @Input('separator_rc') separator_rc: string;
  @Input('popup_text_area_value') popup_text_area_value: string[] = [];
  @Input('simple_text_area_value') simple_text_area_value: string[] = [];
  @Input('enable_information_screen') enable_information_screen: boolean;
  @Input('text_index') text_index;


  constructor(
    public ngxSmartModalService: NgxSmartModalService,
    @Inject(ElementRef) elementRef: ElementRef) {

    this.valueAccessIndex = this.text_index - 1;
    this.elementRef = elementRef;
    this.selectedText = "";
  }

  ngOnInit() {

    this.valueAccessIndex = this.text_index - 1;

    if (this.popup_text_area_value[this.valueAccessIndex] == undefined) {

      this.popup_text_area_value[this.valueAccessIndex] = '';

    }

    if (this.simple_text_area_value[this.valueAccessIndex] == undefined) {

      this.simple_text_area_value[this.valueAccessIndex] = '';

    }

  }

  getTextAreDisabled() {
    return this.text_area_disabled;
  }

  detectInput(event) {
    this.simple_text_area_value[this.valueAccessIndex] = event.target.value;
    this.popup_text_area_value[this.valueAccessIndex] = this.simple_text_area_value[this.valueAccessIndex];
  }

  validatePopup() {
    this.simple_text_area_value[this.valueAccessIndex] = this.popup_text_area_value[this.valueAccessIndex];
  }

  detectPopupInput(event) {
    this.popup_text_area_value[this.valueAccessIndex] = event.target.value;
  }


  clearPopupValue() {

    this.elementRef.nativeElement.querySelector(this.maximizedAreaIdRef).value = this.simple_text_area_value[this.valueAccessIndex];
    this.popup_text_area_value[this.valueAccessIndex] = this.simple_text_area_value[this.valueAccessIndex];

  }


  createParts(value, index, type): FormGroup {
    return new FormGroup({
      partId: new FormControl(''),
      type: new FormControl(type),
      position: new FormControl(index++),
      phraseId: new FormControl(''),
      value: new FormControl(value)
    })
  }

  closeTextArea() {

    let informations = ( < FormArray > this.form.controls['informations']);
    let areas = informations.at(0).get('areas') as FormArray;

    for (let i = 0; i < areas.length; i++) {
      if (areas.at(i).get('textarea_no').value == this.text_index) {
        areas.removeAt(i);
      }
    }
    this.compInteraction.removeComponent(this.text_index);
    this.valueAccessIndex = this.text_index - 1;
    
  }

  processTextForSeparator(text_area_value) {
    let str = text_area_value;
    let i;
    let substringResult = "";
    let type;
    let positionCounter = 1;
    let value = "";
    let position;
    let text = str.split(/(?=@)/g);
    let newParts = new FormArray([]);

    for (i = 0; i < text.length; i++) {

      if (text[i].indexOf('@S#') > -1 && (text[i].indexOf('#') !== text[i].lastIndexOf('#'))) {

        let textBetweenValue = text[i].split('@S#').pop().split('#')[0];
        substringResult = substringResult + '$~' + textBetweenValue;
        let textAfterValue = text[i].split('@S#').pop().split('#')[1];
        substringResult = substringResult + '$' + textAfterValue;

      } else if (text[i].indexOf('@D#') > -1 && (text[i].indexOf('#') !== text[i].lastIndexOf('#')) &&
        text[i].indexOf('||') > -1
      ) {

        let textBetweenValue = text[i].split('@D#').pop().split('#')[0];
        substringResult = substringResult + '$&' + textBetweenValue;
        let textAfterValue = text[i].split('@D#').pop().split('#')[1];
        substringResult = substringResult + '$' + textAfterValue;

      } else {
        substringResult = substringResult + '' + text[i];
      }
    }

    let finalResult = substringResult.split('$');
    finalResult = finalResult.filter(function (e) {
      return e
    });

    for (i = 0; i < finalResult.length; i++) {
      if (finalResult[i].indexOf('~') > -1) {
        value = '@S#' + finalResult[i].substring(1, (finalResult[i].length)) + '#';
        position = i + 1;
        if (this.separator_colon == value || this.separator_dash == value || this.separator_dot == value || this.separator_rc == value || this.separator_semicolon == value) {
          type = 'separator';
        } else {
          type = 'userseparator';
        }
      } else if (finalResult[i].indexOf('&') > -1) {
        value = '@D#' + finalResult[i].substring(1, (finalResult[i].length)) + '#';
        position = i + 1;
        type = "docref"
      } else {
        type = 'text';
        value = finalResult[i];
        position = i + 1;
      }

      if (!this.isInValid(value)) {

        if (this.parts.length > 0) {

          for (let k = 0; k < this.parts.length; k++) {

            let partValue = this.parts.at(k).value.value.toString().trim();
            let enteredValue = value.toString().trim();

            if (!this.isInValid(partValue)) {

              if (partValue === enteredValue) {
                this.parts.at(k).get('position').setValue(positionCounter);
                newParts.push(this.parts.at(k));
                this.parts.removeAt(k);
                positionCounter++;
                break;

              } else if (partValue !== enteredValue && k == Number(this.parts.length - 1)) {

                newParts.push(this.createParts(value, positionCounter, type));
                positionCounter++;
                break;
              }
            }
          }
        } else {
          newParts.push(this.createParts(value, position, type));
        }
      }
      value = "";
    }

    while (this.parts.length) {
      this.parts.removeAt(0);
    }
    for (let part = 0; part < newParts.length; part++) {
      this.parts.push(newParts.at(part))
    }

  }



  addnewPart() {

    let informations = ( < FormArray > this.form.controls['informations']);
    let areas = informations.at(0).get('areas') as FormArray;

    for (let i = 0; i < areas.length; i++) {
      if (areas.at(i).get('textarea_no').value == this.text_index) {
        this.parts = areas.at(i).get('parts') as FormArray;
      }
    }

    this.processTextForSeparator(this.simple_text_area_value[this.valueAccessIndex]);

    this.elementRef.nativeElement.querySelector(this.AreaIdRef).scrollTop = 0;
    
  }


  enterText(separator, popup: boolean) {
    let ref = this.elementRef.nativeElement.querySelector(popup ? this.maximizedAreaIdRef : this.AreaIdRef);

    if (this.simple_text_area_value[this.valueAccessIndex].length > 0 ||
      this.popup_text_area_value[this.valueAccessIndex].length > 0) {

      let startPosition = ref.selectionStart;
      let endPosition = ref.selectionEnd;

      if (popup) {
        this.popup_text_area_value[this.valueAccessIndex] = this.popup_text_area_value[this.valueAccessIndex].substring(0, startPosition) + separator + this.popup_text_area_value[this.valueAccessIndex].substring(endPosition, this.popup_text_area_value[this.valueAccessIndex].length);
      } else {
        this.simple_text_area_value[this.valueAccessIndex] = this.simple_text_area_value[this.valueAccessIndex].substring(0, startPosition) + separator + this.simple_text_area_value[this.valueAccessIndex].substring(endPosition, this.simple_text_area_value[this.valueAccessIndex].length);
        this.popup_text_area_value[this.valueAccessIndex] = this.simple_text_area_value[this.valueAccessIndex];
      }
      ref.value = popup ? this.popup_text_area_value[this.valueAccessIndex] : this.simple_text_area_value[this.valueAccessIndex];
      ref.focus();
      ref.selectionEnd = endPosition + separator.length;
      ref.selectionStart = ref.selectionEnd;
    } else {
        this.focusTextArea(ref);
    }
  }

  editPopuArea() {
    this.selectedText = '';
  }

  editTextArea() {
    this.text_area_disabled = false;
    this.is_text_area_editable = true;
  }

  disableEdit() {
    this.text_area_disabled = true;
    this.is_text_area_editable = false;
  }

  renderSelectedText(popup: boolean) {

    let startPosition = this.elementRef.nativeElement.querySelector(popup ? this.maximizedAreaIdRef : this.AreaIdRef).selectionStart;
    let endPosition = this.elementRef.nativeElement.querySelector(popup ? this.maximizedAreaIdRef : this.AreaIdRef).selectionEnd;

    if (popup) {

      this.selectedText =
        this.popup_text_area_value[this.valueAccessIndex].substring(startPosition, endPosition);

    } else {
      this.selectedText = this.simple_text_area_value[this.valueAccessIndex].substring(startPosition, endPosition);
    }

  }


  addParamterOrCorvet(separator, popup: boolean, ref) {
    let element = this.elementRef.nativeElement.querySelector('#' + ref);

    if (this.selectedText.includes('#')) {
      this.focusTextArea(element);
      return;
    }

    this.selectedText = this.selectedText.replace(/\s+/g, "");

    if (this.simple_text_area_value[this.valueAccessIndex].length > 0 || this.popup_text_area_value[this.valueAccessIndex].length > 0) {

      let ref = this.elementRef.nativeElement.querySelector(popup ? this.maximizedAreaIdRef : this.AreaIdRef);
      let startPosition = ref.selectionStart;
      let endPosition = ref.selectionEnd;

      if (popup) {
        this.popup_text_area_value[this.valueAccessIndex] =
          this.popup_text_area_value[this.valueAccessIndex].substring(0, startPosition) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.popup_text_area_value[this.valueAccessIndex].substring(endPosition, this.popup_text_area_value[this.valueAccessIndex].length);

      } else {
        this.simple_text_area_value[this.valueAccessIndex] = this.simple_text_area_value[this.valueAccessIndex].substring(0, startPosition) + separator.substring(0, separator.indexOf('#') + 1) + this.selectedText + separator.substring(separator.length - 1) + this.simple_text_area_value[this.valueAccessIndex].substring(endPosition, this.simple_text_area_value[this.valueAccessIndex].length);
        this.popup_text_area_value[this.valueAccessIndex] = this.simple_text_area_value[this.valueAccessIndex];
      }

      ref.value = popup ? this.popup_text_area_value[this.valueAccessIndex] : this.simple_text_area_value[this.valueAccessIndex];
      ref.focus();
      ref.selectionEnd = endPosition + separator.length;
      ref.selectionStart = ref.selectionEnd;
      this.selectedText = '';


    } else {
      this.focusTextArea(element);
    }
  }

  focusTextArea(element) {
    if (element && /INPUT|TEXTAREA/i.test(element.tagName)) {
      if ('selectionStart' in element) {
        element.selectionEnd = element.selectionStart;
      }
      element.blur();
    }

    if (window.getSelection) { // All browsers, except IE <=8
      window.getSelection().removeAllRanges();
    } else if (element.selection) { // IE <=8
      element.selection.empty();
    }
    element.focus();
  }

  moveTextArea(index) {
    this.compInteraction.moveInformationBlocks(index, this._ref);
  }

  resetSelectedText() {
    if (this.selectedText !== '') {
      this.selectedText = '';
    }
  }

  docSoaTitle: string = '';
  docSoaNumber: string = '';
  nestedModal: boolean;

  openDocSoa(nestedModal) {
    this.displayDocSoa = true;
    this.nestedModal = nestedModal;
  }

  closeDocSoa() {
    this.displayDocSoa = false;
    this.docSoaNumber = '';
    this.docSoaTitle = '';
  }

  generateDocSoa() {

    let docSoa = `@D#${this.docSoaTitle.trim()}||${this.docSoaNumber.trim()}#`;

    if (this.textareaValue.length > 0 || this.popup_text_area_value[this.valueAccessIndex].length > 0) {

      this.enterText(docSoa, this.nestedModal);

    } else {
      this.popup_text_area_value[this.valueAccessIndex] += docSoa;
      this.simple_text_area_value[this.valueAccessIndex] += docSoa;
    }

    this.closeDocSoa();
  }

  isInValid(str) {
    return (!str || str.length === 0 || /^\s*$/.test(str))
  }

  get maximizedAreaIdRef() {
    return `#${this.maximizedTextAreaReference}`;
  }

  get AreaIdRef() {
    return `#${this.textareaReference}`;
  }

  get popupValue() {
    return this.popup_text_area_value[this.valueAccessIndex];
  }

  get textareaValue() {
    return this.simple_text_area_value[this.valueAccessIndex];
  }

  get maximizedTextAreaReference() {
    return `maximized_area_ref_${this.text_index}`;
  }

  get textareaReference() {
    return `area_ref_${this.text_index}`;
  }

  get isTextEditable() {
    return this.is_text_area_editable;
  }

  get textAreaName() {
    return 'text_area_' + this.text_index;
  }
}