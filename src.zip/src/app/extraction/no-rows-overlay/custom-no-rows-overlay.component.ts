import { Component } from '@angular/core';
import { INoRowsOverlayAngularComp } from "ag-grid-angular";

@Component({
    selector: 'app-no-rows-overlay',
    templateUrl: './custom-no-rows-overlay.component.html',
    styleUrls: ['./custom-no-rows-overlay.component.scss']
})
export class CustomNoRowsOverlay implements INoRowsOverlayAngularComp {
    agInit(): void {}
}