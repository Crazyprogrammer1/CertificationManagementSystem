import { of } from 'rxjs';
import { Component, ViewChild, EventEmitter } from '@angular/core';
import { AgGridNg2 } from 'ag-grid-angular';
import { SelectItem, MenuItem, MessageService } from 'primeng/api';
import {
  ConfirmationService
} from 'primeng/api';
import * as XLSX from 'xlsx';
import { BillingService } from '../service/billing/billing.service';
import { IMyDrpOptions, IMyOptions } from 'mydaterangepicker';
import { RowType, LargeTextCellEditor } from 'ag-grid-community';
import { CustomNoRowsOverlay } from './no-rows-overlay/custom-no-rows-overlay.component';
declare var jsPDF: any;
declare const require: any;
const CONFIRM_MESSAGE = 'Certaines données sont sélectionnées. Voulez-vous exporter uniquement les données sélectionnées?';
const CONFIRM_HEADER = 'Exporter les données sélectionnées';
const DEFAULT_PAGINATION_NUMBER = 20;
const FILENAME = 'Facturation';
@Component({
  selector: 'app-extraction',
  templateUrl: './extraction.component.html',
  styleUrls: ['./extraction.component.scss'],
  providers: [ConfirmationService]
})
export class ExtractionComponent {
  defaultColDef: any;
  billingRowData: any;
  rowSelection: any;
  billingColumnDefs: any;
  billingGrid: any;
  pageLimit: SelectItem[];
  selectedpageLimit: any;
  gridColumnApi: any;
  @ViewChild('gridRef') gridRef: AgGridNg2;
  rowData: any;
  items: MenuItem[];
  globalFilter: string;
  dateSelected: boolean;
  noResults: boolean;
  rowDeselection: boolean = true;
   frameworkComponents;
   noRowsOverlayComponent;
  placeholderTxt = 'Select a date range...'
  myDateRangePickerOptions: IMyDrpOptions = {
    dateFormat: 'yyyy-mm-dd',
    editableDateRangeField: false,
    openSelectorOnInputClick: true
  };
  isIEOrEdge;

  public model: any = {};

  constructor(
    private billingService: BillingService,
    private confirmService: ConfirmationService
  ) {
    this.selectedpageLimit = DEFAULT_PAGINATION_NUMBER;
    this.rowSelection = "multiple";



    this.items = [
      {
        label: 'Export as CSV', icon: 'pi pi-file', command: () => {
          this.exportCSV();
        }
      },
      {
        label: 'Export as Excel', icon: 'pi pi-file', command: () => {
          this.exportXlSX();
        }
      },
      {
        label: 'Export as PDF', icon: 'pi pi-file', command: () => {
          this.exportPDF();
        }
      },
    ];

    this.isIEOrEdge = /msie\s|trident\/|edge\//i.test(window.navigator.userAgent);


    this.pageLimit = [
      { label: '5', value: 5 },
      { label: '10', value: 10 },
      { label: '15', value: 15 },
      { label: '20', value: 20 }
    ];


    this.billingColumnDefs = [
      {
        headerName: 'DataCollection',
        field: 'dataCollection',
        unSortIcon: true
      },
      {
        headerName: 'Datetime',
        field: 'creationDate',
        unSortIcon: true
      },
      {
        headerName: 'UserId',
        field: 'user',
        unSortIcon: true
      },
      {
        headerName: 'VIN',
        field: 'vin',
        unSortIcon: true
      }


    ];

    this.frameworkComponents = {
      customNoRowsOverlay: CustomNoRowsOverlay
    };
    this.noRowsOverlayComponent = "customNoRowsOverlay";

    this.defaultColDef = { resizable: true };
  }



  onPageSizeChanged() {
    let selectedSize = this.selectedpageLimit > 0 ? this.selectedpageLimit : DEFAULT_PAGINATION_NUMBER;
    this.billingGrid.paginationSetPageSize(Number(selectedSize));
    this.billingGrid.sizeColumnsToFit();
  }

  onGridReady(params) {
    this.billingGrid = params.api;
    this.gridColumnApi = params.columnApi;
    params.api.sizeColumnsToFit();
   
  }

  exportCSV() {

    var params = {};
    let selectedNodes: any;
    selectedNodes = this.billingGrid.getSelectedRows();
    this.gridRef.api.setSortModel(null);

    if (selectedNodes.length > 0) {
      this.confirmService.confirm({
        message: CONFIRM_MESSAGE,
        header: CONFIRM_HEADER,
        icon: 'pi pi-info-circle',
        accept: () => {
          params = {
            fileName: FILENAME,
            onlySelected: true
          };
          this.billingGrid.exportDataAsCsv(params);
          this.deselectRows();
        },
        reject: () => {
          params = {
            fileName: FILENAME
          };
          this.billingGrid.exportDataAsCsv(params);
          this.deselectRows();
        }
      });
    } else {
      params = {
        fileName: FILENAME
      };
      this.billingGrid.exportDataAsCsv(params);
      this.deselectRows();
    }


  }

  exportXlSX() {
    let headers = [];

    this.gridRef.columnApi.getAllGridColumns().forEach(element => {
      headers.push(element.getColDef().headerName)
    })

    this.getDataForFileGeneration(false, headers).then(data => {
      /* generate worksheet */

      const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);

      /* generate workbook and add the worksheet */
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

      /* save to file */
      XLSX.writeFile(wb, 'Facturation.xlsx');
    });

  }

  exportPDF() {
    const jsPDF = require('jspdf');
    require('jspdf-autotable');
    let doc = new jsPDF();
    let headers = [];

    this.gridRef.columnApi.getAllGridColumns().forEach(element => {
      headers.push(element.getColDef().headerName)
    })

    this.getDataForFileGeneration(true, headers).then(data => {
      doc.autoTable(
        {
          head: [headers],
          body: [
            ...data
          ]
        }
      );
      doc.save('Facturation.pdf');
    });



  }


  getDataForFileGeneration(returnArrayOfAray?: boolean, headers?: any) {
    let data: any[] = [];
    let selectedNodes: any;
    selectedNodes = this.billingGrid.getSelectedRows();

    var promise = new Promise<any[]>((resolve, reject) => {
      if (selectedNodes.length > 0) {

        this.confirmService.confirm({
          message: CONFIRM_MESSAGE,
          header: CONFIRM_HEADER,
          icon: 'pi pi-info-circle',
          accept: () => {

            if (returnArrayOfAray) {
              this.getArrayOfArray(headers, data, selectedNodes)

            } else {
              this.getArrayOfObjects(headers, data, selectedNodes)

            }
            this.deselectRows();
            resolve(data);

          },
          reject: () => {

            if (returnArrayOfAray) {

              this.getArrayOfArray(headers, data, this.rowData)


            } else {
              this.getArrayOfObjects(headers, data, this.rowData)

            }
            this.deselectRows();
            resolve(data);

          }
        });


      } else {
        if (returnArrayOfAray) {

          this.getArrayOfArray(headers, data, this.rowData)

        } else {
          this.getArrayOfObjects(headers, data, this.rowData)
        }
        this.deselectRows();
        resolve(data);

      }


    });
    return promise;
  }

  extractBillingdata() {

    this.resetAllData();

    let fromDate = `${this.model.beginDate.year}-${this.model.beginDate.month}-${this.model.beginDate.day}`;
    let toDate = `${this.model.endDate.year}-${this.model.endDate.month}-${this.model.endDate.day}`

    this.billingService.extractBillingData(fromDate, toDate).subscribe(data => {
      this.noResults = false;
      this.rowData = data;
      if (this.billingGrid)
        this.billingGrid.sizeColumnsToFit();
    },
      error => {
        this.rowData = null;
        this.noResults = true;
      }
    );

  }

  onDateRangeChanged(event) {

    event.beginJsDate == null ? this.dateSelected = false : this.dateSelected = true;

  }

  onModelUpdated(){
    if(this.billingGrid && this.billingGrid.rowModel.rowsToDisplay.length == 0) {
      this.billingGrid.showNoRowsOverlay();
    }
    if(this.billingGrid && this.billingGrid.rowModel.rowsToDisplay.length > 0) {
      this.billingGrid.hideOverlay();
    }
  }

  filterBillingData() {
  
    this.gridRef.api.setQuickFilter(this.globalFilter);
    this.gridRef.api.sizeColumnsToFit();
    this.onModelUpdated();
  
  }

  deselectRows() {
    if (this.gridRef) {
      this.gridRef.api.deselectAll();
    }
  }

  getArrayOfArray(headers: any[], data: any[], Iterable: any) {

    let col1 = headers[0];
    let col2 = headers[1];
    let col3 = headers[2];
    let col4 = headers[3];

    let objectKeys = [];
    objectKeys.push(col1);
    objectKeys.push(col2);
    objectKeys.push(col3);
    objectKeys.push(col4);

    let keys = [];


    objectKeys.forEach(data => {
      switch (data) {
        case 'DataCollection':
          keys.push('dataCollection');
          break;

        case 'VIN':
          keys.push('vin');
          break;

        case 'Datetime':
          keys.push('creationDate');
          break;

        case 'UserId':
          keys.push('user');
          break;

      }
    });


    Iterable.forEach(element => {
      data.push([
        element[keys[0]],
        element[keys[1]],
        element[keys[2]],
        element[keys[3]]
      ])
    });
  }

  getArrayOfObjects(headers: any[], data: any[], Iterable: any) {

    let col1 = headers[0];
    let col2 = headers[1];
    let col3 = headers[2];
    let col4 = headers[3];

    let objectKeys = [];
    objectKeys.push(col1);
    objectKeys.push(col2);
    objectKeys.push(col3);
    objectKeys.push(col4);

    let keys = [];


    objectKeys.forEach(data => {
      switch (data) {
        case 'DataCollection':
          keys.push('dataCollection');
          break;

        case 'VIN':
          keys.push('vin');
          break;

        case 'Datetime':
          keys.push('creationDate');
          break;

        case 'UserId':
          keys.push('user');
          break;

      }
    });

    Iterable.forEach(element => {

      data.push(
        {
          [col1]: element[keys[0]],
          [col2]: element[keys[1]],
          [col3]: element[keys[2]],
          [col4]: element[keys[3]]
        }
      )
    });
  }

  resetAllData() {
    if (this.gridRef) {
      this.gridRef.api.clearFocusedCell();
      this.gridRef.gridOptions.api.setFilterModel(null);
      this.gridRef.gridOptions.api.deselectAll();
      this.gridRef.api.setQuickFilter(null);
      this.gridRef.api.setSortModel(null);
      this.globalFilter = '';
    }

  }


}

