import { BrowserModule } from '@angular/platform-browser';
import { NgModule, HostListener,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {SplitButtonModule} from 'primeng/splitbutton';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './../welcome/welcome.component';
import {DragDropModule} from '@angular/cdk/drag-drop';
import { NavbarComponent } from './../navbar/navbar.component';
import { LoginComponent } from './../login/login.component';
import {ToastModule} from 'primeng/toast';
import {DropdownModule} from 'primeng/dropdown';
import {HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import {RouterModule} from '@angular/router';
import {appRoutes} from './route';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {AgGridModule} from "ag-grid-angular/main";
import {InputTextModule} from 'primeng/inputtext';
import {ButtonModule} from 'primeng/button';
import {PasswordModule} from 'primeng/password';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {DialogModule} from 'primeng/dialog';
import { HttpModule } from '@angular/http';
import { HeaderComponent } from './header/header.component';
import { TopmenuComponent } from './topmenu/topmenu.component';
import { SaisieComponent } from './saisie/saisie.component';
import { AdministrationComponent } from './administration/administration.component';
import { ExtractionComponent } from './extraction/extraction.component';
import { TopicComponent } from './topic/topic.component';
import {MessageService, ConfirmationService} from 'primeng/api';
import {CheckboxModule} from 'primeng/checkbox';
import {ListboxModule} from 'primeng/listbox';
import {TooltipModule} from 'primeng/tooltip';
import { TextareaComponent } from './textarea/textarea.component';
import { ImageService } from './image-upload/image.service';
import { FileDropDirective } from './file-drop.directive';

import { AppConfig } from './app.config';
import { APP_INITIALIZER } from '@angular/core';
import { environment } from '../environments/environment';
import { ImageUploadComponent } from './image-upload/image-upload.component';
import { NgxSmartModalModule,NgxSmartModalService } from 'ngx-smart-modal';
import {FileUploadModule} from 'primeng/fileupload';
import { ImageareaComponent } from './imagearea/imagearea.component';
import {CardModule} from 'primeng/card';
import {AuthGuardService} from './auth/auth-guard.service';
import {AuthService} from './auth/auth.service';
import {SnackbarModule} from 'ngx-snackbar';
import { TextSelectDirective } from './directive/text-select.directive';
import { ComplexApplicabilityComponent } from './complex-applicability/complex-applicability.component';
import { TagInputModule } from 'ngx-chips';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { TextUppercaseDirective } from './directive/text-uppercase.directive';
import { InformationImageService } from './service/Image/image.service';
import { BillingService } from './service/billing/billing.service';
import { MyDateRangePickerModule } from 'mydaterangepicker';
import { CustomNoRowsOverlay } from './extraction/no-rows-overlay/custom-no-rows-overlay.component';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}

export function initializeApp(appConfig: AppConfig) {
  return () => appConfig.load(environment.configFile);
}


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    WelcomeComponent,
    CustomNoRowsOverlay,
    NavbarComponent,
    HeaderComponent,
    TopmenuComponent,
    ComplexApplicabilityComponent,
    SaisieComponent,
    AdministrationComponent,
    ExtractionComponent,
    TopicComponent,
    TextareaComponent,
    FileDropDirective,
    ImageUploadComponent,
    ImageareaComponent,
    TextSelectDirective,
    TextUppercaseDirective
  ],
  entryComponents: [TextareaComponent,ImageareaComponent,CustomNoRowsOverlay],
  imports: [
    DragDropModule,
    BrowserModule,
    HttpClientModule,
    TooltipModule,
    MessageModule,
    MessagesModule,
    SplitButtonModule,
    DropdownModule,
    NgxSpinnerModule,
    MyDateRangePickerModule,
    BrowserAnimationsModule,
    FormsModule,
    CardModule,
    ReactiveFormsModule,
    InputTextModule,
    ButtonModule,
    TagInputModule,
    HttpModule,
    CheckboxModule,
    ToastModule,
    ListboxModule,
    DialogModule,
    ConfirmDialogModule,
    FileUploadModule,
    NgxSmartModalModule.forRoot(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    AgGridModule.withComponents(
      []
  ),
    RouterModule.forRoot(appRoutes,{ useHash: true }),
    SnackbarModule.forRoot()
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
    ],
  providers: [
    BillingService,
    InformationImageService,
    NgxSpinnerService,
     NgxSmartModalService,
    MessageService,
    ConfirmationService,
    AuthGuardService,
    AuthService,
    AppConfig,
    { provide: APP_INITIALIZER,
      useFactory: initializeApp,
      deps: [AppConfig], multi: true 
    },
    ImageService,
    {provide: LocationStrategy, useClass: HashLocationStrategy}
      ],
  bootstrap: [AppComponent]
})
export class AppModule{
 


}
