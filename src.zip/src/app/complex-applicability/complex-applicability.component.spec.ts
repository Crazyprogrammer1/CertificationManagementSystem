import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplexApplicabilityComponent } from './complex-applicability.component';

describe('ComplexApplicabilityComponent', () => {
  let component: ComplexApplicabilityComponent;
  let fixture: ComponentFixture<ComplexApplicabilityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplexApplicabilityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplexApplicabilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
