export class Topic {
    title : string = '';
   public  information : JSON [];
}