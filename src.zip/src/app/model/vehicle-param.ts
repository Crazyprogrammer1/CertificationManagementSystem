export class VehicleParam {
    label: string;
    value: string;
}
