export interface IAppConfig {
    authUrl: string;
    apiUrl: string;
}