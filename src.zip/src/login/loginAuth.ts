export interface LoginAuth {
  ldapAuthenticatedStr: string;
}
