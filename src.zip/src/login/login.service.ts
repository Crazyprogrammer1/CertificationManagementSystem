import {Injectable, OnDestroy} from '@angular/core';
import {HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
import {RequestOptions, Headers} from '@angular/http';
import {Location} from '@angular/common';
import {Observable} from 'rxjs';
import {LoginAuth} from './loginAuth';
import {UserDetails} from "./userDetails";
import {AppConfig} from '../app/app.config';
import {AuthService} from '../app/auth/auth.service';

@Injectable({
  providedIn: 'root'
})
export class LoginService  {

  constructor(private http: HttpClient, private location: Location,private authService : AuthService) { }

  validateAndGetUserLocale(userName: string, password: string): Observable<any> {
      let domain = location.protocol + '//' + AppConfig.settings.authUrl;
      let url = domain + '/tclAuth/authenticate';
      let userDetails = {userName: userName, password: password};
      console.log("POST WITH HEADERS");
      let headers = new HttpHeaders();
      headers = headers.append("Authorization", "Basic " + btoa("userName:password"));
      headers = headers.append("Content-Type", "application/x-www-form-urlencoded");
     
      this.authService.current_name_subject.next(true);
      
      return this.http.post(url, userDetails, {headers: headers});
  }

  authenticateUsingGet(userName: string, password: string): Observable<any> {
       //this.authService.setCurrentNameSubject(true);
      let domain = location.protocol + '//' + AppConfig.settings.authUrl;
      let url = domain + '/tclAuth/authenticateUsingGet';
      console.log(url);
  const params = new HttpParams()
  .set('userName', userName)
  .set('password', password);
  this.authService.current_name_subject.next(true);
  localStorage.setItem('isUserAuthenticated',this.authService.current_name_subject.getValue().toString());
  return this.http.get(url, {params});
  }


}
