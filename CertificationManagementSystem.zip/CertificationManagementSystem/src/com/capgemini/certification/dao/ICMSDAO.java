/*
 * Creation : 14 Apr 2019
 */
package com.capgemini.certification.dao;

import com.capgemini.certification.bean.UserDetails;

public interface ICMSDAO {

    UserDetails vaidateUser(String username);

}
