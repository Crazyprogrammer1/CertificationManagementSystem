/*
 * Creation : 14 Apr 2019
 */
package com.capgemini.certification.dao;

import java.util.List;

import com.capgemini.certification.bean.UserDetails;

public interface ICMSDAO {

    List<UserDetails> vaidateUser(UserDetails user);

}
