/*
 * Creation : 14 Apr 2019
 */
package com.capgemini.certification.dao;

import org.springframework.stereotype.Repository;

import com.capgemini.certification.bean.UserDetails;

@Repository("ICMSdao")
public class ICMSDaoImpl implements ICMSDAO {

    /*
     * EntityManagerFactory emf = Perasistence.createEntityManagerFactory("oracle");
     */
    @Override
    public UserDetails vaidateUser(String username) {
        /* Query query = emf.createEntityManager().createQuery("FROM userDetails where USERNAME =:uname"); */
        /* query.setParameter("uname", username); */
        return null;
    }

}
