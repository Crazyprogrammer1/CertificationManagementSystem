/*
 * Creation : 14 Apr 2019
 */
package com.capgemini.certification.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.capgemini.certification.bean.UserDetails;

@Repository("ICMSdao")
public class ICMSDaoImpl implements ICMSDAO {

    @PersistenceContext(unitName = "appPU")
    @Qualifier(value = "entityManagerFactory")
    private EntityManager em;

    @Override
    public List<UserDetails> vaidateUser(UserDetails user) {
        Query query = em.createQuery("FROM UserDetails where username= :uname and password = :pass");
        query.setParameter("uname", user.getUsername());
        query.setParameter("pass", user.getPassword());
        return query.getResultList();
    }

}
