/*
 * Creation : 14 Apr 2019
 */
package com.capgemini.certification.service;

import java.util.List;

import com.capgemini.certification.bean.UserDetails;

public interface ICMSService {

    List<UserDetails> vaidateUser(UserDetails user);

    List<UserDetails> viewAllUsers();

    void addNewUser(UserDetails user);

}
