/*
 * Creation : 14 Apr 2019
 */
package com.capgemini.certification.service;

import com.capgemini.certification.bean.UserDetails;

public interface ICMSService {

    UserDetails vaidateUser(String string);

}
