/*
 * Creation : 14 Apr 2019
 */
package com.capgemini.certification.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.certification.bean.UserDetails;
import com.capgemini.certification.dao.ICMSDAO;

@Service("ICMSService")
@Transactional
public class ICMSServiceImpl implements ICMSService {

    @Autowired
    ICMSDAO ICMSdao;

    @Override
    public List<UserDetails> vaidateUser(UserDetails user) {

        return ICMSdao.vaidateUser(user);
    }

    @Override
    public List<UserDetails> viewAllUsers() {

        return ICMSdao.viewAllUsers();

    }

    @Override
    public void addNewUser(UserDetails user) {
        ICMSdao.addNewUser(user);
    }

}
