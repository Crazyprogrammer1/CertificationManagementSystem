package com.capgemini.certification.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.certification.bean.UserDetails;
import com.capgemini.certification.service.ICMSService;

/*
 * author: Crunchify.com
 * 
 */

@Controller
public class Certification {

    @Autowired
    ICMSService ICMSService;

    @RequestMapping(value = "home", method = RequestMethod.GET)
    public ModelAndView helloWorld(@ModelAttribute("user") UserDetails user) {

        return new ModelAndView("login", "user", user);
    }

    @RequestMapping(value = "loginUser", method = RequestMethod.POST)
    public ModelAndView loginUser(@ModelAttribute("user") UserDetails user, Map<String, Object> model) {

        List<UserDetails> userList = ICMSService.vaidateUser(user);
        String role = null;
        if (userList.isEmpty()) {
            model.put("InvalidUser", true);
            return new ModelAndView("login");
        }
        model.put("InvalidUser", false);

        for (UserDetails users : userList) {
            role = users.getRole();
        }

        if ("admin".equalsIgnoreCase(role)) {
            return new ModelAndView("adminLandingPage");
        } else if ("user".equalsIgnoreCase(role)) {
            return new ModelAndView("userLandingPage");
        }

        return new ModelAndView("login", "user", user);
    }

}