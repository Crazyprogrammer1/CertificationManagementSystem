package com.capgemini.certification.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.certification.bean.UserDetails;
import com.capgemini.certification.service.ICMSService;

/*
 * author: Crunchify.com
 * 
 */

@Controller
public class Certification {

    @Autowired
    ICMSService ICMSService;

    String username = null;

    @RequestMapping(value = "home", method = RequestMethod.GET)
    public ModelAndView home(@ModelAttribute("user") UserDetails user) {

        return new ModelAndView("login", "user", user);
    }

    @RequestMapping(value = "loginUser", method = RequestMethod.POST)
    public ModelAndView loginUser(@ModelAttribute("user") UserDetails user, Map<String, Object> model) {

        List<UserDetails> userList = ICMSService.vaidateUser(user);
        String role = null;
        if (userList.isEmpty()) {
            model.put("InvalidUser", true);
            return new ModelAndView("login");
        }
        model.put("InvalidUser", false);

        for (UserDetails users : userList) {
            role = users.getRole();
            username = users.getUsername();
        }
        model.put("username", username);
        if ("admin".equalsIgnoreCase(role)) {

            return new ModelAndView("AdminLanding");
        } else if ("user".equalsIgnoreCase(role)) {

            return new ModelAndView("UserLanding");
        }

        return new ModelAndView("login", "user", user);
    }

    @RequestMapping(value = "allUsers", method = RequestMethod.GET)
    public ModelAndView viewAllUsers(Map<String, Object> model) {

        model.put("username", username);
        List<UserDetails> userList = ICMSService.viewAllUsers();
        model.put("showAllUsers", true);
        model.put("addNewUser", false);
        return new ModelAndView("AdminLanding", "userList", userList);
    }

    @RequestMapping(value = "addUser", method = RequestMethod.GET)
    public ModelAndView addNewUser(@ModelAttribute("user") UserDetails user, Map<String, Object> model) {
        model.put("username", username);
        model.put("showAllUsers", false);
        model.put("addNewUser", true);
        return new ModelAndView("AdminLanding");
    }

    @RequestMapping(value = "insertUser", method = RequestMethod.POST)
    public ModelAndView insertUser(@ModelAttribute("user") UserDetails user, Map<String, Object> model) {
        model.put("username", username);
        model.put("showAllUsers", false);
        model.put("addNewUser", true);
        ICMSService.addNewUser(user);

        model.put("showAllUsers", false);
        model.put("addNewUser", true);
        user.setEmail(null);
        user.setDesignation(null);
        user.setEmpId(null);
        user.setPassword(null);
        user.setUserId(null);
        user.setUsername(null);
        user.setBu(null);
        return new ModelAndView("AdminLanding", "userAdded", true);
    }

    @RequestMapping(value = "resetAdmin", method = RequestMethod.GET)
    public ModelAndView resetAdmin(@ModelAttribute("user") UserDetails user, Map<String, Object> model) {
        model.put("username", username);
        model.put("showAllUsers", false);
        model.put("addNewUser", false);
        return new ModelAndView("AdminLanding");
    }

    @RequestMapping(value = "logoutAdmin", method = RequestMethod.GET)
    public ModelAndView logoutAdmin(@ModelAttribute("user") UserDetails user) {
        username = null;
        return new ModelAndView("login", "user", user);
    }

    @RequestMapping(value = "assignCertification", method = RequestMethod.GET)
    public ModelAndView assignCertification(@ModelAttribute("user") UserDetails user) {
        username = null;
        return new ModelAndView("login", "user", user);
    }

}